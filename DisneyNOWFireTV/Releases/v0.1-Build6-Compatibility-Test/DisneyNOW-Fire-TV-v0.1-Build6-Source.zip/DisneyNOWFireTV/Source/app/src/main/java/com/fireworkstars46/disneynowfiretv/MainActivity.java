package com.fireworkstars46.disneynowfiretv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.media.MediaDrm;
import android.media.UnsupportedSchemeException;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Message;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebViewDatabase;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public final class MainActivity extends Activity {
    private static final String HOME_URL = "https://disneynow.com/";
    private static final String EXPECTED_PACKAGE_ID = "com.fireworkstars46.disneynowfiretv";
    private static final String PREFS_NAME = "settings";
    private static final String KEY_UA_PROFILE = "ua_profile";
    private static final String KEY_TV_FOCUS = "tv_focus_navigation";
    private static final String KEY_CURSOR_ENABLED = "cursor_enabled";
    private static final String KEY_PAGE_ZOOM = "page_zoom_percent";
    private static final String KEY_BUILD2_MIGRATED = "build2_navigation_migrated";
    private static final String KEY_FIRST_RUN_SHOWN = "first_run_shown";

    private static final int DEFAULT_PAGE_ZOOM = 75;
    private static final int MIN_PAGE_ZOOM = 0;
    private static final int MAX_PAGE_ZOOM = 500;

    private static final String UA_ANDROID = "android";
    private static final String UA_WEBVIEW = "webview";
    private static final String UA_DESKTOP = "desktop";

    private static final UUID WIDEVINE_UUID = new UUID(
            0xedef8ba979d64aceL,
            0xa3c827dcd51d21edL
    );

    private FrameLayout root;
    private WebView webView;
    private CursorView cursorView;
    private float cursorX;
    private float cursorY;
    private boolean cursorPositionInitialized;
    private static final long CURSOR_FRAME_INTERVAL_MS = 16L;
    private static final long CURSOR_ACCELERATION_DELAY_MS = 220L;
    private static final long CURSOR_ACCELERATION_RAMP_MS = 1100L;
    private static final float CURSOR_TAP_NUDGE_PIXELS = 2f;
    private static final float CURSOR_START_PIXELS_PER_FRAME = 2f;
    private static final float CURSOR_MAX_PIXELS_PER_FRAME = 10f;
    private final Handler cursorMovementHandler = new Handler(Looper.getMainLooper());
    private boolean cursorLeftHeld, cursorRightHeld, cursorUpHeld, cursorDownHeld, cursorMovementFrameScheduled;
    private long cursorMovementStartedAt;
    private FrameLayout customViewContainer;
    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private SharedPreferences prefs;
    private AppLogger logger;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        enterImmersiveMode();

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        logger = new AppLogger(this);
        migrateBuild2Settings();
        logger.log("START version=" + versionLabel() + " sdk=" + Build.VERSION.SDK_INT);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        root.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        cursorView = new CursorView(this);
        cursorView.setVisibility(isCursorEnabled() ? View.VISIBLE : View.GONE);
        root.addView(cursorView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        customViewContainer = new FrameLayout(this);
        customViewContainer.setBackgroundColor(Color.BLACK);
        customViewContainer.setVisibility(View.GONE);
        root.addView(customViewContainer, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        setContentView(root);
        configureWebView();
        webView.loadUrl(HOME_URL);
        webView.requestFocus();
        cursorView.post(this::resetCursorToCenter);

        if (!prefs.getBoolean(KEY_FIRST_RUN_SHOWN, false)) {
            boolean saved = prefs.edit().putBoolean(KEY_FIRST_RUN_SHOWN, true).commit();
            if (!saved) {
                logger.log("WARN first-run flag persistence failed");
            }
            Toast.makeText(this, "D-pad moves the cursor. Center clicks. Press the Fire TV Menu button for controls.", Toast.LENGTH_LONG).show();
        }
    }

    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setSupportMultipleWindows(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setUserAgentString(resolveUserAgent(currentUaProfile()));
        webView.setInitialScale(currentPageZoom());
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        // Keep application/window hardware acceleration enabled, but do not force the WebView
        // into an offscreen hardware layer. Let WebView/SurfaceView choose the compositor path so
        // Fire TV ad/protected-video surfaces are less likely to render audio with a black picture.
        webView.setLayerType(View.LAYER_TYPE_NONE, null);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            settings.setSafeBrowsingEnabled(true);
        }

        WebView.setWebContentsDebuggingEnabled(false);

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(webView, true);

        webView.setWebViewClient(new DisneyWebViewClient());
        webView.setWebChromeClient(new DisneyWebChromeClient());
    }

    private final class DisneyWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return handleUri(request.getUrl());
        }

        @SuppressWarnings("deprecation")
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            return handleUri(Uri.parse(url));
        }

        @SuppressWarnings("deprecation")
        @Override
        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            logger.log("WEB_ERROR code=" + errorCode + " host=" + safeHost(failingUrl));
            super.onReceivedError(view, errorCode, description, failingUrl);
        }

        @Override
        public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
            if (request.isForMainFrame()) {
                logger.log("HTTP_ERROR status=" + errorResponse.getStatusCode() + " host=" + safeHost(request.getUrl()));
            }
            super.onReceivedHttpError(view, request, errorResponse);
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            CookieManager.getInstance().flush();
            logger.log("PAGE_FINISHED host=" + safeHost(url));
            if (prefs.getBoolean(KEY_TV_FOCUS, false)) {
                injectFocusHighlight();
            }
            view.requestFocus();
        }
    }

    private final class DisneyWebChromeClient extends WebChromeClient {
        @Override
        public void onShowCustomView(View view, CustomViewCallback callback) {
            if (customView != null) {
                callback.onCustomViewHidden();
                return;
            }
            customView = view;
            customViewCallback = callback;
            customViewContainer.removeAllViews();
            customViewContainer.addView(view, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
            ));
            // Keep WebView attached/visible behind the fullscreen surface so its compositor and
            // protected/ad video pipeline stay alive. The opaque fullscreen container sits on top.
            webView.setVisibility(View.VISIBLE);
            customViewContainer.setVisibility(View.VISIBLE);
            customViewContainer.bringToFront();
            view.requestFocus();
            stopAllCursorDirections();
            if (cursorView != null) {
                cursorView.setVisibility(View.GONE);
            }
            enterImmersiveMode();
            logger.log("FULLSCREEN enter compositor=overlay");
        }

        @Override
        public void onHideCustomView() {
            hideCustomView();
        }

        @Override
        public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
            final WebView popup = new WebView(MainActivity.this);
            WebSettings popupSettings = popup.getSettings();
            popupSettings.setJavaScriptEnabled(true);
            popupSettings.setDomStorageEnabled(true);
            popupSettings.setMediaPlaybackRequiresUserGesture(false);
            popupSettings.setAllowFileAccess(false);
            popupSettings.setAllowContentAccess(false);
            popupSettings.setSupportMultipleWindows(true);
            popupSettings.setJavaScriptCanOpenWindowsAutomatically(true);
            popupSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
            popupSettings.setUserAgentString(resolveUserAgent(currentUaProfile()));
            CookieManager popupCookies = CookieManager.getInstance();
            popupCookies.setAcceptCookie(true);
            popupCookies.setAcceptThirdPartyCookies(popup, true);
            final boolean[] routed = new boolean[]{false};
            popup.setWebViewClient(new WebViewClient() {
                private boolean routeOnce(WebView child, Uri uri) {
                    if (uri == null) return false;
                    if (!isHttpOrHttps(uri)) return handleUri(uri);
                    if (routed[0]) return true;
                    routed[0] = true;
                    CookieManager.getInstance().flush();
                    webView.loadUrl(uri.toString());
                    child.post(() -> {
                        child.stopLoading();
                        child.setWebViewClient(null);
                        child.destroy();
                    });
                    return true;
                }

                @Override
                public boolean shouldOverrideUrlLoading(WebView child, WebResourceRequest request) {
                    return routeOnce(child, request == null ? null : request.getUrl());
                }

                @SuppressWarnings("deprecation")
                @Override
                public boolean shouldOverrideUrlLoading(WebView child, String url) {
                    return routeOnce(child, url == null ? null : Uri.parse(url));
                }

                @Override
                public void onPageStarted(WebView child, String url, android.graphics.Bitmap favicon) {
                    super.onPageStarted(child, url, favicon);
                    if (!routed[0] && url != null) routeOnce(child, Uri.parse(url));
                }
            });
            WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
            transport.setWebView(popup);
            resultMsg.sendToTarget();
            return true;
        }

        @Override
        public void onPermissionRequest(PermissionRequest request) {
            logger.log("WEB_PERMISSION denied resources=" + request.getResources().length);
            request.deny();
        }

        @Override
        public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
            logger.log("GEOLOCATION denied host=" + safeHost(origin));
            callback.invoke(origin, false, false);
        }
    }

    private boolean handleUri(Uri uri) {
        if (uri == null) {
            return false;
        }
        if (isHttpOrHttps(uri)) {
            return false;
        }

        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(intent);
            logger.log("EXTERNAL_SCHEME opened scheme=" + safeText(uri.getScheme()));
        } catch (ActivityNotFoundException ex) {
            logger.log("EXTERNAL_SCHEME unavailable scheme=" + safeText(uri.getScheme()));
            Toast.makeText(this, "No app is installed to open that link.", Toast.LENGTH_SHORT).show();
        }
        return true;
    }

    private static boolean isHttpOrHttps(Uri uri) {
        if (uri == null) {
            return false;
        }
        String scheme = uri.getScheme();
        return "http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme);
    }

    private void hideCustomView() {
        if (customView == null) {
            return;
        }
        customViewContainer.removeAllViews();
        customViewContainer.setVisibility(View.GONE);
        customView = null;
        webView.setVisibility(View.VISIBLE);
        if (cursorView != null) {
            cursorView.setVisibility(isCursorEnabled() ? View.VISIBLE : View.GONE);
        }
        if (customViewCallback != null) {
            customViewCallback.onCustomViewHidden();
            customViewCallback = null;
        }
        webView.requestFocus();
        enterImmersiveMode();
        logger.log("FULLSCREEN exit");
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event != null) {
            int keyCode = event.getKeyCode();
            int action = event.getAction();

            if (keyCode == KeyEvent.KEYCODE_MENU) {
                if (action == KeyEvent.ACTION_DOWN && event.getRepeatCount() == 0) {
                    showAppMenu();
                }
                return true;
            }

            if (customView == null && isCursorEnabled() && isCursorNavigationKey(keyCode)) {
                if (isCursorDirectionKey(keyCode)) {
                    if (action == KeyEvent.ACTION_DOWN && event.getRepeatCount() == 0) startCursorDirection(keyCode);
                    else if (action == KeyEvent.ACTION_UP) stopCursorDirection(keyCode);
                } else if (action == KeyEvent.ACTION_DOWN && event.getRepeatCount() == 0) performCursorClick();
                // Consume both DOWN and UP before WebView; repeated DOWN is ignored because our frame loop moves smoothly.
                return true;
            }
        }
        return super.dispatchKeyEvent(event);
    }

    private static boolean isCursorDirectionKey(int keyCode) {
        return keyCode == KeyEvent.KEYCODE_DPAD_LEFT
                || keyCode == KeyEvent.KEYCODE_DPAD_RIGHT
                || keyCode == KeyEvent.KEYCODE_DPAD_UP
                || keyCode == KeyEvent.KEYCODE_DPAD_DOWN;
    }

    private static boolean isCursorNavigationKey(int keyCode) {
        return isCursorDirectionKey(keyCode)
                || keyCode == KeyEvent.KEYCODE_DPAD_CENTER
                || keyCode == KeyEvent.KEYCODE_ENTER
                || keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER;
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            showAppMenu();
            return true;
        }

        if (customView == null && isCursorEnabled()) {
            if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT
                    || keyCode == KeyEvent.KEYCODE_DPAD_RIGHT
                    || keyCode == KeyEvent.KEYCODE_DPAD_UP
                    || keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
                moveCursor(keyCode, event == null ? 0 : event.getRepeatCount());
                return true;
            }
            if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER) {
                performCursorClick();
                return true;
            }
        }

        if (customView == null && prefs.getBoolean(KEY_TV_FOCUS, false)) {
            if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT || keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
                moveWebFocus(true);
                return true;
            }
            if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT || keyCode == KeyEvent.KEYCODE_DPAD_UP) {
                moveWebFocus(false);
                return true;
            }
            if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER) {
                sendEnterToWebView();
                return true;
            }
        }

        return super.onKeyDown(keyCode, event);
    }

    private void startCursorDirection(int keyCode) {
        boolean wasMoving=anyCursorDirectionHeld(); setCursorDirectionHeld(keyCode,true);
        if(!wasMoving&&anyCursorDirectionHeld()){cursorMovementStartedAt=SystemClock.uptimeMillis();moveCursorByDirection(keyCode,CURSOR_TAP_NUDGE_PIXELS);}
        scheduleCursorMovementFrame();
    }
    private void stopCursorDirection(int keyCode){setCursorDirectionHeld(keyCode,false);if(!anyCursorDirectionHeld()){cursorMovementHandler.removeCallbacks(cursorMovementFrame);cursorMovementFrameScheduled=false;}}
    private void stopAllCursorDirections(){cursorLeftHeld=cursorRightHeld=cursorUpHeld=cursorDownHeld=false;cursorMovementHandler.removeCallbacks(cursorMovementFrame);cursorMovementFrameScheduled=false;}
    private void setCursorDirectionHeld(int k,boolean v){if(k==KeyEvent.KEYCODE_DPAD_LEFT)cursorLeftHeld=v;else if(k==KeyEvent.KEYCODE_DPAD_RIGHT)cursorRightHeld=v;else if(k==KeyEvent.KEYCODE_DPAD_UP)cursorUpHeld=v;else if(k==KeyEvent.KEYCODE_DPAD_DOWN)cursorDownHeld=v;}
    private boolean anyCursorDirectionHeld(){return cursorLeftHeld||cursorRightHeld||cursorUpHeld||cursorDownHeld;}
    private void scheduleCursorMovementFrame(){if(!cursorMovementFrameScheduled&&anyCursorDirectionHeld()){cursorMovementFrameScheduled=true;cursorMovementHandler.postDelayed(cursorMovementFrame,CURSOR_FRAME_INTERVAL_MS);}}
    private final Runnable cursorMovementFrame=new Runnable(){@Override public void run(){
        cursorMovementFrameScheduled=false;if(!isCursorEnabled()||customView!=null||!anyCursorDirectionHeld()){stopAllCursorDirections();return;}
        long held=Math.max(0L,SystemClock.uptimeMillis()-cursorMovementStartedAt);float ramp=clamp((held-CURSOR_ACCELERATION_DELAY_MS)/(float)CURSOR_ACCELERATION_RAMP_MS,0f,1f);ramp*=ramp;
        float speed=CURSOR_START_PIXELS_PER_FRAME+(CURSOR_MAX_PIXELS_PER_FRAME-CURSOR_START_PIXELS_PER_FRAME)*ramp;
        float dx=(cursorRightHeld?1f:0f)-(cursorLeftHeld?1f:0f),dy=(cursorDownHeld?1f:0f)-(cursorUpHeld?1f:0f);
        if(dx!=0f||dy!=0f){if(dx!=0f&&dy!=0f){dx*=0.70710677f;dy*=0.70710677f;}moveCursorBy(dx*speed,dy*speed);}scheduleCursorMovementFrame();}};
    private void moveCursor(int keyCode,int repeatCount){moveCursorByDirection(keyCode,CURSOR_TAP_NUDGE_PIXELS);}
    private void moveCursorByDirection(int k,float px){float dx=0f,dy=0f;if(k==KeyEvent.KEYCODE_DPAD_LEFT)dx=-px;else if(k==KeyEvent.KEYCODE_DPAD_RIGHT)dx=px;else if(k==KeyEvent.KEYCODE_DPAD_UP)dy=-px;else if(k==KeyEvent.KEYCODE_DPAD_DOWN)dy=px;moveCursorBy(dx,dy);}
    private void moveCursorBy(float dx,float dy){
        if(cursorView==null||webView==null)return;ensureCursorPosition();float radius=cursorView.cursorRadius(),minX=radius,minY=radius,maxX=Math.max(minX,webView.getWidth()-radius),maxY=Math.max(minY,webView.getHeight()-radius);
        float x=cursorX+dx,y=cursorY+dy;boolean top=y<minY,bottom=y>maxY;cursorX=clamp(x,minX,maxX);cursorY=clamp(y,minY,maxY);cursorView.setCursorPosition(cursorX,cursorY);
        if(top)webView.scrollBy(0,-dp(10));else if(bottom)webView.scrollBy(0,dp(10));
    }

    private void performCursorClick() {
        if (webView == null) {
            return;
        }
        ensureCursorPosition();
        long now = android.os.SystemClock.uptimeMillis();
        MotionEvent down = MotionEvent.obtain(now, now, MotionEvent.ACTION_DOWN, cursorX, cursorY, 0);
        MotionEvent up = MotionEvent.obtain(now, now + 24L, MotionEvent.ACTION_UP, cursorX, cursorY, 0);
        try {
            webView.dispatchTouchEvent(down);
            webView.dispatchTouchEvent(up);
            if (cursorView != null) {
                cursorView.showClickPulse();
            }
        } finally {
            down.recycle();
            up.recycle();
        }
    }

    private void ensureCursorPosition() {
        if (cursorPositionInitialized || webView == null || webView.getWidth() <= 0 || webView.getHeight() <= 0) {
            return;
        }
        resetCursorToCenter();
    }

    private void resetCursorToCenter() {
        if (webView == null || cursorView == null || webView.getWidth() <= 0 || webView.getHeight() <= 0) {
            return;
        }
        cursorX = webView.getWidth() / 2f;
        cursorY = webView.getHeight() / 2f;
        cursorPositionInitialized = true;
        cursorView.setCursorPosition(cursorX, cursorY);
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private void moveWebFocus(boolean forward) {
        String delta = forward ? "1" : "-1";
        String js = "(function(){"
                + "var q='a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex=\\\"-1\\\"]),video';"
                + "var a=Array.prototype.slice.call(document.querySelectorAll(q)).filter(function(e){"
                + "var r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.visibility!==\"hidden\"&&s.display!==\"none\";});"
                + "if(!a.length)return;var cur=document.activeElement,i=a.indexOf(cur);"
                + "if(i<0){i=" + (forward ? "0" : "a.length-1") + ";}else{i=(i+" + delta + "+a.length)%a.length;}"
                + "a[i].focus();a[i].scrollIntoView({block:'center',inline:'center'});"
                + "})();";
        webView.evaluateJavascript(js, null);
    }

    private void sendEnterToWebView() {
        long now = android.os.SystemClock.uptimeMillis();
        webView.dispatchKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER, 0));
        webView.dispatchKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER, 0));
    }

    private void injectFocusHighlight() {
        String js = "(function(){if(document.getElementById('firetv-focus-style'))return;"
                + "var s=document.createElement('style');s.id='firetv-focus-style';"
                + "s.textContent='*:focus{outline:4px solid white !important;outline-offset:3px !important;}';"
                + "(document.head||document.documentElement).appendChild(s);})();";
        webView.evaluateJavascript(js, null);
    }

    private void showAppMenu() {
        final boolean cursorEnabled = isCursorEnabled();
        final boolean legacyFocus = prefs.getBoolean(KEY_TV_FOCUS, false);
        final String[] items = new String[]{
                "Home",
                "Reload",
                "Page Zoom: " + currentPageZoom() + "%",
                "Cursor Navigation: " + (cursorEnabled ? "On" : "Off"),
                "Legacy Focus Navigation: " + (legacyFocus ? "On" : "Off"),
                "User Agent: " + profileLabel(currentUaProfile()),
                "Clear DisneyNOW App Web Data",
                "Diagnostics",
                "Export Diagnostic Report",
                "Safe Self-Test",
                "About",
                "Exit"
        };

        new AlertDialog.Builder(this)
                .setTitle("DisneyNOW Web — " + versionLabel())
                .setItems(items, (dialog, which) -> {
                    switch (which) {
                        case 0:
                            webView.loadUrl(HOME_URL);
                            break;
                        case 1:
                            webView.reload();
                            break;
                        case 2:
                            showPageZoomDialog();
                            break;
                        case 3:
                            setCursorEnabled(!cursorEnabled);
                            break;
                        case 4:
                            setTvFocusNavigation(!legacyFocus);
                            break;
                        case 5:
                            showUserAgentDialog();
                            break;
                        case 6:
                            confirmClearWebData();
                            break;
                        case 7:
                            showTextDialog("Diagnostics", buildDiagnostics());
                            break;
                        case 8:
                            exportDiagnostics();
                            break;
                        case 9:
                            runSafeSelfTest();
                            break;
                        case 10:
                            showAbout();
                            break;
                        case 11:
                            logger.log("EXIT menu");
                            finish();
                            break;
                        default:
                            break;
                    }
                })
                .show();
    }

    private void showPageZoomDialog() {
        final int current = currentPageZoom();
        final LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(20);
        panel.setPadding(pad, dp(8), pad, 0);

        TextView help = new TextView(this);
        help.setText("Custom Page Zoom: 0-500%. 0 uses WebView automatic scale. Enter any whole-number value.");
        panel.addView(help, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_NUMBER);
        input.setText(String.valueOf(current));
        input.setSelectAllOnFocus(true);
        input.setContentDescription("Page Zoom percent from 0 to 500");
        panel.addView(input, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        final SeekBar slider = new SeekBar(this);
        slider.setMax(MAX_PAGE_ZOOM);
        slider.setProgress(current);
        slider.setContentDescription("Page Zoom slider 0 to 500 percent");
        panel.addView(slider, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button minus = new Button(this); minus.setText("-1");
        Button plus = new Button(this); plus.setText("+1");
        Button reset = new Button(this); reset.setText("Reset 100%");
        row.addView(minus, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(plus, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(reset, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.5f));
        panel.addView(row, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        final boolean[] syncing = new boolean[]{false};
        slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser || syncing[0]) return;
                syncing[0] = true;
                input.setText(String.valueOf(progress));
                input.setSelection(input.getText().length());
                syncing[0] = false;
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                int value = seekBar.getProgress();
                input.setText(String.valueOf(value));
                input.setSelection(input.getText().length());
                setPageZoom(value, true);
            }
        });

        View.OnClickListener adjust = v -> {
            Integer parsed = parseZoomInput(input);
            int value = parsed == null ? slider.getProgress() : parsed;
            if (v == minus) value--;
            else if (v == plus) value++;
            else value = 100;
            value = Math.max(MIN_PAGE_ZOOM, Math.min(MAX_PAGE_ZOOM, value));
            slider.setProgress(value);
            input.setText(String.valueOf(value));
            input.setSelection(input.getText().length());
            setPageZoom(value, true);
        };
        minus.setOnClickListener(adjust);
        plus.setOnClickListener(adjust);
        reset.setOnClickListener(adjust);

        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Page Zoom: " + current + "%")
                .setView(panel)
                .setPositiveButton("Apply", null)
                .setNegativeButton("Close", null)
                .create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            Integer value = parseZoomInput(input);
            if (value == null || value < MIN_PAGE_ZOOM || value > MAX_PAGE_ZOOM) {
                input.setError("Enter a whole number from 0 to 500.");
                return;
            }
            slider.setProgress(value);
            if (setPageZoom(value, true)) dialog.dismiss();
        }));
        dialog.show();
    }

    private Integer parseZoomInput(EditText input) {
        if (input == null) return null;
        String raw = input.getText() == null ? "" : input.getText().toString().trim();
        if (raw.isEmpty()) return null;
        try {
            return Integer.parseInt(raw);
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private void showUserAgentDialog() {
        final String[] values = new String[]{UA_ANDROID, UA_WEBVIEW, UA_DESKTOP};
        final String[] labels = new String[]{
                "Android Chrome-compatible (recommended)",
                "Device WebView original",
                "Desktop Edge-compatible"
        };
        String current = currentUaProfile();
        int checked = 0;
        for (int i = 0; i < values.length; i++) {
            if (values[i].equals(current)) {
                checked = i;
                break;
            }
        }

        final int initialChecked = checked;
        new AlertDialog.Builder(this)
                .setTitle("User Agent")
                .setSingleChoiceItems(labels, initialChecked, (dialog, which) -> {
                    setUserAgentProfile(values[which]);
                    dialog.dismiss();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void setUserAgentProfile(String profile) {
        if (!isValidUaProfile(profile)) {
            Toast.makeText(this, "Invalid user-agent profile.", Toast.LENGTH_SHORT).show();
            return;
        }
        boolean saved = prefs.edit().putString(KEY_UA_PROFILE, profile).commit();
        if (!saved) {
            logger.log("ERROR ua profile persistence failed profile=" + profile);
            Toast.makeText(this, "Could not save the user-agent setting.", Toast.LENGTH_LONG).show();
            return;
        }
        webView.getSettings().setUserAgentString(resolveUserAgent(profile));
        logger.log("SETTING ua_profile=" + profile);
        webView.reload();
    }

    private void setTvFocusNavigation(boolean enabled) {
        SharedPreferences.Editor editor = prefs.edit().putBoolean(KEY_TV_FOCUS, enabled);
        if (enabled) {
            editor.putBoolean(KEY_CURSOR_ENABLED, false);
            stopAllCursorDirections();
        }
        boolean saved = editor.commit();
        if (!saved) {
            logger.log("ERROR legacy focus persistence failed");
            Toast.makeText(this, "Could not save Legacy Focus Navigation.", Toast.LENGTH_LONG).show();
            return;
        }
        if (cursorView != null) {
            cursorView.setVisibility(isCursorEnabled() ? View.VISIBLE : View.GONE);
        }
        logger.log("SETTING legacy_focus_navigation=" + enabled);
        if (enabled) {
            injectFocusHighlight();
        }
        Toast.makeText(this, "Legacy Focus Navigation " + (enabled ? "enabled" : "disabled") + ".", Toast.LENGTH_SHORT).show();
    }

    private boolean isCursorEnabled() {
        return prefs.getBoolean(KEY_CURSOR_ENABLED, true);
    }

    private void setCursorEnabled(boolean enabled) {
        SharedPreferences.Editor editor = prefs.edit().putBoolean(KEY_CURSOR_ENABLED, enabled);
        if (enabled) {
            editor.putBoolean(KEY_TV_FOCUS, false);
        }
        boolean saved = editor.commit();
        if (!saved) {
            logger.log("ERROR cursor persistence failed");
            Toast.makeText(this, "Could not save Cursor Navigation.", Toast.LENGTH_LONG).show();
            return;
        }
        if (!enabled) stopAllCursorDirections();
        if (cursorView != null) {
            cursorView.setVisibility(enabled && customView == null ? View.VISIBLE : View.GONE);
        }
        if (enabled) {
            resetCursorToCenter();
        }
        logger.log("SETTING cursor_navigation=" + enabled);
        Toast.makeText(this, "Cursor Navigation " + (enabled ? "enabled" : "disabled") + ".", Toast.LENGTH_SHORT).show();
    }

    private int currentPageZoom() {
        int zoom = prefs.getInt(KEY_PAGE_ZOOM, DEFAULT_PAGE_ZOOM);
        if (zoom < MIN_PAGE_ZOOM || zoom > MAX_PAGE_ZOOM) {
            return DEFAULT_PAGE_ZOOM;
        }
        return zoom;
    }

    private boolean setPageZoom(int percent, boolean reload) {
        if (percent < MIN_PAGE_ZOOM || percent > MAX_PAGE_ZOOM) {
            return false;
        }
        boolean saved = prefs.edit().putInt(KEY_PAGE_ZOOM, percent).commit();
        if (!saved) {
            logger.log("ERROR page zoom persistence failed percent=" + percent);
            if (reload) {
                Toast.makeText(this, "Could not save Page Zoom.", Toast.LENGTH_LONG).show();
            }
            return false;
        }
        if (webView != null) {
            webView.setInitialScale(percent);
            if (reload) {
                webView.reload();
            }
        }
        logger.log("SETTING page_zoom=" + percent);
        return true;
    }

    private void migrateBuild2Settings() {
        if (prefs.getBoolean(KEY_BUILD2_MIGRATED, false)) {
            return;
        }
        boolean saved = prefs.edit()
                .putBoolean(KEY_CURSOR_ENABLED, true)
                .putBoolean(KEY_TV_FOCUS, false)
                .putInt(KEY_PAGE_ZOOM, DEFAULT_PAGE_ZOOM)
                .putBoolean(KEY_BUILD2_MIGRATED, true)
                .commit();
        if (!saved && logger != null) {
            logger.log("WARN Build 2 settings migration persistence failed");
        }
    }

    private String currentUaProfile() {
        String profile = prefs.getString(KEY_UA_PROFILE, UA_ANDROID);
        return isValidUaProfile(profile) ? profile : UA_ANDROID;
    }

    private static boolean isValidUaProfile(String profile) {
        return UA_ANDROID.equals(profile) || UA_WEBVIEW.equals(profile) || UA_DESKTOP.equals(profile);
    }

    private String resolveUserAgent(String profile) {
        String original = WebSettings.getDefaultUserAgent(this);
        if (UA_WEBVIEW.equals(profile)) {
            return original;
        }
        if (UA_DESKTOP.equals(profile)) {
            return "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                    + "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0";
        }

        String sanitized = original
                .replace("; wv", "")
                .replace(" Version/4.0", "")
                .replace("Version/4.0 ", "");
        return sanitized;
    }

    private static String profileLabel(String profile) {
        if (UA_WEBVIEW.equals(profile)) {
            return "Device WebView";
        }
        if (UA_DESKTOP.equals(profile)) {
            return "Desktop Edge";
        }
        return "Android Chrome-compatible";
    }

    private void confirmClearWebData() {
        new AlertDialog.Builder(this)
                .setTitle("Clear DisneyNOW App Web Data?")
                .setMessage("This clears cookies, cache, Web Storage, form data, and HTTP auth saved only inside this app. You may need to sign into your TV provider again.")
                .setPositiveButton("Clear", (dialog, which) -> clearAppWebData())
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void clearAppWebData() {
        CookieManager cookies = CookieManager.getInstance();
        cookies.removeAllCookies(value -> {
            cookies.flush();
            webView.clearCache(true);
            webView.clearHistory();
            webView.clearFormData();
            webView.clearSslPreferences();
            WebStorage.getInstance().deleteAllData();
            WebViewDatabase.getInstance(MainActivity.this).clearHttpAuthUsernamePassword();
            logger.log("WEB_DATA cleared app-local WebView data");
            webView.loadUrl(HOME_URL);
            Toast.makeText(MainActivity.this, "App web data cleared.", Toast.LENGTH_SHORT).show();
        });
    }

    private String buildDiagnostics() {
        StringBuilder out = new StringBuilder();
        out.append("Project: DisneyNOW Fire TV Web Wrapper\n");
        out.append("Version: ").append(versionLabel()).append('\n');
        out.append("Package: ").append(getPackageName()).append('\n');
        out.append("Device: ").append(safeText(Build.MANUFACTURER)).append(' ').append(safeText(Build.MODEL)).append('\n');
        out.append("Android SDK: ").append(Build.VERSION.SDK_INT).append('\n');
        out.append("OS display: ").append(safeText(Build.DISPLAY)).append('\n');
        out.append("WebView: ").append(webViewPackageSummary()).append('\n');
        out.append("UA profile: ").append(profileLabel(currentUaProfile())).append('\n');
        out.append("User agent: ").append(webView.getSettings().getUserAgentString()).append('\n');
        out.append("JavaScript: ").append(webView.getSettings().getJavaScriptEnabled()).append('\n');
        out.append("DOM storage: ").append(webView.getSettings().getDomStorageEnabled()).append('\n');
        out.append("Third-party cookies: enabled for this app WebView\n");
        out.append("Cursor Navigation: ").append(isCursorEnabled()).append('\n');
        out.append("Legacy Focus Navigation: ").append(prefs.getBoolean(KEY_TV_FOCUS, false)).append('\n');
        out.append("Page Zoom: ").append(currentPageZoom()).append("%\n");
        out.append("WebView hardware acceleration: ").append(webView.isHardwareAccelerated()).append('\n');
        out.append("Widevine: ").append(widevineSummary()).append('\n');
        out.append("Home: ").append(HOME_URL).append('\n');
        out.append("Log folder: ").append(logger.getLogDirectory().getAbsolutePath()).append('\n');
        out.append("\nNo passwords, provider tokens, device serials, browsing text, or private input are collected by this diagnostic report.\n");
        return out.toString();
    }

    private String webViewPackageSummary() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            PackageInfo info = WebView.getCurrentWebViewPackage();
            if (info == null) {
                return "unavailable";
            }
            return safeText(info.packageName) + " " + safeText(info.versionName);
        }
        return "package query unavailable below API 26";
    }

    private String widevineSummary() {
        if (!MediaDrm.isCryptoSchemeSupported(WIDEVINE_UUID)) {
            return "not supported";
        }
        MediaDrm drm = null;
        try {
            drm = new MediaDrm(WIDEVINE_UUID);
            String vendor = safeDrmProperty(drm, MediaDrm.PROPERTY_VENDOR);
            String version = safeDrmProperty(drm, MediaDrm.PROPERTY_VERSION);
            String security = safeDrmProperty(drm, "securityLevel");
            return "supported; vendor=" + vendor + "; version=" + version + "; security=" + security;
        } catch (UnsupportedSchemeException | RuntimeException ex) {
            return "reported supported but could not open: " + ex.getClass().getSimpleName();
        } finally {
            if (drm != null) {
                drm.release();
            }
        }
    }

    private static String safeDrmProperty(MediaDrm drm, String key) {
        try {
            String value = drm.getPropertyString(key);
            return value == null || value.trim().isEmpty() ? "unknown" : value.trim();
        } catch (RuntimeException ex) {
            return "unknown";
        }
    }

    private void exportDiagnostics() {
        String diagnostics = buildDiagnostics();
        File folder = new File(appStorageRoot(), "diagnostics");
        if (!folder.exists() && !folder.mkdirs()) {
            Toast.makeText(this, "Could not create the diagnostics folder.", Toast.LENGTH_LONG).show();
            logger.log("ERROR diagnostics folder create failed");
            return;
        }
        String stamp = new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date());
        File file = new File(folder, "DisneyNOWFireTV-Diagnostics-" + stamp + ".txt");
        if (writeUtf8(file, diagnostics)) {
            logger.log("DIAGNOSTICS exported file=" + file.getName());
            showTextDialog("Diagnostic Report Exported", "Saved to:\n" + file.getAbsolutePath());
        } else {
            logger.log("ERROR diagnostics export failed");
            Toast.makeText(this, "Diagnostic export failed.", Toast.LENGTH_LONG).show();
        }
    }

    private void runSafeSelfTest() {
        List<TestResult> results = new ArrayList<>();

        addResult(results, "Project package identity",
                EXPECTED_PACKAGE_ID.equals(getPackageName()),
                "expected=" + EXPECTED_PACKAGE_ID + " actual=" + getPackageName());

        boolean versionOk = "0.1".equals(BuildConfig.VERSION_NAME) && BuildConfig.APP_BUILD == 6 && BuildConfig.VERSION_CODE == 6;
        addResult(results, "Version + Build identity", versionOk,
                "versionName=" + BuildConfig.VERSION_NAME + " versionCode=" + BuildConfig.VERSION_CODE + " Build=" + BuildConfig.APP_BUILD);

        String tempKey = "__selftest_" + System.nanoTime();
        String tempValue = "write-reload-compare";
        boolean settingWritten = prefs.edit().putString(tempKey, tempValue).commit();
        SharedPreferences reloadedPrefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean settingMatches = settingWritten && tempValue.equals(reloadedPrefs.getString(tempKey, null));
        boolean settingCleaned = reloadedPrefs.edit().remove(tempKey).commit();
        addResult(results, "Settings persistence write -> reload/read -> compare -> delete",
                settingMatches && settingCleaned,
                "write=" + settingWritten + " compare=" + settingMatches + " cleanup=" + settingCleaned);

        boolean webSettingsOk = webView.getSettings().getJavaScriptEnabled()
                && webView.getSettings().getDomStorageEnabled()
                && !webView.getSettings().getAllowFileAccess()
                && !webView.getSettings().getAllowContentAccess()
                && CookieManager.getInstance().acceptCookie();
        addResult(results, "WebView production settings", webSettingsOk,
                "JavaScript/DOM enabled; file/content access disabled; cookies accepted");

        String ua = webView.getSettings().getUserAgentString();
        boolean uaOk = ua != null && !ua.trim().isEmpty() && isValidUaProfile(currentUaProfile());
        addResult(results, "User-agent production path", uaOk,
                "profile=" + currentUaProfile() + " uaLength=" + (ua == null ? 0 : ua.length()));

        addResult(results, "Hardware-accelerated WebView runtime", webView.isHardwareAccelerated(),
                "isHardwareAccelerated=" + webView.isHardwareAccelerated());

        boolean cursorStateOk = cursorView != null
                && ((isCursorEnabled() && cursorView.getVisibility() == View.VISIBLE)
                || (!isCursorEnabled() && cursorView.getVisibility() != View.VISIBLE));
        addResult(results, "Cursor visibility matches navigation setting", cursorStateOk,
                "enabled=" + isCursorEnabled() + " visibility=" + (cursorView == null ? -1 : cursorView.getVisibility()));

        ensureCursorPosition();
        float beforeX = cursorX;
        float beforeY = cursorY;
        if (isCursorEnabled() && webView.getWidth() > dp(160)) {
            moveCursor(KeyEvent.KEYCODE_DPAD_RIGHT, 0);
            boolean cursorMoved = cursorX > beforeX || (beforeX >= webView.getWidth() - cursorView.cursorRadius());
            cursorX = beforeX;
            cursorY = beforeY;
            cursorView.setCursorPosition(cursorX, cursorY);
            addResult(results, "Native cursor production movement path", cursorMoved,
                    "beforeX=" + beforeX + " after/restoreX=" + cursorX);
        } else {
            results.add(TestResult.skipped("Native cursor production movement path",
                    "Cursor mode is disabled or WebView geometry is not ready; no page click is performed by Safe Self-Test."));
        }

        if (isCursorEnabled() && webView.getWidth() > dp(160)) {
            ensureCursorPosition();
            float dispatchBeforeX = cursorX;
            float dispatchBeforeY = cursorY;
            long now = android.os.SystemClock.uptimeMillis();
            boolean dispatchConsumed = dispatchKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DPAD_RIGHT, 0));
            boolean dispatchMoved = cursorX > dispatchBeforeX || (dispatchBeforeX >= webView.getWidth() - cursorView.cursorRadius());
            boolean upConsumed = dispatchKeyEvent(new KeyEvent(now, now + 1L, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_DPAD_RIGHT, 0));
            cursorX = dispatchBeforeX;
            cursorY = dispatchBeforeY;
            cursorView.setCursorPosition(cursorX, cursorY);
            addResult(results, "Activity pre-WebView D-pad dispatch interception",
                    dispatchConsumed && dispatchMoved && upConsumed,
                    "downConsumed=" + dispatchConsumed + " moved=" + dispatchMoved + " upConsumed=" + upConsumed);
        } else {
            results.add(TestResult.skipped("Activity pre-WebView D-pad dispatch interception",
                    "Cursor mode is disabled or WebView geometry is not ready; no page click is performed by Safe Self-Test."));
        }

        int originalZoom = currentPageZoom();
        boolean zoomMinSet = setPageZoom(MIN_PAGE_ZOOM, false);
        SharedPreferences zoomMinReload = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean zoomMinReloaded = zoomMinSet && zoomMinReload.getInt(KEY_PAGE_ZOOM, -1) == MIN_PAGE_ZOOM;
        boolean zoomMaxSet = setPageZoom(MAX_PAGE_ZOOM, false);
        SharedPreferences zoomMaxReload = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean zoomMaxReloaded = zoomMaxSet && zoomMaxReload.getInt(KEY_PAGE_ZOOM, -1) == MAX_PAGE_ZOOM;
        boolean invalidLowRejected = !setPageZoom(MIN_PAGE_ZOOM - 1, false);
        boolean invalidHighRejected = !setPageZoom(MAX_PAGE_ZOOM + 1, false);
        boolean zoomRestored = setPageZoom(originalZoom, false);
        addResult(results, "Page Zoom 0-500 production boundary + persistence write -> reload/read -> compare -> restore",
                zoomMinReloaded && zoomMaxReloaded && invalidLowRejected && invalidHighRejected && zoomRestored && currentPageZoom() == originalZoom,
                "min=" + zoomMinReloaded + " max=" + zoomMaxReloaded + " invalidLow=" + invalidLowRejected + " invalidHigh=" + invalidHighRejected + " restored=" + zoomRestored);

        if (customView == null && customViewContainer != null && webView != null) {
            View testFullscreenView = new View(this);
            final boolean[] callbackCalled = new boolean[]{false};
            DisneyWebChromeClient testChrome = new DisneyWebChromeClient();
            testChrome.onShowCustomView(testFullscreenView, () -> callbackCalled[0] = true);
            boolean fullscreenOverlayOk = customView == testFullscreenView
                    && customViewContainer.getVisibility() == View.VISIBLE
                    && webView.getVisibility() == View.VISIBLE;
            testChrome.onHideCustomView();
            boolean fullscreenRestored = customView == null
                    && customViewContainer.getVisibility() == View.GONE
                    && webView.getVisibility() == View.VISIBLE
                    && callbackCalled[0];
            addResult(results, "Fullscreen overlay compositor production path",
                    fullscreenOverlayOk && fullscreenRestored,
                    "overlay=" + fullscreenOverlayOk + " restored=" + fullscreenRestored + " callback=" + callbackCalled[0]);
        } else {
            results.add(TestResult.skipped("Fullscreen overlay compositor production path",
                    "A real fullscreen custom view is already active or required views are unavailable; Safe Self-Test will not interrupt it."));
        }

        File internalTest = new File(getFilesDir(), "selftest.tmp");
        boolean internalRoundTrip = writeReadCompareDelete(internalTest, "DisneyNOWFireTV-selftest");
        addResult(results, "Project data write -> reload/read -> compare -> delete", internalRoundTrip,
                internalTest.getAbsolutePath());

        File externalRoot = getExternalFilesDir(null);
        if (externalRoot == null) {
            results.add(TestResult.skipped("App-specific external diagnostics storage", "External app-specific storage is unavailable on this device."));
        } else {
            File externalTest = new File(externalRoot, "selftest-external.tmp");
            boolean externalRoundTrip = writeReadCompareDelete(externalTest, "diagnostic-storage-selftest");
            addResult(results, "App-specific diagnostic storage write -> reload/read -> compare -> delete", externalRoundTrip,
                    externalTest.getAbsolutePath());
        }

        boolean widevineSupported = MediaDrm.isCryptoSchemeSupported(WIDEVINE_UUID);
        addResult(results, "Widevine DRM scheme availability", widevineSupported,
                widevineSupported ? widevineSummary() : "Widevine is unavailable; protected Disney playback is unlikely to work.");

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            PackageInfo packageInfo = WebView.getCurrentWebViewPackage();
            addResult(results, "WebView runtime package detection", packageInfo != null,
                    packageInfo == null ? "No current WebView package reported." : safeText(packageInfo.packageName) + " " + safeText(packageInfo.versionName));
        } else {
            results.add(TestResult.skipped("WebView runtime package detection", "Android API is below 26; this package-query API is unavailable."));
        }

        boolean homeUrlOk = HOME_URL.startsWith("https://") && "disneynow.com".equalsIgnoreCase(Uri.parse(HOME_URL).getHost());
        addResult(results, "DisneyNOW home URL safety invariant", homeUrlOk, HOME_URL);

        results.add(TestResult.skipped(
                "Live DisneyNOW authentication + protected video playback",
                "Requires the user's real provider session, Disney servers, device DRM negotiation, and an interactive Fire TV playback check."
        ));
        results.add(TestResult.skipped(
                "Physical Fire TV cursor/click navigation and fullscreen video",
                "Requires actual Fire TV hardware interaction; Safe Self-Test moves the cursor through production code but cannot physically press the remote, click Disney controls, or play protected content."
        ));

        String report = formatSelfTestReport(results);
        File folder = new File(appStorageRoot(), "selftest");
        boolean folderReady = folder.exists() || folder.mkdirs();
        File reportFile = new File(folder, "SafeSelfTest-v0.1-Build6.txt");
        boolean reportSaved = folderReady && writeUtf8(reportFile, report);
        logger.log("SELF_TEST complete " + selfTestTotals(results) + " reportSaved=" + reportSaved);

        String shown = report + "\nReport saved: " + (reportSaved ? reportFile.getAbsolutePath() : "FAILED TO SAVE");
        showTextDialog("Safe Self-Test — " + versionLabel(), shown);
    }

    private static void addResult(List<TestResult> results, String name, boolean pass, String detail) {
        results.add(pass ? TestResult.pass(name, detail) : TestResult.fail(name, detail));
    }

    private String formatSelfTestReport(List<TestResult> results) {
        StringBuilder out = new StringBuilder();
        out.append("DisneyNOW Fire TV Web Wrapper SAFE SELF-TEST\n");
        out.append("Version: ").append(versionLabel()).append('\n');
        out.append("Package: ").append(getPackageName()).append('\n');
        out.append("Device: ").append(safeText(Build.MANUFACTURER)).append(' ').append(safeText(Build.MODEL)).append('\n');
        out.append("Android SDK: ").append(Build.VERSION.SDK_INT).append("\n\n");

        int index = 1;
        for (TestResult result : results) {
            out.append(index++)
                    .append(". ")
                    .append(result.status)
                    .append(" - ")
                    .append(result.name)
                    .append(" | ")
                    .append(result.detail)
                    .append('\n');
        }
        out.append("\nTOTALS: ").append(selfTestTotals(results)).append('\n');
        out.append("\nBuild remains NOT DONE until the SKIPPED Fire TV playback/remote checks are physically completed and any failures are resolved.\n");
        return out.toString();
    }

    private static String selfTestTotals(List<TestResult> results) {
        int pass = 0;
        int fail = 0;
        int skipped = 0;
        for (TestResult result : results) {
            if ("PASS".equals(result.status)) {
                pass++;
            } else if ("FAIL".equals(result.status)) {
                fail++;
            } else {
                skipped++;
            }
        }
        return "PASS=" + pass + " FAIL=" + fail + " SKIPPED/NOT TESTED=" + skipped;
    }

    private boolean writeReadCompareDelete(File file, String value) {
        boolean write = writeUtf8(file, value);
        String loaded = write ? readUtf8(file) : null;
        boolean compare = value.equals(loaded);
        boolean deleted = !file.exists() || file.delete();
        return write && compare && deleted;
    }

    private static boolean writeUtf8(File file, String value) {
        try (FileOutputStream out = new FileOutputStream(file, false)) {
            out.write(value.getBytes(StandardCharsets.UTF_8));
            out.flush();
            return true;
        } catch (Exception ex) {
            return false;
        }
    }

    private static String readUtf8(File file) {
        StringBuilder out = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            char[] buffer = new char[2048];
            int count;
            while ((count = reader.read(buffer)) != -1) {
                out.append(buffer, 0, count);
            }
            return out.toString();
        } catch (Exception ex) {
            return null;
        }
    }

    private File appStorageRoot() {
        File external = getExternalFilesDir(null);
        return external != null ? external : getFilesDir();
    }

    private void showAbout() {
        String text = "DisneyNOW Fire TV Web Wrapper\n"
                + versionLabel() + "\n\n"
                + "Unofficial personal-use compatibility wrapper. Not affiliated with or endorsed by Disney.\n\n"
                + "The app loads disneynow.com directly and uses Disney's normal website, provider authentication, video player, and DRM. It does not bypass DRM or unlock content.\n\n"
                + "Build 6 preserves the proven Build 5 smooth cursor, adds fully custom 0-500% Page Zoom controls, removes the forced offscreen WebView hardware layer so Fire TV video surfaces can use their native compositor path, keeps the WebView alive behind fullscreen video, and prevents duplicate popup/login routing. Build 6 preserves the permanent release-signing identity for in-place updates and remains NOT DONE until ad/protected video and login are retested on the actual Fire TV Stick.";
        showTextDialog("About", text);
    }

    private void showTextDialog(String title, String text) {
        ScrollView scroll = new ScrollView(this);
        TextView textView = new TextView(this);
        int pad = dp(20);
        textView.setPadding(pad, pad, pad, pad);
        textView.setTextColor(Color.WHITE);
        textView.setTextSize(16f);
        textView.setTextIsSelectable(true);
        textView.setText(text);
        scroll.addView(textView);

        new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(scroll)
                .setPositiveButton("Close", null)
                .show();
    }

    private int dp(int value) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(value * density);
    }

    private String versionLabel() {
        return "v" + BuildConfig.VERSION_NAME + " Build " + BuildConfig.APP_BUILD;
    }

    private void enterImmersiveMode() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            enterImmersiveMode();
        }
    }

    @Override
    public void onBackPressed() {
        if (customView != null) {
            hideCustomView();
            return;
        }
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
            return;
        }
        logger.log("EXIT back");
        super.onBackPressed();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.onResume();
        }
        if (customView != null && customViewContainer != null) {
            customViewContainer.setVisibility(View.VISIBLE);
            customViewContainer.bringToFront();
            customView.requestFocus();
        }
        enterImmersiveMode();
    }

    @Override
    protected void onPause() {
        stopAllCursorDirections();
        if (webView != null) {
            webView.onPause();
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        stopAllCursorDirections();
        if (webView != null) {
            root.removeView(webView);
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
            webView = null;
        }
        cursorView = null;
        logger.log("STOP version=" + versionLabel());
        super.onDestroy();
    }

    private static String safeHost(String url) {
        if (url == null) {
            return "unknown";
        }
        try {
            return safeHost(Uri.parse(url));
        } catch (RuntimeException ex) {
            return "unknown";
        }
    }

    private static String safeHost(Uri uri) {
        if (uri == null || uri.getHost() == null) {
            return "unknown";
        }
        return uri.getHost();
    }

    private static String safeText(String value) {
        if (value == null || value.trim().isEmpty()) {
            return "unknown";
        }
        return value.replace('\n', ' ').replace('\r', ' ').trim();
    }

    private final class CursorView extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint cross = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float x;
        private float y;
        private long pulseUntil;

        CursorView(Context context) {
            super(context);
            setFocusable(false);
            setClickable(false);
            fill.setStyle(Paint.Style.FILL);
            fill.setColor(Color.WHITE);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(dp(3));
            stroke.setColor(Color.BLACK);
            cross.setStyle(Paint.Style.STROKE);
            cross.setStrokeWidth(dp(2));
            cross.setColor(Color.BLACK);
        }

        float cursorRadius() {
            return dp(16);
        }

        void setCursorPosition(float newX, float newY) {
            x = newX;
            y = newY;
            invalidate();
        }

        void showClickPulse() {
            pulseUntil = android.os.SystemClock.uptimeMillis() + 120L;
            invalidate();
            postDelayed(this::invalidate, 130L);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float radius = cursorRadius();
            if (android.os.SystemClock.uptimeMillis() < pulseUntil) {
                radius *= 1.35f;
            }
            canvas.drawCircle(x, y, radius, fill);
            canvas.drawCircle(x, y, radius, stroke);
            float arm = radius * 0.55f;
            canvas.drawLine(x - arm, y, x + arm, y, cross);
            canvas.drawLine(x, y - arm, x, y + arm, cross);
        }
    }

    private static final class TestResult {
        final String status;
        final String name;
        final String detail;

        private TestResult(String status, String name, String detail) {
            this.status = status;
            this.name = name;
            this.detail = detail;
        }

        static TestResult pass(String name, String detail) {
            return new TestResult("PASS", name, detail);
        }

        static TestResult fail(String name, String detail) {
            return new TestResult("FAIL", name, detail);
        }

        static TestResult skipped(String name, String detail) {
            return new TestResult("SKIPPED/NOT TESTED", name, detail);
        }
    }

    private static final class AppLogger {
        private static final long MAX_BYTES = 1024L * 1024L;
        private static final int MAX_FILES = 5;
        private final File logDir;

        AppLogger(Context context) {
            File external = context.getExternalFilesDir(null);
            File root = external != null ? external : context.getFilesDir();
            logDir = new File(root, "logs");
            if (!logDir.exists()) {
                //noinspection ResultOfMethodCallIgnored
                logDir.mkdirs();
            }
        }

        File getLogDirectory() {
            return logDir;
        }

        synchronized void log(String message) {
            try {
                rotateIfNeeded();
                File current = new File(logDir, "app-0.log");
                String stamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(new Date());
                String line = stamp + " | " + safeText(message) + "\n";
                try (FileOutputStream out = new FileOutputStream(current, true)) {
                    out.write(line.getBytes(StandardCharsets.UTF_8));
                    out.flush();
                }
            } catch (Exception ignored) {
                // Logging must never break normal app behavior.
            }
        }

        private void rotateIfNeeded() {
            File current = new File(logDir, "app-0.log");
            if (!current.exists() || current.length() < MAX_BYTES) {
                return;
            }
            File oldest = new File(logDir, "app-" + (MAX_FILES - 1) + ".log");
            if (oldest.exists()) {
                //noinspection ResultOfMethodCallIgnored
                oldest.delete();
            }
            for (int i = MAX_FILES - 2; i >= 0; i--) {
                File from = new File(logDir, "app-" + i + ".log");
                File to = new File(logDir, "app-" + (i + 1) + ".log");
                if (from.exists()) {
                    //noinspection ResultOfMethodCallIgnored
                    from.renameTo(to);
                }
            }
        }
    }
}
