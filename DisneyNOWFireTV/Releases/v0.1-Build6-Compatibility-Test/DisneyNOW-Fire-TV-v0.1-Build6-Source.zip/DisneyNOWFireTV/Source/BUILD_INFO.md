# Build information

- Project: DisneyNOW Fire TV Web Wrapper
- Version: 0.1
- Build: 6
- Android versionCode: 6
- Package ID: `com.fireworkstars46.disneynowfiretv`
- Release state: NOT DONE pending physical Fire TV ad/protected-video and provider-login retesting.

Build 6 preserves Build 5 smooth cursor input, expands Page Zoom to a custom 0-500 range, changes WebView/fullscreen compositor handling to address black video with audio, and makes popup/login routing one-shot to avoid duplicate navigation glitches. Permanent signing identity and update compatibility are preserved.
