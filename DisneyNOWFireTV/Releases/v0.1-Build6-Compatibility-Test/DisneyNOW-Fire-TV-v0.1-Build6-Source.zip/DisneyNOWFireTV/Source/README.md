# Source — DisneyNOW Fire TV Web Wrapper v0.1 Build 6

Build 6 preserves the Build 5 smooth cursor behavior and targets the real Fire TV playback/login issues reported after Build 5. Page Zoom is now fully custom from 0 through 500 percent with direct numeric entry, a 0-500 slider, -1/+1 controls, and Reset 100%; 0 uses WebView automatic scale. Existing saved zoom values remain valid and are not reset.

For video, the app keeps Android application/window hardware acceleration but no longer forces the WebView into an offscreen hardware layer, allowing WebView/SurfaceView to choose the native compositor path. Fullscreen custom video now overlays the still-attached WebView instead of hiding it, which preserves the underlying playback/compositor context.

For login/navigation stability, popup WebViews mirror the main security/user-agent settings, flush cookies, and route a popup URL into the main WebView at most once so the previous duplicate route/destroy path cannot fire twice during one popup.

Package ID, Version 0.1, app data/settings, Build 5 cursor behavior, cookie acceptance, DisneyNOW authentication path, and the permanent Build 3+ signing identity are preserved. Build 6 remains NOT DONE - COMPATIBILITY TEST until physical Fire TV ad/protected-video rendering and provider-login stability are retested.
