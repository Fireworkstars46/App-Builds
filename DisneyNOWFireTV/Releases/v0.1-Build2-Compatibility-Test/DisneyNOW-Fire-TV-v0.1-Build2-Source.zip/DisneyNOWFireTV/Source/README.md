# Source — DisneyNOW Fire TV Web Wrapper v0.1 Build 2

This is an Android/Fire TV WebView wrapper intended to use the normal DisneyNOW website on a Fire TV Stick.

## Build 2 corrections

Build 2 fixes the three issues reported from real Fire TV testing of Build 1:

- **Laggy D-pad navigation:** the default path is now a lightweight native cursor overlay instead of running a full DOM focus scan on every D-pad press. The legacy focus helper remains available as an optional fallback.
- **No cursor:** a visible on-screen cursor is enabled by default. D-pad moves it, Center/Enter clicks the underlying WebView at the cursor position, and reaching the top/bottom edge scrolls the page.
- **Page too zoomed in:** Page Zoom is now a persisted app setting with 75% as the recommended/default value and selectable 50%, 60%, 70%, 75%, 80%, 90%, and 100% presets.

## Design and safety

- Package ID remains `com.fireworkstars46.disneynowfiretv`.
- Only the `INTERNET` permission is requested.
- No Disney content or artwork is bundled.
- No DRM bypass, credential interception, ad blocking, or provider-token logging.
- JavaScript and DOM storage are enabled because DisneyNOW requires a modern browser environment.
- Third-party cookies are enabled inside the app WebView because TV-provider authentication may rely on cross-site cookies.
- Local file/content access and cleartext HTTP are disabled.
- WebView remote debugging is disabled.
- Hardware acceleration is explicitly enabled for the app and WebView.
- Fire TV Menu button exposes app controls.
- Cursor Navigation is the default; Legacy Focus Navigation is retained as an optional mutually-exclusive fallback.
- Fullscreen WebView video callbacks are implemented; the cursor hides during fullscreen playback.
- Safe Self-Test exercises project identity, Version+Build, settings persistence, project-file persistence, WebView configuration, UA state, hardware acceleration, cursor state/movement, Page Zoom persistence/restore, app-specific diagnostic storage, Widevine availability, and WebView runtime detection. Real Disney playback and physical remote click behavior remain explicitly SKIPPED until tested on the Fire TV hardware.

## Signing / installation note

Build 1 and Build 2 compatibility-test APKs use CI debug signing. A GitHub-hosted runner can generate a different debug signing key between builds, so Android may require Build 1 to be uninstalled before Build 2 installs. A stable private release-signing key must be established before a final update-compatible DONE release.
