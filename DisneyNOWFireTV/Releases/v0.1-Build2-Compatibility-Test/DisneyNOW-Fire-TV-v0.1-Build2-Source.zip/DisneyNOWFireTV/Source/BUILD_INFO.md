# Build information

- Project: DisneyNOW Fire TV Web Wrapper
- Version: 0.1
- Build: 2
- Android versionCode: 2
- Package ID: `com.fireworkstars46.disneynowfiretv`
- Minimum SDK: 22 (Android 5.1 / Fire OS 5-era compatibility target)
- Target SDK: 35
- Distribution: personal sideload compatibility test
- Release state: NOT DONE pending real Fire TV runtime verification of the Build 2 cursor, zoom, smoothness, provider authentication, and protected playback.

Build 2 is the corrective build for the user's three reproducible Build 1 issues: laggy D-pad navigation, no visible cursor, and an overly zoomed-in page. It preserves the package ID, web-data/settings location, Disney authentication path, and DRM behavior.

This build follows the repository's current `MASTER_RULES.md` as of source creation. The release workflow records the exact master-rules SHA-256 used at build time.
