# Source — DisneyNOW Fire TV Hybrid TV Shell v0.1 Build 9

Build 9 is a diagnostic-focused update to Build 8. It preserves the native-TV hybrid architecture, package/update identity, WebView browsing/provider flow, Native TV Navigation default, compatibility cursor, Performance Mode, whole-WebView Page Zoom, experimental Media3 HLS/DASH/Widevine path, and Silk fallback.

Changes in Build 9:
- **Debug Mode (OFF by default):** a new app-menu toggle enables additional privacy-safe troubleshooting events without enabling Android/WebView remote debugging.
- **Debug Snapshot:** shows host-level WebView/HTTP error counts, last safe error codes/status, last page-load time, Media3 state/error code, HLS/DASH and DRM-candidate counts, navigation/performance/zoom state, D-pad dispatch timing, and Java heap usage.
- **Export Debug Report:** writes diagnostics + debug snapshot + the recent bounded privacy-safe app log to the app-specific external-files directory.
- **Lag diagnostics:** while Debug Mode is enabled, D-pad dispatch time is measured as aggregate count/average/max timing; raw typed text is never captured.
- **Playback diagnostics:** Media3 playback state and safe error code/class are logged in Debug Mode. Full media/license URLs, cookies, authorization headers, provider tokens, and DRM responses are never exported.
- **Bounded logging retained:** at most 5 rotating app logs of about 1 MiB each.
- **Security boundary retained:** `WebView.setWebContentsDebuggingEnabled(false)` remains enforced; no DRM keys are extracted, no entitlements/tokens/licenses are forged, and no DRM is bypassed.
- **Build 8 behavior preserved:** Native TV Navigation, Performance Mode, Page Zoom 0-500, experimental authenticated-session Media3 playback, and Silk fallback remain available.

Preserved Build 8 architecture details:
- **Whole-page Page Zoom 0-500:** continues to use Android WebView-level scaling rather than CSS document-only zoom.
- **Experimental native playback:** continues to use AndroidX Media3/ExoPlayer for legitimately observed authenticated-session HLS/DASH requests, with Android Widevine when a matching legitimate license request is observed.
- **Media3 compatibility:** remains pinned to Media3 `1.8.1` to preserve the existing `minSdk 22` compatibility floor.
- The project does not copy Disney proprietary code, credentials, entitlement logic, DRM keys, or authentication secrets.

Build 9 remains **NOT DONE - COMPATIBILITY TEST** until the Fire TV hardware test confirms the debug menu/report works and the captured report is used to diagnose the remaining lag/playback error.
