# Build information

- Project: DisneyNOW Fire TV Hybrid TV Shell
- Version: 0.1
- Build: 9
- Android versionCode: 9
- Package ID: `com.fireworkstars46.disneynowfiretv`
- Release state: NOT DONE pending physical Fire TV testing of navigation responsiveness, whole-page zoom, provider login, WebView playback, experimental native Media3 playback/Widevine negotiation, ads/program video, Silk fallback, and the new privacy-safe Debug Mode/reporting path.

Build 9 preserves Build 8's native-TV hybrid architecture and adds an optional Debug Mode specifically for diagnosing the reported Fire TV lag and playback errors. Debug Mode is OFF by default and records only privacy-safe troubleshooting data: host-level WebView/HTTP errors, page-load timing, Media3 state/error codes, media/DRM candidate counts, D-pad dispatch timing, memory status, and existing safe app events. Exported debug reports deliberately exclude passwords, cookies, authorization headers, provider tokens, full media/license URLs, query strings, device serials, and typed text. WebView remote debugging remains disabled. The package ID, app-local data/settings/cookies, Media3/Widevine rights boundary, and permanent release-signing identity remain unchanged.
