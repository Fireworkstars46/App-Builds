# Source — DisneyNOW Fire TV Hybrid TV Shell v0.1 Build 14

Build 14 is a corrective stability rollback based on the physical Build 11 test. It preserves the package/update identity, WebView/provider flow, Native TV Navigation, compatibility cursor, Performance Mode, whole-WebView Page Zoom, privacy-safe Debug Mode, the dormant experimental Media3 HLS/DASH/Widevine implementation, and Silk fallback.

Changes in Build 14:
- **Automatic Media3 launch disabled:** normal DisneyNOW use no longer creates/starts the native player when HLS/DASH manifests are observed. This directly rolls back the unstable Build 11 automatic handoff that became glitchy/finicky and was followed by an app restart/crash on the physical Fire TV.
- **Media observation remains diagnostic-only:** HLS/DASH host/type and the existing safe request-context indicators can still appear in Debug Mode/reporting, but observing a manifest does not hijack playback.
- **Persistent crash-stage evidence:** Build 14 stores a tiny project-owned marker containing only a controlled runtime stage, safe stage detail, timestamp, and exception class chain. The next launch/report can say that the prior run lacked a clean-shutdown marker and show the last recorded safe stage.
- **Uncaught Java crash capture:** before delegating to Android's normal crash handler, Build 14 records exception class names only. It does not store exception messages, stack traces, URLs, cookies, tokens, request bodies, typed text, or private browsing input.
- **Low-frequency persistence:** crash-stage writes occur only at major transitions such as startup, page start/finish, first manifest observation per page, fullscreen WebView video entry, uncaught exception, and clean shutdown. They are not written for every request/frame.
- **Safe Self-Test regression coverage:** the automatic-launch-disabled invariant is tested, and the production crash-state persistence helper is exercised using isolated temporary SharedPreferences with write -> reload/read -> compare -> delete.
- **Build 10/11 diagnostics retained where safe:** page-load timing, D-pad timing, WebView/HTTP errors, manifest/DRM counters, Media3 counters/state if the dormant path is ever invoked in a future diagnostic build, possible post-manifest non-GET host/type hints, and bounded logs remain available.
- **Security boundary retained:** `WebView.setWebContentsDebuggingEnabled(false)` remains enforced; no DRM keys are extracted, no entitlement/token/license is forged, no DRM is bypassed, and no proprietary Disney player/auth code is copied. The dormant native path only uses legitimately observed authenticated-session media/DRM request information.

Preserved architecture details:
- **Whole-page Page Zoom 0-500:** Android WebView-level scaling, not CSS-only zoom.
- **Dormant experimental native playback code:** AndroidX Media3/ExoPlayer remains in source for controlled future diagnostics, but Build 14 does not automatically invoke it during normal use.
- **Media3 compatibility:** pinned to Media3 `1.8.1` for the existing `minSdk 22` Fire TV compatibility floor.
- **Update compatibility:** package ID and permanent release signer are unchanged. Install Build 14 over Build 11; do not uninstall.

Build 14 remains **NOT DONE - COMPATIBILITY TEST** until a physical Fire TV test verifies that the Build 11 crash/glitch regression is gone, normal WebView/provider behavior remains usable, and the new previous-run crash-stage evidence appears correctly if an unexpected restart occurs.


## Build 14 input-lag correction
Build 14 keeps the stable no-auto-native playback behavior and adds an 85 ms Native TV directional-repeat guard to reduce remote key-repeat backlog in the WebView input path. Initial presses and releases, Select/Menu/Back, Cursor Navigation, Legacy Focus Navigation, crash breadcrumbs, Performance Mode, zoom, and Silk fallback are preserved. Debug reports include suppressed-repeat and >=100 ms dispatch counts for physical comparison.
