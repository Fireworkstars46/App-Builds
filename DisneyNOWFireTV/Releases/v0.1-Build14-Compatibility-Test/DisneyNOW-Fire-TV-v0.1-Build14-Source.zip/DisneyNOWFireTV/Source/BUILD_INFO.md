# Build information

- Project: DisneyNOW Fire TV Hybrid TV Shell
- Version: 0.1
- Build: 13
- Android versionCode: 13
- Package ID: `com.fireworkstars46.disneynowfiretv`
- Release state: NOT DONE pending physical Fire TV testing of stability after the Build 11 crash regression, WebView playback, navigation responsiveness, provider login, whole-page zoom, Silk fallback, Debug Mode/reporting, and previous-run crash-stage evidence.

Build 14 is a corrective stability rollback based on the physical Build 11 report and debug log. Build 11 proved that Media3 could reach READY and `isPlaying=true` with the observed DisneyNOW HLS stream, but the app later became glitchy/finicky and restarted without a captured Java/Media3 error. Build 14 therefore disconnects automatic Media3 launch from normal DisneyNOW use. HLS/DASH observation remains available for privacy-safe diagnostics, but no automatic native player is created or started from those observations.

Build 14 also adds bounded persistent runtime/crash-stage evidence. A small internal marker records only controlled stage names and safe details such as host/type/load timing plus exception class chains (never exception messages). On the next launch, Debug Snapshot/export can report whether the previous run ended without a clean shutdown marker and which safe stage was last persisted. An uncaught-Java-exception handler records class names only before delegating to Android's normal crash handler. The Safe Self-Test exercises the same persistence helper using isolated temporary SharedPreferences and deletes the test data afterward.

The package ID, app data/settings/cookies, minSdk 22 compatibility floor, Media3 1.8.1 pin, WebView remote-debugging prohibition, DRM/entitlement safety boundary, Silk fallback, and permanent release-signing identity remain unchanged. Install Build 14 directly over Build 11; do not uninstall.


## Build 14 lag/stability correction
- Native TV Navigation suppresses only rapid repeated directional ACTION_DOWN events inside an 85 ms guard window; initial directional presses and ACTION_UP still pass through.
- Adds privacy-safe counters for suppressed repeats and dispatches taking at least 100 ms.
- Automatic native Media3 launch remains disabled; crash-stage breadcrumbs and existing compatibility settings remain preserved.
