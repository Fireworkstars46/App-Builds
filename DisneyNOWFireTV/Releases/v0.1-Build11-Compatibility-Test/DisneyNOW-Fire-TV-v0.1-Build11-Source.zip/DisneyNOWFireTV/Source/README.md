# Source — DisneyNOW Fire TV Hybrid TV Shell v0.1 Build 11

Build 11 is a targeted usability/corrective update based on the physical Build 10 debug report. It preserves the package/update identity, WebView/provider flow, Native TV Navigation, compatibility cursor, Performance Mode, whole-WebView Page Zoom, privacy-safe Debug Mode, experimental Media3 HLS/DASH/Widevine path, and Silk fallback.

Changes in Build 11:
- **Automatic native handoff:** after a legitimate authenticated-session HLS/DASH manifest is observed, repeated manifest events are debounced and Media3 is tried automatically once for that page.
- **No manual normal-use handoff step:** the confusing `Try Native Player` menu item and stream-ready instruction are removed from the normal menu flow.
- **Automatic fallback:** Media3 player/setup errors immediately restore the normal DisneyNOW WebView player. A bounded 20-second startup watchdog also restores WebView if native playback never begins.
- **Debug-only handoff detail:** automatic schedule/attempt/playback-start state and the existing privacy-safe handoff stage/counters remain available in Debug Snapshot/export.
- **Build 10 diagnostics retained:** safe manifest host/type, header-presence booleans, possible post-manifest non-GET host/type hints, Media3 error codes/class chains, page-load timing, D-pad timing, and bounded logs remain available.
- **Security boundary retained:** `WebView.setWebContentsDebuggingEnabled(false)` remains enforced; no DRM keys are extracted, no entitlement/token/license is forged, and no DRM is bypassed.

Preserved architecture details:
- **Whole-page Page Zoom 0-500:** Android WebView-level scaling, not CSS-only zoom.
- **Experimental native playback:** AndroidX Media3/ExoPlayer uses only legitimately observed authenticated-session HLS/DASH requests and Android Widevine when a matching legitimate license request is observed.
- **Media3 compatibility:** pinned to Media3 `1.8.1` for the existing `minSdk 22` Fire TV compatibility floor.
- **Update compatibility:** package ID and permanent release signer are unchanged. Install Build 11 over Build 10; do not uninstall.

Build 11 remains **NOT DONE - COMPATIBILITY TEST** until a physical Fire TV test verifies the automatic handoff/fallback path and exports a resulting Debug Report.
