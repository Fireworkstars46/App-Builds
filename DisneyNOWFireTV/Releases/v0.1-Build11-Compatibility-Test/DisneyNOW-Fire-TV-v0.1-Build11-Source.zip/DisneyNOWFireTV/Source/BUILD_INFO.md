# Build information

- Project: DisneyNOW Fire TV Hybrid TV Shell
- Version: 0.1
- Build: 11
- Android versionCode: 11
- Package ID: `com.fireworkstars46.disneynowfiretv`
- Release state: NOT DONE pending physical Fire TV testing of automatic native-player handoff/fallback, WebView/native playback, Widevine negotiation, navigation responsiveness, provider login, ads/program video, whole-page zoom, Silk fallback, and Debug Mode/reporting.

Build 11 is a targeted usability/corrective update based on the physical Build 10 report. Build 10 proved that authenticated-session HLS manifests were repeatedly detected and marked manifest-ready, but the handoff counters still showed zero native attempts because playback required the user to manually open the menu and invoke Try Native Player. Build 11 removes that manual normal-use step. It debounces repeated manifest observations, automatically makes one native Media3 attempt per page after a short delay, and automatically restores the normal DisneyNOW WebView player if Media3 reports an error, setup fails, or playback does not begin within a bounded startup timeout. Detailed stage/counter information remains in Debug Mode/reporting rather than requiring a normal-use menu action.

The package ID, app data/settings/cookies, minSdk 22 compatibility floor, Media3 1.8.1 pin, WebView remote-debugging prohibition, DRM/entitlement safety boundary, Silk fallback, and permanent release-signing identity remain unchanged.
