# Source — DisneyNOW Fire TV Web Wrapper v0.1 Build 1

This is a minimal Android/Fire TV WebView wrapper intended to test whether DisneyNOW playback works on a Fire TV Stick when iOS WebKit playback fails.

## Design

- Package ID: `com.fireworkstars46.disneynowfiretv`
- One permission only: `INTERNET`
- No Disney content or artwork is bundled.
- No DRM bypass, credential interception, ad blocking, or provider-token logging.
- JavaScript and DOM storage are enabled because the DisneyNOW site requires a modern browser environment.
- Third-party cookies are enabled inside the app WebView because participating TV-provider authentication may rely on cross-site cookies.
- Local file/content access and cleartext HTTP are disabled.
- WebView remote debugging is disabled.
- Fire TV Menu button exposes app controls.
- Optional D-pad focus helper provides TV-oriented web navigation.
- Fullscreen WebView video callbacks are implemented.
- A runtime Safe Self-Test exercises project identity, Version+Build, settings persistence, project-file persistence, WebView configuration, UA state, app-specific diagnostic storage, Widevine availability, and WebView runtime detection. Real Disney playback and physical remote interaction are explicitly SKIPPED until tested on the Fire TV hardware.

## Build

The GitHub Actions workflow installs Android SDK 35 + Gradle 8.7, runs the custom static audit, Android lint, unit-test task, and `assembleDebug`, then archives exact Build 1 compatibility-test artifacts and SHA-256 hashes.

Build 1 uses CI debug signing for compatibility testing only. It is not a stable update-compatible signing strategy.
