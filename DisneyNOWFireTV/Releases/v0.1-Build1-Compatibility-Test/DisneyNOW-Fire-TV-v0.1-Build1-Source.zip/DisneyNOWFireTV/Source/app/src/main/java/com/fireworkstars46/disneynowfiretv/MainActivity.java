package com.fireworkstars46.disneynowfiretv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.graphics.Color;
import android.media.MediaDrm;
import android.media.UnsupportedSchemeException;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Message;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebViewDatabase;
import android.widget.FrameLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public final class MainActivity extends Activity {
    private static final String HOME_URL = "https://disneynow.com/";
    private static final String EXPECTED_PACKAGE_ID = "com.fireworkstars46.disneynowfiretv";
    private static final String PREFS_NAME = "settings";
    private static final String KEY_UA_PROFILE = "ua_profile";
    private static final String KEY_TV_FOCUS = "tv_focus_navigation";
    private static final String KEY_FIRST_RUN_SHOWN = "first_run_shown";

    private static final String UA_ANDROID = "android";
    private static final String UA_WEBVIEW = "webview";
    private static final String UA_DESKTOP = "desktop";

    private static final UUID WIDEVINE_UUID = new UUID(
            0xedef8ba979d64aceL,
            0xa3c827dcd51d21edL
    );

    private FrameLayout root;
    private WebView webView;
    private FrameLayout customViewContainer;
    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private SharedPreferences prefs;
    private AppLogger logger;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        enterImmersiveMode();

        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        logger = new AppLogger(this);
        logger.log("START version=" + versionLabel() + " sdk=" + Build.VERSION.SDK_INT);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        webView.setFocusable(true);
        webView.setFocusableInTouchMode(true);
        root.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        customViewContainer = new FrameLayout(this);
        customViewContainer.setBackgroundColor(Color.BLACK);
        customViewContainer.setVisibility(View.GONE);
        root.addView(customViewContainer, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
        ));

        setContentView(root);
        configureWebView();
        webView.loadUrl(HOME_URL);
        webView.requestFocus();

        if (!prefs.getBoolean(KEY_FIRST_RUN_SHOWN, false)) {
            boolean saved = prefs.edit().putBoolean(KEY_FIRST_RUN_SHOWN, true).commit();
            if (!saved) {
                logger.log("WARN first-run flag persistence failed");
            }
            Toast.makeText(this, "Press the Fire TV Menu button (three lines) for app controls.", Toast.LENGTH_LONG).show();
        }
    }

    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setSupportZoom(false);
        settings.setSupportMultipleWindows(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setUserAgentString(resolveUserAgent(currentUaProfile()));

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            settings.setSafeBrowsingEnabled(true);
        }

        WebView.setWebContentsDebuggingEnabled(false);

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(webView, true);

        webView.setWebViewClient(new DisneyWebViewClient());
        webView.setWebChromeClient(new DisneyWebChromeClient());
    }

    private final class DisneyWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return handleUri(request.getUrl());
        }

        @SuppressWarnings("deprecation")
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            return handleUri(Uri.parse(url));
        }

        @SuppressWarnings("deprecation")
        @Override
        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            logger.log("WEB_ERROR code=" + errorCode + " host=" + safeHost(failingUrl));
            super.onReceivedError(view, errorCode, description, failingUrl);
        }

        @Override
        public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
            if (request.isForMainFrame()) {
                logger.log("HTTP_ERROR status=" + errorResponse.getStatusCode() + " host=" + safeHost(request.getUrl()));
            }
            super.onReceivedHttpError(view, request, errorResponse);
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            logger.log("PAGE_FINISHED host=" + safeHost(url));
            if (prefs.getBoolean(KEY_TV_FOCUS, true)) {
                injectFocusHighlight();
            }
            view.requestFocus();
        }
    }

    private final class DisneyWebChromeClient extends WebChromeClient {
        @Override
        public void onShowCustomView(View view, CustomViewCallback callback) {
            if (customView != null) {
                callback.onCustomViewHidden();
                return;
            }
            customView = view;
            customViewCallback = callback;
            customViewContainer.addView(view, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
            ));
            customViewContainer.setVisibility(View.VISIBLE);
            webView.setVisibility(View.GONE);
            enterImmersiveMode();
            logger.log("FULLSCREEN enter");
        }

        @Override
        public void onHideCustomView() {
            hideCustomView();
        }

        @Override
        public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
            final WebView popup = new WebView(MainActivity.this);
            popup.getSettings().setJavaScriptEnabled(true);
            popup.getSettings().setDomStorageEnabled(true);
            CookieManager.getInstance().setAcceptThirdPartyCookies(popup, true);
            popup.setWebViewClient(new WebViewClient() {
                @Override
                public boolean shouldOverrideUrlLoading(WebView child, WebResourceRequest request) {
                    Uri uri = request.getUrl();
                    if (isHttpOrHttps(uri)) {
                        webView.loadUrl(uri.toString());
                    } else {
                        handleUri(uri);
                    }
                    child.destroy();
                    return true;
                }

                @Override
                public void onPageStarted(WebView child, String url, android.graphics.Bitmap favicon) {
                    super.onPageStarted(child, url, favicon);
                    Uri uri = Uri.parse(url);
                    if (isHttpOrHttps(uri)) {
                        webView.loadUrl(url);
                        child.stopLoading();
                        child.destroy();
                    }
                }
            });
            WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
            transport.setWebView(popup);
            resultMsg.sendToTarget();
            return true;
        }

        @Override
        public void onPermissionRequest(PermissionRequest request) {
            logger.log("WEB_PERMISSION denied resources=" + request.getResources().length);
            request.deny();
        }

        @Override
        public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
            logger.log("GEOLOCATION denied host=" + safeHost(origin));
            callback.invoke(origin, false, false);
        }
    }

    private boolean handleUri(Uri uri) {
        if (uri == null) {
            return false;
        }
        if (isHttpOrHttps(uri)) {
            return false;
        }

        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(intent);
            logger.log("EXTERNAL_SCHEME opened scheme=" + safeText(uri.getScheme()));
        } catch (ActivityNotFoundException ex) {
            logger.log("EXTERNAL_SCHEME unavailable scheme=" + safeText(uri.getScheme()));
            Toast.makeText(this, "No app is installed to open that link.", Toast.LENGTH_SHORT).show();
        }
        return true;
    }

    private static boolean isHttpOrHttps(Uri uri) {
        if (uri == null) {
            return false;
        }
        String scheme = uri.getScheme();
        return "http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme);
    }

    private void hideCustomView() {
        if (customView == null) {
            return;
        }
        customViewContainer.removeView(customView);
        customViewContainer.setVisibility(View.GONE);
        customView = null;
        webView.setVisibility(View.VISIBLE);
        if (customViewCallback != null) {
            customViewCallback.onCustomViewHidden();
            customViewCallback = null;
        }
        webView.requestFocus();
        enterImmersiveMode();
        logger.log("FULLSCREEN exit");
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            showAppMenu();
            return true;
        }

        if (customView == null && prefs.getBoolean(KEY_TV_FOCUS, true)) {
            if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT || keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
                moveWebFocus(true);
                return true;
            }
            if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT || keyCode == KeyEvent.KEYCODE_DPAD_UP) {
                moveWebFocus(false);
                return true;
            }
            if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER) {
                sendEnterToWebView();
                return true;
            }
        }

        return super.onKeyDown(keyCode, event);
    }

    private void moveWebFocus(boolean forward) {
        String delta = forward ? "1" : "-1";
        String js = "(function(){"
                + "var q='a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex=\\\"-1\\\"]),video';"
                + "var a=Array.prototype.slice.call(document.querySelectorAll(q)).filter(function(e){"
                + "var r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.visibility!==\"hidden\"&&s.display!==\"none\";});"
                + "if(!a.length)return;var cur=document.activeElement,i=a.indexOf(cur);"
                + "if(i<0){i=" + (forward ? "0" : "a.length-1") + ";}else{i=(i+" + delta + "+a.length)%a.length;}"
                + "a[i].focus();a[i].scrollIntoView({block:'center',inline:'center'});"
                + "})();";
        webView.evaluateJavascript(js, null);
    }

    private void sendEnterToWebView() {
        long now = android.os.SystemClock.uptimeMillis();
        webView.dispatchKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER, 0));
        webView.dispatchKeyEvent(new KeyEvent(now, now, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER, 0));
    }

    private void injectFocusHighlight() {
        String js = "(function(){if(document.getElementById('firetv-focus-style'))return;"
                + "var s=document.createElement('style');s.id='firetv-focus-style';"
                + "s.textContent='*:focus{outline:4px solid white !important;outline-offset:3px !important;}';"
                + "(document.head||document.documentElement).appendChild(s);})();";
        webView.evaluateJavascript(js, null);
    }

    private void showAppMenu() {
        final boolean tvFocus = prefs.getBoolean(KEY_TV_FOCUS, true);
        final String[] items = new String[]{
                "Home",
                "Reload",
                "User Agent: " + profileLabel(currentUaProfile()),
                "TV Focus Navigation: " + (tvFocus ? "On" : "Off"),
                "Clear DisneyNOW App Web Data",
                "Diagnostics",
                "Export Diagnostic Report",
                "Safe Self-Test",
                "About",
                "Exit"
        };

        new AlertDialog.Builder(this)
                .setTitle("DisneyNOW Web — " + versionLabel())
                .setItems(items, (dialog, which) -> {
                    switch (which) {
                        case 0:
                            webView.loadUrl(HOME_URL);
                            break;
                        case 1:
                            webView.reload();
                            break;
                        case 2:
                            showUserAgentDialog();
                            break;
                        case 3:
                            setTvFocusNavigation(!tvFocus);
                            break;
                        case 4:
                            confirmClearWebData();
                            break;
                        case 5:
                            showTextDialog("Diagnostics", buildDiagnostics());
                            break;
                        case 6:
                            exportDiagnostics();
                            break;
                        case 7:
                            runSafeSelfTest();
                            break;
                        case 8:
                            showAbout();
                            break;
                        case 9:
                            logger.log("EXIT menu");
                            finish();
                            break;
                        default:
                            break;
                    }
                })
                .show();
    }

    private void showUserAgentDialog() {
        final String[] values = new String[]{UA_ANDROID, UA_WEBVIEW, UA_DESKTOP};
        final String[] labels = new String[]{
                "Android Chrome-compatible (recommended)",
                "Device WebView original",
                "Desktop Edge-compatible"
        };
        String current = currentUaProfile();
        int checked = 0;
        for (int i = 0; i < values.length; i++) {
            if (values[i].equals(current)) {
                checked = i;
                break;
            }
        }

        final int initialChecked = checked;
        new AlertDialog.Builder(this)
                .setTitle("User Agent")
                .setSingleChoiceItems(labels, initialChecked, (dialog, which) -> {
                    setUserAgentProfile(values[which]);
                    dialog.dismiss();
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void setUserAgentProfile(String profile) {
        if (!isValidUaProfile(profile)) {
            Toast.makeText(this, "Invalid user-agent profile.", Toast.LENGTH_SHORT).show();
            return;
        }
        boolean saved = prefs.edit().putString(KEY_UA_PROFILE, profile).commit();
        if (!saved) {
            logger.log("ERROR ua profile persistence failed profile=" + profile);
            Toast.makeText(this, "Could not save the user-agent setting.", Toast.LENGTH_LONG).show();
            return;
        }
        webView.getSettings().setUserAgentString(resolveUserAgent(profile));
        logger.log("SETTING ua_profile=" + profile);
        webView.reload();
    }

    private void setTvFocusNavigation(boolean enabled) {
        boolean saved = prefs.edit().putBoolean(KEY_TV_FOCUS, enabled).commit();
        if (!saved) {
            logger.log("ERROR tv focus persistence failed");
            Toast.makeText(this, "Could not save TV Focus Navigation.", Toast.LENGTH_LONG).show();
            return;
        }
        logger.log("SETTING tv_focus_navigation=" + enabled);
        if (enabled) {
            injectFocusHighlight();
        }
        Toast.makeText(this, "TV Focus Navigation " + (enabled ? "enabled" : "disabled") + ".", Toast.LENGTH_SHORT).show();
    }

    private String currentUaProfile() {
        String profile = prefs.getString(KEY_UA_PROFILE, UA_ANDROID);
        return isValidUaProfile(profile) ? profile : UA_ANDROID;
    }

    private static boolean isValidUaProfile(String profile) {
        return UA_ANDROID.equals(profile) || UA_WEBVIEW.equals(profile) || UA_DESKTOP.equals(profile);
    }

    private String resolveUserAgent(String profile) {
        String original = WebSettings.getDefaultUserAgent(this);
        if (UA_WEBVIEW.equals(profile)) {
            return original;
        }
        if (UA_DESKTOP.equals(profile)) {
            return "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                    + "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36 Edg/131.0.0.0";
        }

        String sanitized = original
                .replace("; wv", "")
                .replace(" Version/4.0", "")
                .replace("Version/4.0 ", "");
        return sanitized;
    }

    private static String profileLabel(String profile) {
        if (UA_WEBVIEW.equals(profile)) {
            return "Device WebView";
        }
        if (UA_DESKTOP.equals(profile)) {
            return "Desktop Edge";
        }
        return "Android Chrome-compatible";
    }

    private void confirmClearWebData() {
        new AlertDialog.Builder(this)
                .setTitle("Clear DisneyNOW App Web Data?")
                .setMessage("This clears cookies, cache, Web Storage, form data, and HTTP auth saved only inside this app. You may need to sign into your TV provider again.")
                .setPositiveButton("Clear", (dialog, which) -> clearAppWebData())
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void clearAppWebData() {
        CookieManager cookies = CookieManager.getInstance();
        cookies.removeAllCookies(value -> {
            cookies.flush();
            webView.clearCache(true);
            webView.clearHistory();
            webView.clearFormData();
            webView.clearSslPreferences();
            WebStorage.getInstance().deleteAllData();
            WebViewDatabase.getInstance(MainActivity.this).clearHttpAuthUsernamePassword();
            logger.log("WEB_DATA cleared app-local WebView data");
            webView.loadUrl(HOME_URL);
            Toast.makeText(MainActivity.this, "App web data cleared.", Toast.LENGTH_SHORT).show();
        });
    }

    private String buildDiagnostics() {
        StringBuilder out = new StringBuilder();
        out.append("Project: DisneyNOW Fire TV Web Wrapper\n");
        out.append("Version: ").append(versionLabel()).append('\n');
        out.append("Package: ").append(getPackageName()).append('\n');
        out.append("Device: ").append(safeText(Build.MANUFACTURER)).append(' ').append(safeText(Build.MODEL)).append('\n');
        out.append("Android SDK: ").append(Build.VERSION.SDK_INT).append('\n');
        out.append("OS display: ").append(safeText(Build.DISPLAY)).append('\n');
        out.append("WebView: ").append(webViewPackageSummary()).append('\n');
        out.append("UA profile: ").append(profileLabel(currentUaProfile())).append('\n');
        out.append("User agent: ").append(webView.getSettings().getUserAgentString()).append('\n');
        out.append("JavaScript: ").append(webView.getSettings().getJavaScriptEnabled()).append('\n');
        out.append("DOM storage: ").append(webView.getSettings().getDomStorageEnabled()).append('\n');
        out.append("Third-party cookies: enabled for this app WebView\n");
        out.append("TV Focus Navigation: ").append(prefs.getBoolean(KEY_TV_FOCUS, true)).append('\n');
        out.append("Widevine: ").append(widevineSummary()).append('\n');
        out.append("Home: ").append(HOME_URL).append('\n');
        out.append("Log folder: ").append(logger.getLogDirectory().getAbsolutePath()).append('\n');
        out.append("\nNo passwords, provider tokens, device serials, browsing text, or private input are collected by this diagnostic report.\n");
        return out.toString();
    }

    private String webViewPackageSummary() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            PackageInfo info = WebView.getCurrentWebViewPackage();
            if (info == null) {
                return "unavailable";
            }
            return safeText(info.packageName) + " " + safeText(info.versionName);
        }
        return "package query unavailable below API 26";
    }

    private String widevineSummary() {
        if (!MediaDrm.isCryptoSchemeSupported(WIDEVINE_UUID)) {
            return "not supported";
        }
        MediaDrm drm = null;
        try {
            drm = new MediaDrm(WIDEVINE_UUID);
            String vendor = safeDrmProperty(drm, MediaDrm.PROPERTY_VENDOR);
            String version = safeDrmProperty(drm, MediaDrm.PROPERTY_VERSION);
            String security = safeDrmProperty(drm, "securityLevel");
            return "supported; vendor=" + vendor + "; version=" + version + "; security=" + security;
        } catch (UnsupportedSchemeException | RuntimeException ex) {
            return "reported supported but could not open: " + ex.getClass().getSimpleName();
        } finally {
            if (drm != null) {
                drm.release();
            }
        }
    }

    private static String safeDrmProperty(MediaDrm drm, String key) {
        try {
            String value = drm.getPropertyString(key);
            return value == null || value.trim().isEmpty() ? "unknown" : value.trim();
        } catch (RuntimeException ex) {
            return "unknown";
        }
    }

    private void exportDiagnostics() {
        String diagnostics = buildDiagnostics();
        File folder = new File(appStorageRoot(), "diagnostics");
        if (!folder.exists() && !folder.mkdirs()) {
            Toast.makeText(this, "Could not create the diagnostics folder.", Toast.LENGTH_LONG).show();
            logger.log("ERROR diagnostics folder create failed");
            return;
        }
        String stamp = new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date());
        File file = new File(folder, "DisneyNOWFireTV-Diagnostics-" + stamp + ".txt");
        if (writeUtf8(file, diagnostics)) {
            logger.log("DIAGNOSTICS exported file=" + file.getName());
            showTextDialog("Diagnostic Report Exported", "Saved to:\n" + file.getAbsolutePath());
        } else {
            logger.log("ERROR diagnostics export failed");
            Toast.makeText(this, "Diagnostic export failed.", Toast.LENGTH_LONG).show();
        }
    }

    private void runSafeSelfTest() {
        List<TestResult> results = new ArrayList<>();

        addResult(results, "Project package identity",
                EXPECTED_PACKAGE_ID.equals(getPackageName()),
                "expected=" + EXPECTED_PACKAGE_ID + " actual=" + getPackageName());

        boolean versionOk = "0.1".equals(BuildConfig.VERSION_NAME) && BuildConfig.APP_BUILD == 1 && BuildConfig.VERSION_CODE == 1;
        addResult(results, "Version + Build identity", versionOk,
                "versionName=" + BuildConfig.VERSION_NAME + " versionCode=" + BuildConfig.VERSION_CODE + " Build=" + BuildConfig.APP_BUILD);

        String tempKey = "__selftest_" + System.nanoTime();
        String tempValue = "write-reload-compare";
        boolean settingWritten = prefs.edit().putString(tempKey, tempValue).commit();
        SharedPreferences reloadedPrefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean settingMatches = settingWritten && tempValue.equals(reloadedPrefs.getString(tempKey, null));
        boolean settingCleaned = reloadedPrefs.edit().remove(tempKey).commit();
        addResult(results, "Settings persistence write -> reload/read -> compare -> delete",
                settingMatches && settingCleaned,
                "write=" + settingWritten + " compare=" + settingMatches + " cleanup=" + settingCleaned);

        boolean webSettingsOk = webView.getSettings().getJavaScriptEnabled()
                && webView.getSettings().getDomStorageEnabled()
                && !webView.getSettings().getAllowFileAccess()
                && !webView.getSettings().getAllowContentAccess()
                && CookieManager.getInstance().acceptCookie();
        addResult(results, "WebView production settings", webSettingsOk,
                "JavaScript/DOM enabled; file/content access disabled; cookies accepted");

        String ua = webView.getSettings().getUserAgentString();
        boolean uaOk = ua != null && !ua.trim().isEmpty() && isValidUaProfile(currentUaProfile());
        addResult(results, "User-agent production path", uaOk,
                "profile=" + currentUaProfile() + " uaLength=" + (ua == null ? 0 : ua.length()));

        File internalTest = new File(getFilesDir(), "selftest.tmp");
        boolean internalRoundTrip = writeReadCompareDelete(internalTest, "DisneyNOWFireTV-selftest");
        addResult(results, "Project data write -> reload/read -> compare -> delete", internalRoundTrip,
                internalTest.getAbsolutePath());

        File externalRoot = getExternalFilesDir(null);
        if (externalRoot == null) {
            results.add(TestResult.skipped("App-specific external diagnostics storage", "External app-specific storage is unavailable on this device."));
        } else {
            File externalTest = new File(externalRoot, "selftest-external.tmp");
            boolean externalRoundTrip = writeReadCompareDelete(externalTest, "diagnostic-storage-selftest");
            addResult(results, "App-specific diagnostic storage write -> reload/read -> compare -> delete", externalRoundTrip,
                    externalTest.getAbsolutePath());
        }

        boolean widevineSupported = MediaDrm.isCryptoSchemeSupported(WIDEVINE_UUID);
        addResult(results, "Widevine DRM scheme availability", widevineSupported,
                widevineSupported ? widevineSummary() : "Widevine is unavailable; protected Disney playback is unlikely to work.");

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            PackageInfo packageInfo = WebView.getCurrentWebViewPackage();
            addResult(results, "WebView runtime package detection", packageInfo != null,
                    packageInfo == null ? "No current WebView package reported." : safeText(packageInfo.packageName) + " " + safeText(packageInfo.versionName));
        } else {
            results.add(TestResult.skipped("WebView runtime package detection", "Android API is below 26; this package-query API is unavailable."));
        }

        boolean homeUrlOk = HOME_URL.startsWith("https://") && "disneynow.com".equalsIgnoreCase(Uri.parse(HOME_URL).getHost());
        addResult(results, "DisneyNOW home URL safety invariant", homeUrlOk, HOME_URL);

        results.add(TestResult.skipped(
                "Live DisneyNOW authentication + protected video playback",
                "Requires the user's real provider session, Disney servers, device DRM negotiation, and an interactive Fire TV playback check."
        ));
        results.add(TestResult.skipped(
                "Physical Fire TV remote navigation and fullscreen video",
                "Requires actual Fire TV hardware interaction; the app includes the production handlers but this test cannot physically press the remote or play protected content."
        ));

        String report = formatSelfTestReport(results);
        File folder = new File(appStorageRoot(), "selftest");
        boolean folderReady = folder.exists() || folder.mkdirs();
        File reportFile = new File(folder, "SafeSelfTest-v0.1-Build1.txt");
        boolean reportSaved = folderReady && writeUtf8(reportFile, report);
        logger.log("SELF_TEST complete " + selfTestTotals(results) + " reportSaved=" + reportSaved);

        String shown = report + "\nReport saved: " + (reportSaved ? reportFile.getAbsolutePath() : "FAILED TO SAVE");
        showTextDialog("Safe Self-Test — " + versionLabel(), shown);
    }

    private static void addResult(List<TestResult> results, String name, boolean pass, String detail) {
        results.add(pass ? TestResult.pass(name, detail) : TestResult.fail(name, detail));
    }

    private String formatSelfTestReport(List<TestResult> results) {
        StringBuilder out = new StringBuilder();
        out.append("DisneyNOW Fire TV Web Wrapper SAFE SELF-TEST\n");
        out.append("Version: ").append(versionLabel()).append('\n');
        out.append("Package: ").append(getPackageName()).append('\n');
        out.append("Device: ").append(safeText(Build.MANUFACTURER)).append(' ').append(safeText(Build.MODEL)).append('\n');
        out.append("Android SDK: ").append(Build.VERSION.SDK_INT).append("\n\n");

        int index = 1;
        for (TestResult result : results) {
            out.append(index++)
                    .append(". ")
                    .append(result.status)
                    .append(" - ")
                    .append(result.name)
                    .append(" | ")
                    .append(result.detail)
                    .append('\n');
        }
        out.append("\nTOTALS: ").append(selfTestTotals(results)).append('\n');
        out.append("\nBuild remains NOT DONE until the SKIPPED Fire TV playback/remote checks are physically completed and any failures are resolved.\n");
        return out.toString();
    }

    private static String selfTestTotals(List<TestResult> results) {
        int pass = 0;
        int fail = 0;
        int skipped = 0;
        for (TestResult result : results) {
            if ("PASS".equals(result.status)) {
                pass++;
            } else if ("FAIL".equals(result.status)) {
                fail++;
            } else {
                skipped++;
            }
        }
        return "PASS=" + pass + " FAIL=" + fail + " SKIPPED/NOT TESTED=" + skipped;
    }

    private boolean writeReadCompareDelete(File file, String value) {
        boolean write = writeUtf8(file, value);
        String loaded = write ? readUtf8(file) : null;
        boolean compare = value.equals(loaded);
        boolean deleted = !file.exists() || file.delete();
        return write && compare && deleted;
    }

    private static boolean writeUtf8(File file, String value) {
        try (FileOutputStream out = new FileOutputStream(file, false)) {
            out.write(value.getBytes(StandardCharsets.UTF_8));
            out.flush();
            return true;
        } catch (Exception ex) {
            return false;
        }
    }

    private static String readUtf8(File file) {
        StringBuilder out = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
            char[] buffer = new char[2048];
            int count;
            while ((count = reader.read(buffer)) != -1) {
                out.append(buffer, 0, count);
            }
            return out.toString();
        } catch (Exception ex) {
            return null;
        }
    }

    private File appStorageRoot() {
        File external = getExternalFilesDir(null);
        return external != null ? external : getFilesDir();
    }

    private void showAbout() {
        String text = "DisneyNOW Fire TV Web Wrapper\n"
                + versionLabel() + "\n\n"
                + "Unofficial personal-use compatibility wrapper. Not affiliated with or endorsed by Disney.\n\n"
                + "The app loads disneynow.com directly and uses Disney's normal website, provider authentication, video player, and DRM. It does not bypass DRM or unlock content.\n\n"
                + "Build 1 is an experimental compatibility build and remains NOT DONE until it is tested on the actual Fire TV Stick.";
        showTextDialog("About", text);
    }

    private void showTextDialog(String title, String text) {
        ScrollView scroll = new ScrollView(this);
        TextView textView = new TextView(this);
        int pad = dp(20);
        textView.setPadding(pad, pad, pad, pad);
        textView.setTextColor(Color.WHITE);
        textView.setTextSize(16f);
        textView.setTextIsSelectable(true);
        textView.setText(text);
        scroll.addView(textView);

        new AlertDialog.Builder(this)
                .setTitle(title)
                .setView(scroll)
                .setPositiveButton("Close", null)
                .show();
    }

    private int dp(int value) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(value * density);
    }

    private String versionLabel() {
        return "v" + BuildConfig.VERSION_NAME + " Build " + BuildConfig.APP_BUILD;
    }

    private void enterImmersiveMode() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            enterImmersiveMode();
        }
    }

    @Override
    public void onBackPressed() {
        if (customView != null) {
            hideCustomView();
            return;
        }
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
            return;
        }
        logger.log("EXIT back");
        super.onBackPressed();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.onResume();
        }
        enterImmersiveMode();
    }

    @Override
    protected void onPause() {
        if (webView != null) {
            webView.onPause();
        }
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            root.removeView(webView);
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
            webView = null;
        }
        logger.log("STOP version=" + versionLabel());
        super.onDestroy();
    }

    private static String safeHost(String url) {
        if (url == null) {
            return "unknown";
        }
        try {
            return safeHost(Uri.parse(url));
        } catch (RuntimeException ex) {
            return "unknown";
        }
    }

    private static String safeHost(Uri uri) {
        if (uri == null || uri.getHost() == null) {
            return "unknown";
        }
        return uri.getHost();
    }

    private static String safeText(String value) {
        if (value == null || value.trim().isEmpty()) {
            return "unknown";
        }
        return value.replace('\n', ' ').replace('\r', ' ').trim();
    }

    private static final class TestResult {
        final String status;
        final String name;
        final String detail;

        private TestResult(String status, String name, String detail) {
            this.status = status;
            this.name = name;
            this.detail = detail;
        }

        static TestResult pass(String name, String detail) {
            return new TestResult("PASS", name, detail);
        }

        static TestResult fail(String name, String detail) {
            return new TestResult("FAIL", name, detail);
        }

        static TestResult skipped(String name, String detail) {
            return new TestResult("SKIPPED/NOT TESTED", name, detail);
        }
    }

    private static final class AppLogger {
        private static final long MAX_BYTES = 1024L * 1024L;
        private static final int MAX_FILES = 5;
        private final File logDir;

        AppLogger(Context context) {
            File external = context.getExternalFilesDir(null);
            File root = external != null ? external : context.getFilesDir();
            logDir = new File(root, "logs");
            if (!logDir.exists()) {
                //noinspection ResultOfMethodCallIgnored
                logDir.mkdirs();
            }
        }

        File getLogDirectory() {
            return logDir;
        }

        synchronized void log(String message) {
            try {
                rotateIfNeeded();
                File current = new File(logDir, "app-0.log");
                String stamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(new Date());
                String line = stamp + " | " + safeText(message) + "\n";
                try (FileOutputStream out = new FileOutputStream(current, true)) {
                    out.write(line.getBytes(StandardCharsets.UTF_8));
                    out.flush();
                }
            } catch (Exception ignored) {
                // Logging must never break normal app behavior.
            }
        }

        private void rotateIfNeeded() {
            File current = new File(logDir, "app-0.log");
            if (!current.exists() || current.length() < MAX_BYTES) {
                return;
            }
            File oldest = new File(logDir, "app-" + (MAX_FILES - 1) + ".log");
            if (oldest.exists()) {
                //noinspection ResultOfMethodCallIgnored
                oldest.delete();
            }
            for (int i = MAX_FILES - 2; i >= 0; i--) {
                File from = new File(logDir, "app-" + i + ".log");
                File to = new File(logDir, "app-" + (i + 1) + ".log");
                if (from.exists()) {
                    //noinspection ResultOfMethodCallIgnored
                    from.renameTo(to);
                }
            }
        }
    }
}
