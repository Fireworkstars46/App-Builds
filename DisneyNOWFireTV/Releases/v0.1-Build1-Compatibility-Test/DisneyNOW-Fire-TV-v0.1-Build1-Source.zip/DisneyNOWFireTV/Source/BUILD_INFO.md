# Build information

- Project: DisneyNOW Fire TV Web Wrapper
- Version: 0.1
- Build: 1
- Android versionCode: 1
- Package ID: `com.fireworkstars46.disneynowfiretv`
- Minimum SDK: 22 (Android 5.1 / Fire OS 5-era compatibility target)
- Target SDK: 35
- Distribution: personal sideload compatibility test
- Release state: NOT DONE pending real Fire TV runtime playback test and stable release-signing setup.

This build follows the repository's current `MASTER_RULES.md` as of source creation. The release workflow records the exact master-rules SHA-256 used at build time.
