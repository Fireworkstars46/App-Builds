#!/usr/bin/env python3
from pathlib import Path
import hashlib
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
APP_GRADLE = ROOT / "app" / "build.gradle"
MANIFEST = ROOT / "app" / "src" / "main" / "AndroidManifest.xml"
MAIN = ROOT / "app" / "src" / "main" / "java" / "com" / "fireworkstars46" / "disneynowfiretv" / "MainActivity.java"
BUILD_INFO = ROOT / "BUILD_INFO.md"
REPORT = ROOT / "build" / "reports" / "STATIC-AUDIT-v0.1-Build1.txt"
EXPECTED_PACKAGE = "com.fireworkstars46.disneynowfiretv"
EXPECTED_VERSION = "0.1"
EXPECTED_BUILD = "1"
EXPECTED_VERSION_CODE = "1"
ANDROID_NS = "{http://schemas.android.com/apk/res/android}"

results = []

def add(name, ok, detail):
    results.append(("PASS" if ok else "FAIL", name, detail))

for path in [APP_GRADLE, MANIFEST, MAIN, BUILD_INFO]:
    add(f"Required source exists: {path.relative_to(ROOT)}", path.is_file(), str(path))

if any(status == "FAIL" for status, _, _ in results):
    gradle = manifest_text = main = build_info = ""
else:
    gradle = APP_GRADLE.read_text(encoding="utf-8")
    manifest_text = MANIFEST.read_text(encoding="utf-8")
    main = MAIN.read_text(encoding="utf-8")
    build_info = BUILD_INFO.read_text(encoding="utf-8")

add("Package ID / namespace", EXPECTED_PACKAGE in gradle and EXPECTED_PACKAGE in main, EXPECTED_PACKAGE)
add("Version name", re.search(r"versionName\s+['\"]0\.1['\"]", gradle) is not None, EXPECTED_VERSION)
add("Version code", re.search(r"versionCode\s+1\b", gradle) is not None, EXPECTED_VERSION_CODE)
add("Build number constant", "buildConfigField 'int', 'APP_BUILD', '1'" in gradle and "BuildConfig.APP_BUILD == 1" in main, EXPECTED_BUILD)
add("Minimum SDK 22", re.search(r"minSdk\s+22\b", gradle) is not None, "Android 5.1 / Fire OS 5-era floor")
add("Target SDK 35", re.search(r"targetSdk\s+35\b", gradle) is not None, "targetSdk 35")
add("Java 17 compile target", "JavaVersion.VERSION_17" in gradle, "source/target compatibility")

try:
    root = ET.fromstring(manifest_text)
    permissions = [node.attrib.get(ANDROID_NS + "name", "") for node in root.findall("uses-permission")]
    add("Least privilege: INTERNET is requested", permissions == ["android.permission.INTERNET"], f"permissions={permissions}")
    application = root.find("application")
    cleartext = application.attrib.get(ANDROID_NS + "usesCleartextTraffic") if application is not None else None
    add("Cleartext HTTP disabled", cleartext == "false", f"usesCleartextTraffic={cleartext}")
    activity = application.find("activity") if application is not None else None
    exported = activity.attrib.get(ANDROID_NS + "exported") if activity is not None else None
    add("Launcher activity explicitly exported", exported == "true", f"exported={exported}")
    categories = [c.attrib.get(ANDROID_NS + "name", "") for c in root.findall(".//category")]
    add("Fire TV leanback launcher category", "android.intent.category.LEANBACK_LAUNCHER" in categories, str(categories))
    add("Standard launcher category", "android.intent.category.LAUNCHER" in categories, str(categories))
except Exception as exc:
    add("AndroidManifest XML parses", False, repr(exc))
else:
    add("AndroidManifest XML parses", True, "well-formed XML")

checks = [
    ("JavaScript enabled through production WebView settings", "setJavaScriptEnabled(true)"),
    ("DOM storage enabled", "setDomStorageEnabled(true)"),
    ("Media playback user gesture relaxed for TV playback", "setMediaPlaybackRequiresUserGesture(false)"),
    ("File access disabled", "setAllowFileAccess(false)"),
    ("Content access disabled", "setAllowContentAccess(false)"),
    ("Mixed content prohibited", "MIXED_CONTENT_NEVER_ALLOW"),
    ("Third-party cookies explicitly enabled for provider auth", "setAcceptThirdPartyCookies(webView, true)"),
    ("Fullscreen video production callback", "onShowCustomView"),
    ("Fullscreen exit production callback", "onHideCustomView"),
    ("Fire TV Menu key app controls", "KEYCODE_MENU"),
    ("D-pad TV focus navigation", "KEYCODE_DPAD_RIGHT"),
    ("Settings persistence uses synchronous verification path", ".commit()"),
    ("Safe Self-Test present", "runSafeSelfTest"),
    ("Settings persistence self-test write/reload/compare", "Settings persistence write -> reload/read -> compare -> delete"),
    ("Data persistence self-test write/reload/compare", "Project data write -> reload/read -> compare -> delete"),
    ("Widevine runtime diagnostic", "MediaDrm.isCryptoSchemeSupported(WIDEVINE_UUID)"),
    ("No WebView remote debugging", "setWebContentsDebuggingEnabled(false)"),
    ("App-local web-data clear path", "clearAppWebData"),
    ("Bounded log rotation", "MAX_FILES = 5"),
    ("Log size bound", "MAX_BYTES = 1024L * 1024L"),
]
for name, needle in checks:
    add(name, needle in main, needle)

for forbidden in [
    "android.permission.READ_CONTACTS",
    "android.permission.READ_SMS",
    "android.permission.RECORD_AUDIO",
    "android.permission.CAMERA",
    "android.permission.ACCESS_FINE_LOCATION",
    "android.permission.MANAGE_EXTERNAL_STORAGE",
    "setWebContentsDebuggingEnabled(true)",
    "onReceivedSslError",
]:
    add(f"Forbidden/high-risk capability absent: {forbidden}", forbidden not in manifest_text + main, forbidden)

# Privacy invariant: navigation logs should be host-only rather than full URLs.
add("Navigation logging is host-only", 'logger.log("PAGE_FINISHED host=" + safeHost(url))' in main, "No full page URL in normal navigation log")
add("Diagnostics declare no credential/token collection", "No passwords, provider tokens" in main, "privacy statement present")

# Simple structural sanity checks that catch accidental truncation.
add("MainActivity brace balance", main.count("{") == main.count("}"), f"open={main.count('{')} close={main.count('}')}")
add("MainActivity parenthesis count sanity", abs(main.count("(") - main.count(")")) == 0, f"open={main.count('(')} close={main.count(')')}")
add("Build info matches version/build", "Version: 0.1" in build_info and "Build: 1" in build_info, "BUILD_INFO.md")

pass_count = sum(1 for status, _, _ in results if status == "PASS")
fail_count = sum(1 for status, _, _ in results if status == "FAIL")
REPORT.parent.mkdir(parents=True, exist_ok=True)
master = ROOT.parents[1] / "MASTER_RULES.md"
master_sha = hashlib.sha256(master.read_bytes()).hexdigest() if master.is_file() else "unavailable"

lines = [
    "DisneyNOW Fire TV Web Wrapper - STATIC / RELEASE AUDIT",
    "Version: 0.1 Build 1",
    f"MASTER_RULES SHA-256: {master_sha}",
    "",
]
for i, (status, name, detail) in enumerate(results, start=1):
    lines.append(f"{i}. {status} - {name} | {detail}")
lines += [
    "",
    f"STATIC TOTAL: PASS={pass_count} FAIL={fail_count}",
    "RESULT: PASS" if fail_count == 0 else "RESULT: FAIL",
    "",
    "Runtime Fire TV playback, DRM license negotiation, real provider sign-in, physical remote behavior, and fullscreen protected video are not claimed by this static audit.",
]
REPORT.write_text("\n".join(lines) + "\n", encoding="utf-8")
print(REPORT.read_text(encoding="utf-8"))
sys.exit(0 if fail_count == 0 else 1)
