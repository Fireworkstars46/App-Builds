# Source — DisneyNOW Fire TV Hybrid TV Shell v0.1 Build 12

Build 12 is a corrective safety/stability update based on the physical Build 11 test. It preserves the package/update identity, WebView/provider flow, Native TV Navigation, compatibility cursor, Performance Mode, whole-WebView Page Zoom, privacy-safe Debug Mode, experimental Media3 code for diagnostics/future controlled work, and Silk fallback.

Physical Build 11 evidence showed that Media3 could reach `BUFFERING`, `READY`, and `isPlaying=true`, but the app later became glitchy and the process restarted without a Java/Media3 error being captured. Build 12 responds by simplifying normal use rather than automatically taking over playback.

Changes in Build 12:
- **Automatic native handoff disabled:** detecting an authenticated-session HLS/DASH manifest no longer schedules or launches Media3 automatically.
- **Native path out of normal use:** the manual `Try Native Player` item remains absent, so normal use does not require or expose an experimental native-player action.
- **Persistent crash/restart breadcrumb:** the app records a privacy-safe active-session marker plus the last safe native-handoff stage/detail and Build number using synchronous persistence at critical handoff points.
- **Unclean-session detection:** the next launch can report that the previous session did not reach clean `onDestroy`. This indicates a crash/kill/restart possibility but is not by itself proof of a crash because Android can terminate a process for other reasons.
- **Privacy-safe uncaught Java exception capture:** an uncaught exception handler records only exception class names/cause class chain before forwarding to Android's existing handler; messages, URLs, tokens, cookies, request bodies, and typed text are not recorded.
- **Debug report visibility:** Debug Snapshot/export includes the previous-session unclean flag and persisted breadcrumb.
- **Build 10/11 diagnostics retained:** safe manifest host/type, header-presence booleans, possible post-manifest non-GET host/type hints, Media3 codes/class chains, page-load timing, D-pad timing, and bounded logs remain available.

Preserved architecture details:
- **Whole-page Page Zoom 0-500:** Android WebView-level scaling, not CSS-only zoom.
- **Experimental native playback code:** AndroidX Media3/ExoPlayer remains in source for controlled diagnostics/future fixes but is not automatically launched in Build 12 normal use.
- **Media3 compatibility:** pinned to Media3 `1.8.1` for the existing `minSdk 22` Fire TV compatibility floor.
- **Security boundary:** `WebView.setWebContentsDebuggingEnabled(false)` remains enforced; no DRM keys are extracted, no entitlement/token/license is forged, and no DRM is bypassed.
- **Update compatibility:** package ID and permanent release signer are unchanged. Install Build 12 over Build 11; do not uninstall.

Build 12 remains **NOT DONE - COMPATIBILITY TEST** until a physical Fire TV test verifies that the Build 11 automatic-handoff regression is gone, normal browsing/playback is no longer destabilized by automatic Media3 launch, and the new crash/restart breadcrumb appears correctly in Debug Report if a future restart occurs.
