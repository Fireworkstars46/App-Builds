# Build information

- Project: DisneyNOW Fire TV Hybrid TV Shell
- Version: 0.1
- Build: 12
- Android versionCode: 12
- Package ID: `com.fireworkstars46.disneynowfiretv`
- Release state: NOT DONE pending physical Fire TV testing of Build 12 stability, WebView playback behavior, crash/restart breadcrumb usefulness, navigation responsiveness, provider login, ads/program video, whole-page zoom, Silk fallback, and Debug Mode/reporting.

Build 12 is a corrective safety/stability update based on the physical Build 11 report. Build 11 proved that the experimental Media3 path could reach BUFFERING, READY, and `isPlaying=true`, but the app later became glitchy and restarted without a Java/Media3 error being captured. Build 12 therefore disables automatic native-player launch during normal use and keeps HLS/DASH/native-handoff observation diagnostic-only.

Build 12 also adds a persistent privacy-safe crash/restart breadcrumb. Each session is marked active on startup and clean only when `onDestroy` is reached. The last safe native-handoff stage/detail and uncaught Java exception class chain can be committed synchronously. On the next launch, Debug Snapshot/export reports whether the prior session ended without clean `onDestroy` and the last persisted breadcrumb. This is a crash/kill indicator, not proof of a specific cause, because Android may terminate a process without a Java exception.

The package ID, app data/settings/cookies, minSdk 22 compatibility floor, Media3 1.8.1 pin, WebView remote-debugging prohibition, DRM/entitlement safety boundary, Silk fallback, and permanent release-signing identity remain unchanged.
