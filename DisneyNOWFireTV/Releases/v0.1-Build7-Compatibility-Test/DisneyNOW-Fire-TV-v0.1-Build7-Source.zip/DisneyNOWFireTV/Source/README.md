# Source — DisneyNOW Fire TV Web Wrapper v0.1 Build 7

Build 7 is a corrective compatibility build after physical Fire TV testing showed Build 6 still had laggy cursor motion, black video with audio, and Page Zoom that reloaded without visibly changing scale. It preserves the proven pre-WebView D-pad interception, package ID, cookies/login data, settings, and permanent signing identity.

Changes in Build 7:
- Cursor rendering uses a small 48dp overlay translated across the screen instead of invalidating a full-screen cursor canvas. Held movement is scheduled on display vsync with elapsed-time-based speed/acceleration.
- Page Zoom remains fully custom from 0 through 500 but now applies live through an injected `html { zoom: ... !important; }` style. Changing zoom no longer reloads DisneyNOW. The native app menu remains available even at extreme zoom values.
- Fullscreen media keeps the WebView attached but invisible while the custom media view is active, with a transparent media container, to reduce composition conflicts on Fire TV.
- Menu adds `Open Current Page in Silk (Video Fallback)` so a DisneyNOW page can be handed to Amazon Silk when embedded WebView playback still produces audio with a black picture.

Build 7 remains **NOT DONE - COMPATIBILITY TEST** until physical Fire TV testing confirms cursor responsiveness, live zoom behavior, provider-login stability, ad video, protected-program playback, and the Silk fallback path.
