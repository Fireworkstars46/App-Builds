#!/usr/bin/env python3
from pathlib import Path
import hashlib
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
APP_GRADLE = ROOT / "app" / "build.gradle"
MANIFEST = ROOT / "app" / "src" / "main" / "AndroidManifest.xml"
MAIN = ROOT / "app" / "src" / "main" / "java" / "com" / "fireworkstars46" / "disneynowfiretv" / "MainActivity.java"
BUILD_INFO = ROOT / "BUILD_INFO.md"
README = ROOT / "README.md"
REPORT = ROOT / "build" / "reports" / "STATIC-AUDIT-v0.1-Build7.txt"
EXPECTED_PACKAGE = "com.fireworkstars46.disneynowfiretv"
EXPECTED_VERSION = "0.1"
EXPECTED_BUILD = "7"
EXPECTED_VERSION_CODE = "7"
ANDROID_NS = "{http://schemas.android.com/apk/res/android}"

results = []

def add(name, ok, detail):
    results.append(("PASS" if ok else "FAIL", name, detail))

for path in [APP_GRADLE, MANIFEST, MAIN, BUILD_INFO, README]:
    add(f"Required source exists: {path.relative_to(ROOT)}", path.is_file(), str(path))

if any(status == "FAIL" for status, _, _ in results):
    gradle = manifest_text = main = build_info = readme = ""
else:
    gradle = APP_GRADLE.read_text(encoding="utf-8")
    manifest_text = MANIFEST.read_text(encoding="utf-8")
    main = MAIN.read_text(encoding="utf-8")
    build_info = BUILD_INFO.read_text(encoding="utf-8")
    readme = README.read_text(encoding="utf-8")

add("Package ID / namespace preserved", EXPECTED_PACKAGE in gradle and EXPECTED_PACKAGE in main, EXPECTED_PACKAGE)
add("Version name preserved", re.search(r"versionName\s+['\"]0\.1['\"]", gradle) is not None, EXPECTED_VERSION)
add("Version code incremented", re.search(r"versionCode\s+7\b", gradle) is not None, EXPECTED_VERSION_CODE)
add("Build number incremented", "buildConfigField 'int', 'APP_BUILD', '7'" in gradle and "BuildConfig.APP_BUILD == 7" in main, EXPECTED_BUILD)
add("Minimum SDK 22 preserved", re.search(r"minSdk\s+22\b", gradle) is not None, "Android 5.1 / Fire OS 5-era floor")
add("Target SDK 35 preserved", re.search(r"targetSdk\s+35\b", gradle) is not None, "targetSdk 35")
add("Java 17 compile target", "JavaVersion.VERSION_17" in gradle, "source/target compatibility")

try:
    root = ET.fromstring(manifest_text)
    permissions = [node.attrib.get(ANDROID_NS + "name", "") for node in root.findall("uses-permission")]
    add("Least privilege: INTERNET is the only permission", permissions == ["android.permission.INTERNET"], f"permissions={permissions}")
    application = root.find("application")
    cleartext = application.attrib.get(ANDROID_NS + "usesCleartextTraffic") if application is not None else None
    hw = application.attrib.get(ANDROID_NS + "hardwareAccelerated") if application is not None else None
    add("Cleartext HTTP disabled", cleartext == "false", f"usesCleartextTraffic={cleartext}")
    add("Application hardware acceleration enabled", hw == "true", f"hardwareAccelerated={hw}")
    activity = application.find("activity") if application is not None else None
    exported = activity.attrib.get(ANDROID_NS + "exported") if activity is not None else None
    add("Launcher activity explicitly exported", exported == "true", f"exported={exported}")
    categories = [c.attrib.get(ANDROID_NS + "name", "") for c in root.findall(".//category")]
    add("Fire TV leanback launcher category", "android.intent.category.LEANBACK_LAUNCHER" in categories, str(categories))
    add("Standard launcher category", "android.intent.category.LAUNCHER" in categories, str(categories))
except Exception as exc:
    add("AndroidManifest XML parses", False, repr(exc))
else:
    add("AndroidManifest XML parses", True, "well-formed XML")

checks = [
    ("JavaScript enabled through production WebView settings", "setJavaScriptEnabled(true)"),
    ("DOM storage enabled", "setDomStorageEnabled(true)"),
    ("Media playback user gesture relaxed for TV playback", "setMediaPlaybackRequiresUserGesture(false)"),
    ("File access disabled", "setAllowFileAccess(false)"),
    ("Content access disabled", "setAllowContentAccess(false)"),
    ("Mixed content prohibited", "MIXED_CONTENT_NEVER_ALLOW"),
    ("Third-party cookies explicitly enabled for provider auth", "setAcceptThirdPartyCookies(webView, true)"),
    ("Fullscreen video production callback", "onShowCustomView"),
    ("Fullscreen exit production callback", "onHideCustomView"),
    ("Fire TV Menu key app controls", "KEYCODE_MENU"),
    ("Activity pre-WebView key dispatch override", "public boolean dispatchKeyEvent(KeyEvent event)"),
    ("Cursor keys consumed before WebView", "Consume both DOWN and UP before WebView"),
    ("Cursor dispatch directional helper", "isCursorDirectionKey"),
    ("Cursor dispatch Select/Enter helper", "isCursorNavigationKey"),
    ("Native cursor overlay exists", "private final class CursorView extends View"),
    ("Compact cursor overlay is 48dp", "cursorOverlaySize = dp(48)"),
    ("Cursor uses translated view instead of full-screen canvas coordinates", "setTranslationX(newX - getWidth() / 2f)"),
    ("D-pad cursor movement fallback path", "moveCursor(keyCode"),
    ("Smooth cursor direction start", "startCursorDirection"),
    ("Smooth cursor direction stop", "stopCursorDirection"),
    ("Smooth cursor vsync loop", "postOnAnimation(cursorMovementFrame)"),
    ("Smooth cursor elapsed-time acceleration", "CURSOR_MAX_PIXELS_PER_SECOND = 720f"),
    ("Precision 2-pixel nudge", "CURSOR_TAP_NUDGE_PIXELS = 2f"),
    ("Center/Enter cursor click production path", "performCursorClick()"),
    ("Cursor click uses WebView touch dispatch", "webView.dispatchTouchEvent(down)"),
    ("Cursor hides during fullscreen", "cursorView.setVisibility(View.GONE)"),
    ("Cursor preference persisted", "KEY_CURSOR_ENABLED"),
    ("Build 2 migration enables cursor", ".putBoolean(KEY_CURSOR_ENABLED, true)"),
    ("Build 2 migration disables legacy focus default", ".putBoolean(KEY_TV_FOCUS, false)"),
    ("Page Zoom setting exists", "KEY_PAGE_ZOOM"),
    ("Page Zoom default is 75 percent", "DEFAULT_PAGE_ZOOM = 75"),
    ("Page Zoom minimum is 0", "MIN_PAGE_ZOOM = 0"),
    ("Page Zoom maximum is 500", "MAX_PAGE_ZOOM = 500"),
    ("Page Zoom direct numeric entry", "TYPE_CLASS_NUMBER"),
    ("Page Zoom custom slider", "slider.setMax(MAX_PAGE_ZOOM)"),
    ("Page Zoom one-percent controls", "minus.setText(\"-1\")"),
    ("Page Zoom reset 100 control", "reset.setText(\"Reset 100%\")"),
    ("Page Zoom live CSS style injection", "firetv-page-zoom-style"),
    ("Page Zoom CSS zoom property", "html{zoom:"),
    ("Page Zoom baseline WebView scale fixed at 100", "webView.setInitialScale(100)"),
    ("Page Zoom menu is exposed", "showPageZoomDialog"),
    ("WebView native compositor layer mode", "webView.setLayerType(View.LAYER_TYPE_NONE, null)"),
    ("Fullscreen media container is transparent", "customViewContainer.setBackgroundColor(Color.TRANSPARENT)"),
    ("Fullscreen keeps WebView attached but invisible", "webView.setVisibility(View.INVISIBLE)"),
    ("Fullscreen overlay brought to front", "customViewContainer.bringToFront()"),
    ("Popup login route is one-shot", "final boolean[] routed = new boolean[]{false}"),
    ("Amazon Silk playback fallback package", "SILK_PACKAGE = \"com.amazon.cloud9\""),
    ("Silk playback fallback menu", "Open Current Page in Silk (Video Fallback)"),
    ("Silk fallback production method", "openCurrentPageInSilk()"),
    ("Cookie flush after navigation", "CookieManager.getInstance().flush()"),
    ("Default D-pad path avoids DOM focus scanning", "if (customView == null && isCursorEnabled())"),
    ("Legacy focus fallback retained", "moveWebFocus(boolean forward)"),
    ("Settings persistence uses synchronous verification path", ".commit()"),
    ("Safe Self-Test present", "runSafeSelfTest"),
    ("Settings persistence self-test write/reload/compare", "Settings persistence write -> reload/read -> compare -> delete"),
    ("Cursor movement self-test through production method", "Native cursor production movement path"),
    ("Pre-WebView dispatch regression self-test", "Activity pre-WebView D-pad dispatch interception"),
    ("Page Zoom persistence/live-apply self-test", "Page Zoom 0-500 persistence + live production apply -> restore"),
    ("Fullscreen compositor self-test", "Fullscreen overlay compositor production path"),
    ("Hardware acceleration runtime self-test", "Hardware-accelerated WebView runtime"),
    ("Data persistence self-test write/reload/compare", "Project data write -> reload/read -> compare -> delete"),
    ("Widevine runtime diagnostic", "MediaDrm.isCryptoSchemeSupported(WIDEVINE_UUID)"),
    ("No WebView remote debugging", "setWebContentsDebuggingEnabled(false)"),
    ("App-local web-data clear path", "clearAppWebData"),
    ("Bounded log rotation", "MAX_FILES = 5"),
    ("Log size bound", "MAX_BYTES = 1024L * 1024L"),
]
for name, needle in checks:
    add(name, needle in main, needle)

# Build 7 regressions reported on physical Fire TV: zoom must never reload the page,
# and the cursor must not return to a full-screen redraw surface.
zoom_match = re.search(r"private boolean setPageZoom\(int percent, boolean applyNow\) \{(.*?)\n    \}", main, re.S)
zoom_body = zoom_match.group(1) if zoom_match else ""
add("Page Zoom production setter does not reload WebView", bool(zoom_match) and "webView.reload()" not in zoom_body, "live CSS apply must not trigger endless page loads")
add("Page Zoom production setter calls live document apply", "applyPageZoomToCurrentDocument();" in zoom_body, "same production setter as UI")
add("Cursor overlay is not MATCH_PARENT", "root.addView(cursorView, new FrameLayout.LayoutParams(cursorOverlaySize, cursorOverlaySize))" in main, "small translated overlay")

for forbidden in [
    "android.permission.READ_CONTACTS",
    "android.permission.READ_SMS",
    "android.permission.RECORD_AUDIO",
    "android.permission.CAMERA",
    "android.permission.ACCESS_FINE_LOCATION",
    "android.permission.MANAGE_EXTERNAL_STORAGE",
    "setWebContentsDebuggingEnabled(true)",
    "onReceivedSslError",
]:
    add(f"Forbidden/high-risk capability absent: {forbidden}", forbidden not in manifest_text + main, forbidden)

# Privacy and regression invariants.
add("Navigation logging remains host-only", 'logger.log("PAGE_FINISHED host=" + safeHost(url))' in main, "No full page URL in normal navigation log")
add("Diagnostics declare no credential/token collection", "No passwords, provider tokens" in main, "privacy statement present")
add("Build 7 cursor/zoom/video fallback changes documented", all(term in readme.lower() for term in ["small 48dp", "live", "silk"]), "Build 7 targeted corrective changes")
add("Build info matches Version + Build", "Version: 0.1" in build_info and "Build: 7" in build_info, "BUILD_INFO.md")
add("Build 7 self-test report filename", "SafeSelfTest-v0.1-Build7.txt" in main, "current build report path")

# Simple structural sanity checks that catch accidental truncation.
add("MainActivity brace balance", main.count("{") == main.count("}"), f"open={main.count('{')} close={main.count('}')}")
add("MainActivity parenthesis count sanity", abs(main.count("(") - main.count(")")) == 0, f"open={main.count('(')} close={main.count(')')}")

pass_count = sum(1 for status, _, _ in results if status == "PASS")
fail_count = sum(1 for status, _, _ in results if status == "FAIL")
REPORT.parent.mkdir(parents=True, exist_ok=True)
master = ROOT.parents[1] / "MASTER_RULES.md"
master_sha = hashlib.sha256(master.read_bytes()).hexdigest() if master.is_file() else "unavailable"

lines = [
    "DisneyNOW Fire TV Web Wrapper - STATIC / RELEASE AUDIT",
    "Version: 0.1 Build 7",
    f"MASTER_RULES SHA-256: {master_sha}",
    "",
]
for i, (status, name, detail) in enumerate(results, start=1):
    lines.append(f"{i}. {status} - {name} | {detail}")
lines += [
    "",
    f"STATIC TOTAL: PASS={pass_count} FAIL={fail_count}",
    "RESULT: PASS" if fail_count == 0 else "RESULT: FAIL",
    "",
    "Runtime Fire TV ad/protected-video rendering, Amazon Silk fallback playback, real provider sign-in stability, DRM license negotiation, live custom Page Zoom appearance, and physical remote behavior are not claimed by this static audit.",
]
REPORT.write_text("\n".join(lines) + "\n", encoding="utf-8")
print(REPORT.read_text(encoding="utf-8"))
sys.exit(0 if fail_count == 0 else 1)
