# Build information

- Project: DisneyNOW Fire TV Web Wrapper
- Version: 0.1
- Build: 7
- Android versionCode: 7
- Package ID: `com.fireworkstars46.disneynowfiretv`
- Release state: NOT DONE pending physical Fire TV cursor, live zoom, ad/protected-video, login, and Silk-fallback testing.

Build 7 corrects Build 6's physically reported laggy full-screen cursor redraw path and ineffective reload-based zoom. It uses a compact translated cursor surface with vsync-timed motion, live CSS zoom with no page reload, a fullscreen WebView-invisible compositor experiment, and an explicit Amazon Silk playback fallback. Permanent signing identity and in-place update compatibility are preserved.
