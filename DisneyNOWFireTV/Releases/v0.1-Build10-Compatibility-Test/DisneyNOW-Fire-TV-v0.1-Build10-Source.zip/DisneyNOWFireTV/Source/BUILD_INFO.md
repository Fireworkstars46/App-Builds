# Build information

- Project: DisneyNOW Fire TV Hybrid TV Shell
- Version: 0.1
- Build: 10
- Android versionCode: 10
- Package ID: `com.fireworkstars46.disneynowfiretv`
- Release state: NOT DONE pending physical Fire TV testing of the new native-player handoff diagnostics, WebView/native playback, Widevine negotiation, navigation responsiveness, provider login, ads/program video, whole-page zoom, Silk fallback, and Debug Mode/reporting.

Build 10 is a targeted diagnostic/corrective update based on the physical Build 9 report. Build 9 proved that the Fire TV WebView sees repeated authenticated-session HLS manifest requests while the native Media3 player remains uncreated unless the user explicitly invokes the native-player action, and no high-confidence DRM license request was captured by the existing classifier. Build 10 preserves the Build 8/9 architecture and adds a privacy-safe handoff state trace around manifest readiness, session-context reconstruction, Media3 creation, MediaItem/DRM configuration, prepare/play calls, playback states, and safe exception-class chains. It also records host-only/type-only hints for non-GET subresource requests that happen shortly after a manifest so a hidden DRM/license transaction can be identified without exporting the request URL, body, cookie, authorization value, provider token, query string, or typed input.

The package ID, app data/settings/cookies, minSdk 22 compatibility floor, Media3 1.8.1 pin, WebView remote-debugging prohibition, DRM/entitlement safety boundary, Silk fallback, and permanent release-signing identity remain unchanged.
