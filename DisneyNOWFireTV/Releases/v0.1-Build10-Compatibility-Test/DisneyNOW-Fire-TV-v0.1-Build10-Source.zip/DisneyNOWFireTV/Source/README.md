# Source — DisneyNOW Fire TV Hybrid TV Shell v0.1 Build 10

Build 10 is a targeted native-player handoff diagnostic update based on the physical Build 9 debug report. It preserves the package/update identity, WebView/provider flow, Native TV Navigation, compatibility cursor, Performance Mode, whole-WebView Page Zoom, privacy-safe Debug Mode, experimental Media3 HLS/DASH/Widevine path, and Silk fallback.

Changes in Build 10:
- **Native handoff stage trace:** records privacy-safe stage names from manifest readiness through session context, Media3 creation, MediaItem/DRM configuration, prepare, play, playback state, and error.
- **Actionable native-player menu state:** the existing native-player action now shows whether it is waiting for a stream or ready with HLS/DASH detected.
- **One-time stream-ready hint:** after the first HLS/DASH manifest is observed on a page, the app tells the user how to invoke the native player if WebView playback fails.
- **Safe session-context diagnostics:** records only header counts/presence booleans and cookie availability, never cookie/header values.
- **Possible DRM transaction hints:** while Debug Mode is enabled, host-only/method/content-type-category details are recorded for non-GET subresource requests within two minutes of an observed manifest. Full URLs, request bodies, tokens, cookies, and authorization values are never exported.
- **Player failure detail:** Media3 error codes plus exception class/cause-chain names are recorded without exception messages that could contain protected URLs.
- **New counters:** manifest-ready events, native handoff attempts, player creations, prepare calls, and possible post-manifest non-GET requests are included in Debug Snapshot/export.
- **Build 9 Debug Mode retained:** WebView/HTTP errors, page-load timing, Media3 state/error counts, D-pad dispatch timing, memory status, and bounded safe app logging remain available.
- **Security boundary retained:** `WebView.setWebContentsDebuggingEnabled(false)` remains enforced; no DRM keys are extracted, no entitlement/token/license is forged, and no DRM is bypassed.

Preserved architecture details:
- **Whole-page Page Zoom 0-500:** Android WebView-level scaling, not CSS-only zoom.
- **Experimental native playback:** AndroidX Media3/ExoPlayer uses only legitimately observed authenticated-session HLS/DASH requests and Android Widevine when a matching legitimate license request is observed.
- **Media3 compatibility:** pinned to Media3 `1.8.1` for the existing `minSdk 22` Fire TV compatibility floor.
- **Update compatibility:** package ID and permanent release signer are unchanged. Install Build 10 over Build 9; do not uninstall.

Build 10 remains **NOT DONE - COMPATIBILITY TEST** until a physical Fire TV test exercises the native-player action after HLS detection and exports the resulting Debug Report.
