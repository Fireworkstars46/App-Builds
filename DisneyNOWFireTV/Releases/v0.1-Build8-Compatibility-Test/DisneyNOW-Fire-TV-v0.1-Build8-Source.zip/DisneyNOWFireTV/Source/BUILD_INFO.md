# Build information

- Project: DisneyNOW Fire TV Hybrid TV Shell
- Version: 0.1
- Build: 8
- Android versionCode: 8
- Package ID: `com.fireworkstars46.disneynowfiretv`
- Release state: NOT DONE pending physical Fire TV testing of navigation responsiveness, whole-page zoom, provider login, WebView playback, experimental native Media3 playback/Widevine negotiation, ads/program video, and Silk fallback.

Build 8 is a corrective architectural compatibility build after physical Fire TV testing showed Build 7 remained laggy, still produced the playback error, and CSS zoom did not scale the complete page. It preserves the established package/signing/update identity and app-local cookies/settings, changes the default interaction mode to low-overhead native WebView TV navigation, keeps the cursor as a compatibility option, adds a performance mode that suppresses expensive page animations, replaces CSS zoom with WebView-level whole-page zoom from 0 through 500, and adds an experimental Media3/ExoPlayer player path for HLS/DASH requests legitimately exposed by the authenticated DisneyNOW session. The native path uses Android Widevine normally when a matching license endpoint is observed; it does not extract keys, bypass DRM, or copy Disney proprietary player/authentication code.
