import SwiftUI

@main
struct TimeStepApp: App {
    var body: some Scene {
        WindowGroup {
            CalculatorView()
        }
    }
}
