import XCTest
@testable import TimeStepCore

final class KeypadTests: XCTestCase {
    private func newKeypad() throws -> KeypadCalculator {
        KeypadCalculator(clock: try ClockEngine.Calculator(startMinuteOfDay: 9 * 60))
    }

    func testKeypadRepeatsIndefinitely() throws {
        var pad = try newKeypad()
        pad.chooseOperation(adding: true)
        pad.typeDigits("4")
        try pad.pressEquals()
        XCTAssertEqual(pad.clock.reading.text12, "1:00 PM")
        try pad.pressEquals()
        XCTAssertEqual(pad.clock.reading.text24, "17:00")
        for _ in 1...498 { try pad.pressEquals() }
        XCTAssertEqual(pad.clock.equalPresses, 500)
    }

    func testSetStartingClockWithTimeAndPeriod() throws {
        var pad = try newKeypad()
        try pad.pressStart()
        pad.typeDigits("11")
        pad.typeColon()
        pad.typeDigits("30")
        pad.toggleAMPM()
        try pad.pressStart()
        XCTAssertEqual(pad.clock.reading.text12, "11:30 PM")
        XCTAssertEqual(pad.clock.equalPresses, 0)
    }

    func testClockShorthand() throws {
        var pad = try newKeypad()
        try pad.pressStart()
        pad.typeDigits("930")
        try pad.pressEquals()
        XCTAssertEqual(pad.clock.reading.text12, "9:30 AM")
    }

    func testSubtractMinutesAndCrossMidnight() throws {
        var pad = try newKeypad()
        pad.chooseOperation(adding: false)
        pad.typeDigits("9")
        pad.typeColon()
        pad.typeDigits("30")
        try pad.pressEquals()
        XCTAssertEqual(pad.clock.reading.text12, "11:30 PM")
        XCTAssertEqual(pad.clock.reading.dayOffset, -1)
    }

    func testClearingEntryDoesNotResetCalculation() throws {
        var pad = try newKeypad()
        try pad.pressEquals()
        pad.typeDigits("12")
        pad.clearEntry()
        XCTAssertEqual(pad.clock.reading.text12, "1:00 PM")
        try pad.pressEquals()
        XCTAssertEqual(pad.clock.reading.text12, "5:00 PM")
    }

    func testBackspaceAndChangingSign() throws {
        var pad = try newKeypad()
        pad.typeDigits("45")
        pad.backspace()
        pad.chooseOperation(adding: false)
        try pad.pressEquals()
        XCTAssertEqual(pad.clock.reading.text12, "5:00 AM")
        XCTAssertEqual(pad.stepHours, 4)
        XCTAssertFalse(pad.adding)
    }

    func testInvalidInputDoesNotApplyOrOverwriteStep() throws {
        var pad = try newKeypad()
        pad.typeDigits("4")
        pad.typeColon()
        pad.typeDigits("60")
        XCTAssertThrowsError(try pad.pressEquals())
        XCTAssertEqual(pad.clock.reading.text12, "9:00 AM")
        XCTAssertEqual(pad.stepHours, 4)
        XCTAssertEqual(pad.pending, "4:60")
    }

    func testResetKeepsDuration() throws {
        var pad = try newKeypad()
        pad.typeDigits("5")
        try pad.pressEquals()
        pad.pressReset()
        XCTAssertEqual(pad.clock.reading.text12, "9:00 AM")
        XCTAssertEqual(pad.stepHours, 5)
        XCTAssertEqual(pad.clock.equalPresses, 0)
    }

    func testIOSClearKeySwitchesCToAC() throws {
        var pad = try newKeypad()
        XCTAssertEqual(pad.clearKeyTitle, "AC")
        pad.typeDigits("17")
        XCTAssertEqual(pad.clearKeyTitle, "C")
        pad.pressClearKey()
        XCTAssertEqual(pad.clearKeyTitle, "AC")
        XCTAssertEqual(pad.pending, "")
        XCTAssertEqual(pad.enteredTime, "+ —  hours:minutes")
        XCTAssertEqual(pad.clock.reading.text12, "9:00 AM")
        pad.typeDigits("4")
        try pad.pressEquals()
        XCTAssertEqual(pad.clock.reading.text12, "1:00 PM")
        try pad.pressEquals()
        XCTAssertEqual(pad.clock.reading.text12, "5:00 PM")
        pad.pressClearKey()
        XCTAssertEqual(pad.clock.reading.text12, "9:00 AM")
        XCTAssertEqual(pad.clock.equalPresses, 0)
        XCTAssertEqual(pad.stepHours, 4)
    }

    func testClearInputPreservesResultAndRepeatOperation() throws {
        var pad = try newKeypad()
        try pad.pressEquals()
        pad.typeDigits("6")
        pad.pressClearKey()
        XCTAssertEqual(pad.clock.reading.text24, "13:00")
        XCTAssertTrue(pad.entryCleared)
        try pad.pressEquals()
        XCTAssertEqual(pad.clock.reading.text24, "17:00")
        XCTAssertFalse(pad.entryCleared)
    }

    func testACWhileEditingStartKeepsChosenStartTime() throws {
        var pad = try newKeypad()
        try pad.pressStart()
        pad.typeDigits("11")
        pad.pressClearKey() // C clears only the entered start digits.
        XCTAssertTrue(pad.editingStart)
        XCTAssertEqual(pad.clearKeyTitle, "AC")
        pad.pressClearKey() // AC returns to the established start time.
        XCTAssertFalse(pad.editingStart)
        XCTAssertEqual(pad.clock.reading.text12, "9:00 AM")
    }
}
