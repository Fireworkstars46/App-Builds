# Time Step 1.0.0 Build 4
Targeted change: nonblank iPhone Home Screen AppIcon artwork compiled into Assets.car; prior calculator features unchanged.
Original bundle ID: com.fireworkstars46.timestep.
Keeps prior app storage identifiers and existing repeat-equals behavior.
iOS 16 deployment target retained.
Cloud compilation and host-side tests performed in the GitHub Actions run.
Actual device installation, iOS UI runtime and sign/update compatibility remain NOT TESTED.
This is an unsigned draft IPA for local Apple ID signing in Sideloadly.
