import Foundation

/// Clock-only arithmetic: every hour is exactly 60 minutes, independent of DST.
/// The resulting clock time wraps at midnight while the day offset is retained.
public enum ClockEngine {
    public static let minutesPerDay = 24 * 60
    public static let maximumStepHours = 99_999

    public enum CalculatorError: Error, Equatable {
        case invalidStartTime
        case invalidDuration
        case calculationOverflow
    }

    public struct Reading: Equatable {
        public let totalMinutes: Int

        public init(totalMinutes: Int) {
            self.totalMinutes = totalMinutes
        }

        public var minuteOfDay: Int {
            let remainder = totalMinutes % ClockEngine.minutesPerDay
            return remainder < 0 ? remainder + ClockEngine.minutesPerDay : remainder
        }

        public var dayOffset: Int {
            let quotient = totalMinutes / ClockEngine.minutesPerDay
            return quotient - (totalMinutes % ClockEngine.minutesPerDay < 0 ? 1 : 0)
        }

        public var hour24: Int { minuteOfDay / 60 }
        public var minute: Int { minuteOfDay % 60 }
        public var hour12: Int { hour24 % 12 == 0 ? 12 : hour24 % 12 }
        public var period: String { hour24 < 12 ? "AM" : "PM" }

        public var text12: String {
            String(format: "%d:%02d %@", hour12, minute, period)
        }

        public var text24: String {
            String(format: "%02d:%02d", hour24, minute)
        }

        public var dayDescription: String {
            switch dayOffset {
            case 0: return "Same day"
            case 1: return "Next day"
            case -1: return "Previous day"
            case 2...: return "\(dayOffset) days later"
            default: return "\(-dayOffset) days earlier"
            }
        }
    }

    public struct Calculator: Equatable {
        public private(set) var startMinuteOfDay: Int
        public private(set) var currentTotalMinutes: Int
        public private(set) var equalPresses: Int

        public init(startMinuteOfDay: Int = 9 * 60,
                    currentTotalMinutes: Int? = nil,
                    equalPresses: Int = 0) throws {
            guard (0..<ClockEngine.minutesPerDay).contains(startMinuteOfDay),
                  equalPresses >= 0 else {
                throw CalculatorError.invalidStartTime
            }
            self.startMinuteOfDay = startMinuteOfDay
            self.currentTotalMinutes = currentTotalMinutes ?? startMinuteOfDay
            self.equalPresses = equalPresses
        }

        public var reading: Reading { Reading(totalMinutes: currentTotalMinutes) }

        /// Each call applies exactly one user-selected step. There is no timer,
        /// automatic repetition or preset repetition limit.
        public mutating func pressEquals(hours: Int, minutes: Int, adding: Bool) throws {
            guard (0...ClockEngine.maximumStepHours).contains(hours),
                  (0..<60).contains(minutes) else {
                throw CalculatorError.invalidDuration
            }

            let unsignedChange = hours * 60 + minutes
            let signedChange = adding ? unsignedChange : -unsignedChange
            let (updatedMinutes, didOverflow) = currentTotalMinutes.addingReportingOverflow(signedChange)
            let (updatedPresses, didPressesOverflow) = equalPresses.addingReportingOverflow(1)
            guard !didOverflow, !didPressesOverflow else {
                throw CalculatorError.calculationOverflow
            }
            currentTotalMinutes = updatedMinutes
            equalPresses = updatedPresses
        }

        public mutating func setStartTime(minuteOfDay: Int) throws {
            guard (0..<ClockEngine.minutesPerDay).contains(minuteOfDay) else {
                throw CalculatorError.invalidStartTime
            }
            startMinuteOfDay = minuteOfDay
            reset()
        }

        public mutating func reset() {
            currentTotalMinutes = startMinuteOfDay
            equalPresses = 0
        }
    }
}
