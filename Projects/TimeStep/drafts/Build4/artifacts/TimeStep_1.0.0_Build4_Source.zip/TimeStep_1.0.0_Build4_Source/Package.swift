// swift-tools-version: 5.7
import PackageDescription

let package = Package(
    name: "TimeStepCore",
    platforms: [.iOS(.v16)],
    products: [
        .library(name: "TimeStepCore", targets: ["TimeStepCore"])
    ],
    targets: [
        .target(name: "TimeStepCore", path: "TimeStepCore"),
        .testTarget(name: "TimeStepCoreTests", dependencies: ["TimeStepCore"], path: "Tests/TimeStepCoreTests")
    ]
)
