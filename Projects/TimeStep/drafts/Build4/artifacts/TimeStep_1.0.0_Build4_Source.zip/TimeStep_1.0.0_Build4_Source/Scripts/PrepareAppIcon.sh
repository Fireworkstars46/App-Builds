#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ICONS="$ROOT/TimeStep/Assets.xcassets/AppIcon.appiconset"
SOURCE="$ICONS/IconArtwork.jpg"
test -s "$SOURCE"
test -s "$ICONS/Contents.json"
for size in 40 60 58 87 80 120 180 1024; do
  /usr/bin/sips -s format png -z "$size" "$size" "$SOURCE" --out "$ICONS/icon-${size}.png" >/dev/null
  test -s "$ICONS/icon-${size}.png"
  actual=$(/usr/bin/sips -g pixelWidth "$ICONS/icon-${size}.png" | awk '/pixelWidth/{print $2}')
  test "$actual" = "$size" || { echo "Incorrect icon pixel width ${size}: ${actual}"; exit 1; }
done
/usr/bin/sips -g hasAlpha "$ICONS/icon-1024.png" | tee "$ROOT/TimeStepIcon_Metadata.txt"
if ! grep -q 'hasAlpha: no' "$ROOT/TimeStepIcon_Metadata.txt"; then
  echo "Marketing app icon incorrectly contains an alpha channel" >&2
  exit 1
fi
python3 - "$ICONS" <<'PY2'
import json, pathlib, sys, struct
p=pathlib.Path(sys.argv[1]); data=json.loads((p/'Contents.json').read_text())
assert len(data['images'])==9
for entry in data['images']:
    name=entry['filename']; b=(p/name).read_bytes()
    assert b[:8]==b'\x89PNG\r\n\x1a\n', f'Bad icon PNG: {name}'
    w,h=struct.unpack('>II',b[16:24])
    target=int(entry['size'].split('x')[0])*int(entry['scale'][0])
    assert (w,h)==(target,target), f'Bad dimensions {name}: {w}x{h} != {target}'
    assert len(b)>2000, f'Suspiciously blank icon: {name}'
print('PASS: 9 icon catalog entries have real image bytes and correct dimensions')
PY2
