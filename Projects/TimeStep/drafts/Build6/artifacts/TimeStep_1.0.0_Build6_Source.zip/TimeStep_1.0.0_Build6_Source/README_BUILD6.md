# Time Step — Version 1.0.0 · Build 6 (simplified time entry)

## Quick use

1. Tap the native **Start Time** picker and choose 9:00 AM.
2. Enter **3** using the number buttons.
3. Select **Hours** to add three hours or **Minutes** to add three minutes.
4. Choose **+ Add** or **− Subtract**.
5. Tap **= Calculate / Repeat**. Tap **=** again to repeat exactly that adjustment.

For example, 9:00 AM + 3 hours = 12:00 PM, or 9:00 AM + 3 minutes = 9:03 AM.

**C** clears digits currently entered. **AC** or **Reset** clears the result display (blank). **⌫** deletes one digit. The starting time is preserved in app settings so it can be reused. In the new UI, minute amounts do not require the old `0:03` colon notation; the old parser is kept internally for backwards compatibility.

## Compatibility

- Original bundle identifier: `com.fireworkstars46.timestep`
- Version: `1.0.0`, Build: `6`, minimum iOS: `16.0`
- Unsigned pre-signing iPhone IPA for free local Sideloadly Apple ID signing.
- Preserves Build 1–5 app settings and the existing clock calculation engine.
- Keeps existing icon assets and Build 5 explicit iPhone icon packaging.
- No new permissions, network access, or update mechanism.
- Signing identity and installed-update compatibility cannot be verified in this cloud build; **do not uninstall the previous app on a signing mismatch**.
- Final status NOT DONE until device GUI, persistence, signing/update and release gates are verified.
