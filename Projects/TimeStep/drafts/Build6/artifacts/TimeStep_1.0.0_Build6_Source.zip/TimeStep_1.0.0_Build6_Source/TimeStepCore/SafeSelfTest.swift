import Foundation

/// Safe, side-effect-free checks exercising the same production calculator.
public enum SafeSelfTest {
    public struct CaseResult: Identifiable {
        public let name: String
        public let passed: Bool
        public let actual: String
        public var id: String { name }
    }

    public static func run() -> [CaseResult] {
        var output: [CaseResult] = []

        func record(_ name: String, _ actual: String, _ expected: String) {
            output.append(CaseResult(name: name, passed: actual == expected,
                                     actual: "Expected \(expected); got \(actual)"))
        }

        do {
            var calculator = try ClockEngine.Calculator(startMinuteOfDay: 9 * 60)
            try calculator.pressEquals(hours: 4, minutes: 0, adding: true)
            record("First = (+4h)", calculator.reading.text12 + " | " + calculator.reading.text24,
                   "1:00 PM | 13:00")
            try calculator.pressEquals(hours: 4, minutes: 0, adding: true)
            record("Second = (+4h)", calculator.reading.text12, "5:00 PM")
            try calculator.pressEquals(hours: 4, minutes: 0, adding: true)
            record("Third = (+4h)", calculator.reading.text24, "21:00")
            try calculator.pressEquals(hours: 4, minutes: 0, adding: true)
            record("Across midnight", calculator.reading.text12 + " / " + calculator.reading.dayDescription,
                   "1:00 AM / Next day")
            calculator.reset()
            record("Reset", "\(calculator.reading.text12) / \(calculator.equalPresses)", "9:00 AM / 0")
            try calculator.pressEquals(hours: 4, minutes: 0, adding: false)
            record("Subtract 4h", calculator.reading.text12, "5:00 AM")
            try calculator.setStartTime(minuteOfDay: 15)
            record("Changing start resets", "\(calculator.reading.text24) / \(calculator.equalPresses)", "00:15 / 0")
            try calculator.pressEquals(hours: 0, minutes: 30, adding: false)
            record("Negative date rollover", calculator.reading.text24 + " / " + calculator.reading.dayDescription,
                   "23:45 / Previous day")
            record("12 AM formatting", ClockEngine.Reading(totalMinutes: 0).text12, "12:00 AM")
            record("12 PM formatting", ClockEngine.Reading(totalMinutes: 720).text12, "12:00 PM")
            record("24-hour formatting", ClockEngine.Reading(totalMinutes: 13 * 60).text24, "13:00")
            do {
                try calculator.pressEquals(hours: 1, minutes: 60, adding: true)
                record("Invalid minutes rejected", "Accepted", "Rejected")
            } catch ClockEngine.CalculatorError.invalidDuration {
                record("Invalid minutes rejected", "Rejected", "Rejected")
            }
        } catch {
            output.append(CaseResult(name: "Calculator execution", passed: false,
                                     actual: "Unexpected error: \(error)"))
        }
        do {
            var keypad = KeypadCalculator(clock: try ClockEngine.Calculator(startMinuteOfDay: 540))
            keypad.typeDigits("4")
            try keypad.pressEquals()
            record("Keypad +4 hours", keypad.clock.reading.text24, "13:00")
            try keypad.pressEquals()
            record("Keypad manual repeat", keypad.clock.reading.text12, "5:00 PM")
            keypad.typeDigits("8")
            keypad.backspace()
            record("Keypad backspace", keypad.pending.isEmpty ? "Empty" : "Not empty", "Empty")
            keypad.chooseOperation(adding: false)
            try keypad.pressEquals()
            record("Keypad minus", keypad.clock.reading.text24, "13:00")
            keypad.pressReset()
            record("Keypad reset", keypad.clock.reading.text12, "9:00 AM")
            try keypad.pressStart()
            keypad.typeDigits("930")
            keypad.toggleAMPM()
            try keypad.pressStart()
            record("Keypad AM/PM start", keypad.clock.reading.text12, "9:30 PM")
            keypad.typeDigits("8")
            record("C appears while typing", keypad.clearKeyTitle, "C")
            keypad.pressClearKey()
            record("C clears visible entry", keypad.clearKeyTitle + " / " + keypad.pending + " / " + (keypad.entryCleared ? "cleared" : "not cleared"), "AC /  / cleared")
            record("C preserves time", keypad.clock.reading.text12, "9:30 PM")
            keypad.pressClearKey()
            record("AC resets calculation", keypad.clock.reading.text12 + " / " + String(keypad.clock.equalPresses), "9:30 PM / 0")
            record("AC preserves repeat step", String(keypad.stepHours), "4")
            record("AC screen blank (12h)", keypad.displayedTime12, "")
            record("AC screen blank (24h)", keypad.displayedTime24, "")
            record("AC input blank", keypad.enteredTime, "")
            record("AC persists clear flag", String(keypad.allCleared), "true")
            try keypad.pressEquals()
            record("No invisible = after AC", String(keypad.clock.equalPresses), "0")
            keypad.typeDigits("4")
            record("Digit appears in main display", keypad.displayedTime12, "4")
            var easy = KeypadCalculator(clock: try ClockEngine.Calculator(startMinuteOfDay: 9 * 60))
            easy.chooseUnit(.minutes)
            easy.typeDigits("3")
            try easy.pressEquals()
            record("Simple minutes entry", easy.clock.reading.text12, "9:03 AM")
            try easy.pressEquals()
            record("Minutes repeat", easy.clock.reading.text12, "9:06 AM")
            try easy.setStartingMinuteOfDay(9 * 60)
            easy.chooseUnit(.hours)
            easy.typeDigits("3")
            try easy.pressEquals()
            record("Simple hours entry", easy.clock.reading.text12, "12:00 PM")
            easy.pressReset()
            record("Clear remains blank", easy.displayedTime12 + easy.displayedTime24, "")
        } catch {
            output.append(CaseResult(name: "Keypad execution", passed: false,
                                     actual: "Unexpected error: \(error)"))
        }
        return output
    }
}
