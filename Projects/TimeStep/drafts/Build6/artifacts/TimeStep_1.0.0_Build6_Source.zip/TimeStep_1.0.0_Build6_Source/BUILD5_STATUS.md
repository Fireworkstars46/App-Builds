# Time Step 1.0.0 Build 6
Targeted change: native start-time picker, Hours/Minutes selection, Add/Subtract, repeat equals; blank Reset and packaged app icon preserved.
Original bundle ID: com.fireworkstars46.timestep.
Keeps prior app storage identifiers and existing repeat-equals behavior.
iOS 16 deployment target retained.
Cloud compilation and host-side tests performed in the GitHub Actions run.
Actual device installation, iOS UI runtime and sign/update compatibility remain NOT TESTED.
This is an unsigned draft IPA for local Apple ID signing in Sideloadly.
