import XCTest
@testable import TimeStepCore

final class KeypadTests: XCTestCase {
    private func newKeypad() throws -> KeypadCalculator {
        KeypadCalculator(clock: try ClockEngine.Calculator(startMinuteOfDay: 9 * 60))
    }

    func testKeypadRepeatsIndefinitely() throws {
        var pad = try newKeypad()
        pad.chooseOperation(adding: true)
        pad.typeDigits("4")
        try pad.pressEquals()
        XCTAssertEqual(pad.clock.reading.text12, "1:00 PM")
        try pad.pressEquals()
        XCTAssertEqual(pad.clock.reading.text24, "17:00")
        for _ in 1...498 { try pad.pressEquals() }
        XCTAssertEqual(pad.clock.equalPresses, 500)
    }

    func testSetStartingClockWithTimeAndPeriod() throws {
        var pad = try newKeypad()
        try pad.pressStart()
        pad.typeDigits("11")
        pad.typeColon()
        pad.typeDigits("30")
        pad.toggleAMPM()
        try pad.pressStart()
        XCTAssertEqual(pad.clock.reading.text12, "11:30 PM")
        XCTAssertEqual(pad.clock.equalPresses, 0)
    }

    func testClockShorthand() throws {
        var pad = try newKeypad()
        try pad.pressStart()
        pad.typeDigits("930")
        try pad.pressEquals()
        XCTAssertEqual(pad.clock.reading.text12, "9:30 AM")
    }

    func testSubtractMinutesAndCrossMidnight() throws {
        var pad = try newKeypad()
        pad.chooseOperation(adding: false)
        pad.typeDigits("9")
        pad.typeColon()
        pad.typeDigits("30")
        try pad.pressEquals()
        XCTAssertEqual(pad.clock.reading.text12, "11:30 PM")
        XCTAssertEqual(pad.clock.reading.dayOffset, -1)
    }

    func testClearingEntryDoesNotResetCalculation() throws {
        var pad = try newKeypad()
        try pad.pressEquals()
        pad.typeDigits("12")
        pad.clearEntry()
        XCTAssertEqual(pad.clock.reading.text12, "1:00 PM")
        try pad.pressEquals()
        XCTAssertEqual(pad.clock.reading.text12, "5:00 PM")
    }

    func testBackspaceAndChangingSign() throws {
        var pad = try newKeypad()
        pad.typeDigits("45")
        pad.backspace()
        pad.chooseOperation(adding: false)
        try pad.pressEquals()
        XCTAssertEqual(pad.clock.reading.text12, "5:00 AM")
        XCTAssertEqual(pad.stepHours, 4)
        XCTAssertFalse(pad.adding)
    }

    func testInvalidInputDoesNotApplyOrOverwriteStep() throws {
        var pad = try newKeypad()
        pad.typeDigits("4")
        pad.typeColon()
        pad.typeDigits("60")
        XCTAssertThrowsError(try pad.pressEquals())
        XCTAssertEqual(pad.clock.reading.text12, "9:00 AM")
        XCTAssertEqual(pad.stepHours, 4)
        XCTAssertEqual(pad.pending, "4:60")
    }

    func testResetKeepsDuration() throws {
        var pad = try newKeypad()
        pad.typeDigits("5")
        try pad.pressEquals()
        pad.pressReset()
        XCTAssertEqual(pad.clock.reading.text12, "9:00 AM")
        XCTAssertEqual(pad.stepHours, 5)
        XCTAssertEqual(pad.clock.equalPresses, 0)
    }

    func testIOSClearKeySwitchesCToAC() throws {
        var pad = try newKeypad()
        XCTAssertEqual(pad.clearKeyTitle, "AC")
        pad.typeDigits("17")
        XCTAssertEqual(pad.clearKeyTitle, "C")
        pad.pressClearKey()
        XCTAssertEqual(pad.clearKeyTitle, "AC")
        XCTAssertEqual(pad.pending, "")
        XCTAssertEqual(pad.enteredTime, "")
        XCTAssertEqual(pad.clock.reading.text12, "9:00 AM")
        pad.typeDigits("4")
        try pad.pressEquals()
        XCTAssertEqual(pad.clock.reading.text12, "1:00 PM")
        try pad.pressEquals()
        XCTAssertEqual(pad.clock.reading.text12, "5:00 PM")
        pad.pressClearKey()
        XCTAssertEqual(pad.clock.reading.text12, "9:00 AM")
        XCTAssertEqual(pad.clock.equalPresses, 0)
        XCTAssertEqual(pad.stepHours, 4)
    }

    func testClearInputPreservesResultAndRepeatOperation() throws {
        var pad = try newKeypad()
        try pad.pressEquals()
        pad.typeDigits("6")
        pad.pressClearKey()
        XCTAssertEqual(pad.clock.reading.text24, "13:00")
        XCTAssertTrue(pad.entryCleared)
        try pad.pressEquals()
        XCTAssertEqual(pad.clock.reading.text24, "17:00")
        XCTAssertFalse(pad.entryCleared)
    }

    func testACWhileEditingStartKeepsChosenStartTime() throws {
        var pad = try newKeypad()
        try pad.pressStart()
        pad.typeDigits("11")
        pad.pressClearKey() // C clears only the entered start digits.
        XCTAssertTrue(pad.editingStart)
        XCTAssertEqual(pad.clearKeyTitle, "AC")
        pad.pressClearKey() // AC returns to the established start time.
        XCTAssertFalse(pad.editingStart)
        XCTAssertEqual(pad.clock.reading.text12, "9:00 AM")
    }

    func testResetShowsCompletelyBlankDisplay() throws {
        var pad = try newKeypad()
        try pad.pressEquals()
        XCTAssertEqual(pad.displayedTime12, "1:00 PM")
        pad.pressReset()
        XCTAssertEqual(pad.displayedTime12, "")
        XCTAssertEqual(pad.displayedTime24, "")
        XCTAssertEqual(pad.displayedStart, "")
        XCTAssertEqual(pad.enteredTime, "")
        XCTAssertEqual(pad.displayedDay, "")
        XCTAssertEqual(pad.displayedPresses, "")
        XCTAssertTrue(pad.displayBlank)
        XCTAssertTrue(pad.allCleared)
        XCTAssertEqual(pad.clock.startMinuteOfDay, 9 * 60)
        XCTAssertEqual(pad.clock.equalPresses, 0)
    }

    func testACIsBlankAndEqualsDoesNotRestoreClearedResult() throws {
        var pad = try newKeypad()
        pad.pressClearKey() // AC from no pending digits
        XCTAssertEqual(pad.clearKeyTitle, "AC")
        XCTAssertEqual(pad.displayedTime12, "")
        try pad.pressEquals() // On a fresh cleared screen this should not repeat an old operation.
        XCTAssertEqual(pad.displayedTime12, "")
        XCTAssertEqual(pad.clock.equalPresses, 0)
    }

    func testAfterClearTypingAppearsInLargeDisplay() throws {
        var pad = try newKeypad()
        pad.pressReset()
        pad.typeDigits("4")
        XCTAssertEqual(pad.displayedTime12, "4")
        XCTAssertEqual(pad.displayedTime24, "")
        XCTAssertEqual(pad.enteredTime, "+ 4 hours")
        try pad.pressEquals()
        XCTAssertEqual(pad.displayedTime12, "1:00 PM")
        XCTAssertEqual(pad.displayedTime24, "13:00")
    }

    func testCClearsEntryVisiblyWithoutLosingRepeat() throws {
        var pad = try newKeypad()
        try pad.pressEquals()
        pad.typeDigits("9")
        XCTAssertEqual(pad.displayedTime12, "9")
        pad.pressClearKey()
        XCTAssertEqual(pad.displayedTime12, "")
        XCTAssertEqual(pad.displayedTime24, "")
        XCTAssertEqual(pad.enteredTime, "")
        XCTAssertEqual(pad.clock.reading.text24, "13:00")
        try pad.pressEquals()
        XCTAssertEqual(pad.displayedTime24, "17:00")
    }

    func testBlankStateSurvivesReinitializationFromSavedState() throws {
        var pad = try newKeypad()
        pad.pressReset()
        let restored = KeypadCalculator(clock: pad.clock, stepHours: pad.stepHours,
                                        stepMinutes: pad.stepMinutes, adding: pad.adding,
                                        displayBlank: pad.displayBlank, allCleared: pad.allCleared)
        XCTAssertEqual(restored.displayedTime12, "")
        XCTAssertEqual(restored.displayedTime24, "")
        XCTAssertEqual(restored.enteredTime, "")
        XCTAssertTrue(restored.allCleared)
        XCTAssertEqual(restored.clock.startMinuteOfDay, pad.clock.startMinuteOfDay)
    }

    func testBackspaceToEmptyIsActuallyBlank() throws {
        var pad = try newKeypad()
        pad.typeDigits("78")
        pad.backspace()
        XCTAssertEqual(pad.displayedTime12, "7")
        pad.backspace()
        XCTAssertEqual(pad.displayedTime12, "")
        XCTAssertEqual(pad.displayedTime24, "")
        XCTAssertEqual(pad.enteredTime, "")
    }

    func testSimpleThreeHoursFromNineAM() throws {
        var pad = try newKeypad()
        pad.chooseUnit(.hours)
        pad.typeDigits("3")
        XCTAssertEqual(pad.enteredTime, "+ 3 hours")
        try pad.pressEquals()
        XCTAssertEqual(pad.clock.reading.text12, "12:00 PM")
        try pad.pressEquals()
        XCTAssertEqual(pad.clock.reading.text12, "3:00 PM")
        XCTAssertEqual(pad.clock.equalPresses, 2)
    }

    func testSimpleThreeMinutesFromNineAM() throws {
        var pad = try newKeypad()
        pad.chooseUnit(.minutes)
        pad.typeDigits("3")
        XCTAssertEqual(pad.enteredTime, "+ 3 minutes")
        try pad.pressEquals()
        XCTAssertEqual(pad.clock.reading.text12, "9:03 AM")
        XCTAssertEqual(pad.stepHours, 0)
        XCTAssertEqual(pad.stepMinutes, 3)
        try pad.pressEquals()
        XCTAssertEqual(pad.clock.reading.text12, "9:06 AM")
    }

    func testNinetyMinutesNormalizesToHourAndHalf() throws {
        var pad = try newKeypad()
        pad.chooseUnit(.minutes)
        pad.typeDigits("90")
        try pad.pressEquals()
        XCTAssertEqual(pad.clock.reading.text24, "10:30")
        XCTAssertEqual(pad.stepHours, 1)
        XCTAssertEqual(pad.stepMinutes, 30)
    }

    func testSimpleSubtractionThreeMinutesCrossesMidnight() throws {
        var pad = try KeypadCalculator(clock: ClockEngine.Calculator(startMinuteOfDay: 1))
        pad.chooseOperation(adding: false)
        pad.chooseUnit(.minutes)
        pad.typeDigits("3")
        try pad.pressEquals()
        XCTAssertEqual(pad.clock.reading.text12, "11:58 PM")
        XCTAssertEqual(pad.clock.reading.dayOffset, -1)
    }

    func testNativeTimePickerResetsAndPreservesUnit() throws {
        var pad = try newKeypad()
        pad.chooseUnit(.minutes)
        pad.typeDigits("3")
        try pad.pressEquals()
        try pad.setStartingMinuteOfDay(21 * 60 + 15)
        XCTAssertEqual(pad.clock.reading.text12, "9:15 PM")
        XCTAssertEqual(pad.clock.equalPresses, 0)
        XCTAssertFalse(pad.displayBlank)
        XCTAssertEqual(pad.unit, .minutes)
        pad.typeDigits("3")
        try pad.pressEquals()
        XCTAssertEqual(pad.clock.reading.text12, "9:18 PM")
    }

    func testUnitSwitchDoesNotChangeCommittedRepeatStep() throws {
        var pad = try newKeypad()
        pad.typeDigits("4")
        try pad.pressEquals()
        pad.chooseUnit(.minutes)
        try pad.pressEquals()
        XCTAssertEqual(pad.clock.reading.text12, "5:00 PM")
        pad.typeDigits("3")
        try pad.pressEquals()
        XCTAssertEqual(pad.clock.reading.text12, "5:03 PM")
    }

    func testACStillBlankWithMinutesSelectionAndRecovery() throws {
        var pad = try newKeypad()
        pad.chooseUnit(.minutes)
        pad.pressReset()
        XCTAssertEqual(pad.displayedTime12, "")
        XCTAssertEqual(pad.displayedTime24, "")
        XCTAssertEqual(pad.unit, .minutes)
        pad.typeDigits("3")
        try pad.pressEquals()
        XCTAssertEqual(pad.clock.reading.text12, "9:03 AM")
        XCTAssertEqual(pad.displayedTime12, "9:03 AM")
    }

    func testMinutesUnitCanBeRestoredFromSavedState() throws {
        var pad = try newKeypad()
        pad.chooseUnit(.minutes)
        let restored = KeypadCalculator(clock: pad.clock, stepHours: pad.stepHours,
                                        stepMinutes: pad.stepMinutes, adding: pad.adding,
                                        displayBlank: pad.displayBlank, allCleared: pad.allCleared,
                                        unit: pad.unit)
        XCTAssertEqual(restored.unit.rawValue, "minutes")
    }

}
