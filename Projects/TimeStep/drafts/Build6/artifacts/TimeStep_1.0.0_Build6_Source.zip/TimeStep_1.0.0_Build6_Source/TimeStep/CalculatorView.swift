import SwiftUI

/// Familiar calculator keypad, with the existing clock engine and storage keys preserved.
struct CalculatorView: View {
    // Build 6 keeps all established Build 1-5 storage keys and the same bundle identity.
    @AppStorage("com.fireworkstars46.timestep.startMinute") private var startMinute = 9 * 60
    @AppStorage("com.fireworkstars46.timestep.totalMinute") private var totalMinute = 9 * 60
    @AppStorage("com.fireworkstars46.timestep.equalPresses") private var equalPresses = 0
    @AppStorage("com.fireworkstars46.timestep.stepHours") private var stepHours = "4"
    @AppStorage("com.fireworkstars46.timestep.stepMinutes") private var stepMinutes = "0"
    @AppStorage("com.fireworkstars46.timestep.adding") private var adding = true
    @AppStorage("com.fireworkstars46.timestep.displayBlank") private var displayBlank = false
    @AppStorage("com.fireworkstars46.timestep.allCleared") private var allCleared = false
    // Additive, non-disruptive setting: a plain number means hours unless Minutes is selected.
    @AppStorage("com.fireworkstars46.timestep.entryUnit") private var savedUnit = "hours"

    @State private var keypad: KeypadCalculator?
    @State private var errorMessage: String?
    @State private var showingTests = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 10) {
                    startTimeRow
                    resultPanel
                    amountPanel
                    operationRow
                    digitPad
                    calculateButton
                    if let model = keypad, !model.displayBlank, model.clock.equalPresses > 0 {
                        Text("Press = again to repeat the same \(model.adding ? "addition" : "subtraction").")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                            .frame(maxWidth: .infinity, alignment: .center)
                    }
                    if let errorMessage {
                        Text(errorMessage)
                            .foregroundColor(.red)
                            .font(.footnote)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
                .padding(12)
                .frame(maxWidth: 480)
                .frame(maxWidth: .infinity)
            }
            .background(Color.black)
            .navigationTitle("Time Step")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { showingTests = true } label: { Image(systemName: "info.circle") }
                        .accessibilityLabel("About and Safe Self-Test")
                }
            }
            .sheet(isPresented: $showingTests) { TestAndAboutView() }
            .onAppear(perform: initialize)
        }
        .preferredColorScheme(.dark)
    }

    // One native control for start time; the phone handles hour/minute and AM/PM.
    private var startDate: Binding<Date> {
        Binding(get: {
            let minute = keypad?.clock.startMinuteOfDay ?? startMinute
            var components = Calendar.current.dateComponents([.year, .month, .day], from: Date())
            components.hour = minute / 60
            components.minute = minute % 60
            components.second = 0
            return Calendar.current.date(from: components) ?? Date()
        }, set: { newDate in
            let parts = Calendar.current.dateComponents([.hour, .minute], from: newDate)
            let minute = (parts.hour ?? 9) * 60 + (parts.minute ?? 0)
            update { try $0.setStartingMinuteOfDay(minute) }
        })
    }

    private var startTimeRow: some View {
        HStack(spacing: 10) {
            VStack(alignment: .leading, spacing: 2) {
                Text("1  START TIME").font(.caption.weight(.bold)).foregroundStyle(.secondary)
                Text("Tap the time to change it")
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            DatePicker("Start time", selection: startDate, displayedComponents: .hourAndMinute)
                .labelsHidden()
                .datePickerStyle(.compact)
                .tint(.orange)
                .accessibilityLabel("Choose starting time")
        }
        .padding(12)
        .background(Color(white: 0.13), in: RoundedRectangle(cornerRadius: 16))
    }

    private var resultPanel: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack {
                Text("RESULT")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.secondary)
                Spacer()
                Button("Reset") { update { $0.pressReset() } }
                    .font(.footnote.weight(.semibold))
                    .foregroundColor(.orange)
                    .accessibilityLabel("Reset all and blank the calculator")
            }
            Text(keypad?.displayBlank == false ? keypad?.clock.reading.text12 ?? "" : "")
                .font(.system(size: 43, weight: .medium, design: .rounded))
                .monospacedDigit()
                .lineLimit(1)
                .minimumScaleFactor(0.55)
                .frame(maxWidth: .infinity, minHeight: 55, alignment: .trailing)
                .accessibilityLabel("Result in 12-hour time: \(keypad?.displayBlank == false ? keypad?.clock.reading.text12 ?? "blank" : "blank")")
            HStack {
                Text("24-hour")
                Spacer()
                Text(keypad?.displayBlank == false ? keypad?.clock.reading.text24 ?? "" : "")
                    .monospacedDigit()
                    .font(.headline)
            }
            .foregroundStyle(.secondary)
            if let model = keypad, !model.displayBlank, model.clock.equalPresses > 0 {
                Text(model.clock.reading.dayDescription)
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(13)
        .background(Color(white: 0.09), in: RoundedRectangle(cornerRadius: 16))
    }

    private var amountPanel: some View {
        VStack(alignment: .leading, spacing: 7) {
            HStack {
                Text("2  ENTER AN AMOUNT")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.secondary)
                Spacer()
                Text(keypad?.pending ?? "")
                    .font(.system(size: 30, weight: .medium, design: .rounded))
                    .monospacedDigit()
                    .frame(minWidth: 45, alignment: .trailing)
                    .accessibilityLabel("Entered amount: \(keypad?.pending ?? "blank")")
            }
            Picker("Time unit", selection: Binding(
                get: { keypad?.unit ?? .hours },
                set: { unit in update { $0.chooseUnit(unit) } }
            )) {
                Text("Hours").tag(KeypadCalculator.DurationUnit.hours)
                Text("Minutes").tag(KeypadCalculator.DurationUnit.minutes)
            }
            .pickerStyle(.segmented)
            .accessibilityLabel("3. Choose hours or minutes")
        }
        .padding(12)
        .background(Color(white: 0.13), in: RoundedRectangle(cornerRadius: 16))
    }

    private var operationRow: some View {
        HStack(spacing: 10) {
            operationButton("+  Add", adding: true)
            operationButton("−  Subtract", adding: false)
        }
    }

    private func operationButton(_ title: String, adding shouldAdd: Bool) -> some View {
        let selected = (keypad?.adding ?? true) == shouldAdd
        return Button { update { $0.chooseOperation(adding: shouldAdd) } } label: {
            Text(title)
                .font(.headline)
                .frame(maxWidth: .infinity)
                .frame(height: 42)
                .foregroundColor(.white)
                .background(selected ? Color.orange : Color(white: 0.23),
                            in: RoundedRectangle(cornerRadius: 13))
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(selected ? .isSelected : [])
    }

    private var digitPad: some View {
        VStack(spacing: 7) {
            digitRow(["7", "8", "9"])
            digitRow(["4", "5", "6"])
            digitRow(["1", "2", "3"])
            digitRow(["AC", "0", "⌫"])
        }
    }

    private func digitRow(_ labels: [String]) -> some View {
        HStack(spacing: 8) {
            ForEach(labels, id: \.self) { label in
                Button {
                    update { model in
                        switch label {
                        case "AC": model.pressClearKey()
                        case "⌫": model.backspace()
                        default: model.typeDigits(label)
                        }
                    }
                } label: {
                    Text(label == "AC" ? (keypad?.clearKeyTitle ?? "AC") : label)
                        .font(.system(size: 25, weight: .medium, design: .rounded))
                        .frame(maxWidth: .infinity)
                        .frame(height: 48)
                        .foregroundColor(.white)
                        .background(label == "AC" || label == "⌫" ? Color(white: 0.33) : Color(white: 0.22),
                                    in: RoundedRectangle(cornerRadius: 15))
                }
                .buttonStyle(.plain)
                .accessibilityLabel(label == "AC" ? (keypad?.clearKeyTitle == "C" ? "Clear entered amount" : "All clear") : (label == "⌫" ? "Backspace" : label))
            }
        }
    }

    private var calculateButton: some View {
        Button { update { try $0.pressEquals() } } label: {
            HStack {
                Text("=")
                    .font(.system(size: 30, weight: .semibold, design: .rounded))
                Spacer()
                Text("Calculate / Repeat")
                    .font(.headline)
                Spacer()
                Image(systemName: "arrow.right")
            }
            .foregroundColor(.white)
            .padding(.horizontal, 19)
            .frame(height: 54)
            .background(Color.orange, in: RoundedRectangle(cornerRadius: 16))
        }
        .buttonStyle(.plain)
        .accessibilityHint("Each press applies the selected amount again")
    }

    private func initialize() {
        guard keypad == nil else { return }
        let savedClock = try? ClockEngine.Calculator(startMinuteOfDay: startMinute,
                                                    currentTotalMinutes: totalMinute,
                                                    equalPresses: equalPresses)
        let fallback = try? ClockEngine.Calculator(startMinuteOfDay: 9 * 60)
        guard let clock = savedClock ?? fallback else { return }
        keypad = KeypadCalculator(clock: clock,
                                  stepHours: Int(stepHours) ?? 4,
                                  stepMinutes: Int(stepMinutes) ?? 0,
                                  adding: adding,
                                  displayBlank: displayBlank,
                                  allCleared: allCleared,
                                  unit: KeypadCalculator.DurationUnit(rawValue: savedUnit) ?? .hours)
    }

    private func update(_ action: (inout KeypadCalculator) throws -> Void) {
        guard var model = keypad else { return }
        do {
            try action(&model)
            keypad = model
            startMinute = model.clock.startMinuteOfDay
            totalMinute = model.clock.currentTotalMinutes
            equalPresses = model.clock.equalPresses
            stepHours = String(model.stepHours)
            stepMinutes = String(model.stepMinutes)
            adding = model.adding
            displayBlank = model.displayBlank
            allCleared = model.allCleared
            savedUnit = model.unit.rawValue
            errorMessage = nil
        } catch KeypadCalculator.InputError.invalidStartTime {
            errorMessage = "Choose a valid starting time."
        } catch KeypadCalculator.InputError.invalidNumber {
            errorMessage = "Enter a number up to 99,999."
        } catch ClockEngine.CalculatorError.calculationOverflow {
            errorMessage = "Too many repeats. Use AC to start over."
        } catch {
            errorMessage = "Invalid time. Check your numbers."
        }
    }
}

private struct TestAndAboutView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var results: [SafeSelfTest.CaseResult] = []

    var body: some View {
        NavigationStack {
            List {
                Section("About") {
                    Text("Time Step · Version 1.0.0 · Build 6")
                    Text("Native iPhone calculator · iOS 16+")
                    Text("Offline. No ads, tracking, or network access.")
                }
                Section("Safe Self-Test") {
                    Button("Run Safe Self-Test") { results = SafeSelfTest.run() }
                    if !results.isEmpty {
                        let passed = results.filter(\.passed).count
                        Text("\(passed) PASS · \(results.count - passed) FAIL")
                            .font(.headline)
                        ForEach(results) { item in
                            VStack(alignment: .leading, spacing: 3) {
                                Text("\(item.passed ? "PASS" : "FAIL") · \(item.name)")
                                    .font(.subheadline.weight(.semibold))
                                if !item.passed {
                                    Text(item.actual).font(.caption).foregroundColor(.red)
                                }
                            }
                        }
                    }
                }
            }
            .navigationTitle("About & Tests")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") { dismiss() }
                }
            }
        }
    }
}
