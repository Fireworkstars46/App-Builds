import SwiftUI

/// Familiar calculator keypad, with the existing clock engine and storage keys preserved.
struct CalculatorView: View {
    @AppStorage("com.fireworkstars46.timestep.startMinute") private var startMinute = 9 * 60
    @AppStorage("com.fireworkstars46.timestep.totalMinute") private var totalMinute = 9 * 60
    @AppStorage("com.fireworkstars46.timestep.equalPresses") private var equalPresses = 0
    @AppStorage("com.fireworkstars46.timestep.stepHours") private var stepHours = "4"
    @AppStorage("com.fireworkstars46.timestep.stepMinutes") private var stepMinutes = "0"
    @AppStorage("com.fireworkstars46.timestep.adding") private var adding = true
    @AppStorage("com.fireworkstars46.timestep.displayBlank") private var displayBlank = false
    @AppStorage("com.fireworkstars46.timestep.allCleared") private var allCleared = false

    @State private var keypad: KeypadCalculator?
    @State private var errorMessage: String?
    @State private var showingTests = false

    private var result: ClockEngine.Reading {
        keypad?.clock.reading ?? ClockEngine.Reading(totalMinutes: totalMinute)
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 13) {
                    display
                    inputDisplay
                    keypadGrid

                    HStack {
                        if let model = keypad, !model.displayBlank {
                            Text("= pressed \(model.clock.equalPresses) times")
                                .foregroundStyle(.secondary)
                            Spacer()
                            Text(model.displayedDay)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .font(.footnote.monospacedDigit())

                    if let errorMessage {
                        Text(errorMessage)
                            .foregroundColor(.red)
                            .font(.footnote)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .accessibilityAddTraits(.updatesFrequently)
                    }

                    Text("Start → enter a clock time → Set. Enter 4 for 4 hours, tap + or −, then tap = to repeat. C clears typed numbers; AC and Reset leave the display blank. Use : for minutes.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding(14)
                .frame(maxWidth: 500)
                .frame(maxWidth: .infinity)
            }
            .background(Color.black)
            .navigationTitle("Time Step")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button { showingTests = true } label: {
                        Image(systemName: "info.circle")
                    }
                    .accessibilityLabel("About and Safe Self-Test")
                }
            }
            .sheet(isPresented: $showingTests) {
                TestAndAboutView()
            }
            .onAppear(perform: initialize)
        }
        .preferredColorScheme(.dark)
    }

    private var display: some View {
        VStack(alignment: .trailing, spacing: 5) {
            HStack {
                Text(keypad?.displayedStart.isEmpty == false ? "Start: \(keypad?.displayedStart ?? "")" : "")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                Spacer(minLength: 4)
                Text("12-HOUR")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.secondary)
            }

            Text(keypad?.displayedTime12 ?? "")
                .font(.system(size: 52, weight: .medium, design: .rounded))
                .monospacedDigit()
                .lineLimit(1)
                .minimumScaleFactor(0.55)
                .frame(maxWidth: .infinity, alignment: .trailing)
                .accessibilityLabel("12-hour display: \(keypad?.displayedTime12 ?? "blank")")

            HStack(spacing: 8) {
                Text("24-HOUR")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.secondary)
                Text(keypad?.displayedTime24 ?? "")
                    .font(.title2.weight(.semibold).monospacedDigit())
                    .accessibilityLabel("24-hour display: \(keypad?.displayedTime24 ?? "blank")")
            }
        }
        .padding(.horizontal, 6)
        .padding(.vertical, 14)
        .frame(maxWidth: .infinity)
    }

    private var inputDisplay: some View {
        HStack {
            Text((keypad?.enteredTime ?? "").isEmpty ? "" : (keypad?.editingStart == true ? "START TIME" : "ADJUSTMENT"))
                .font(.caption.weight(.semibold))
                .foregroundStyle(.secondary)
            Spacer()
            Text(keypad?.enteredTime ?? "")
                .font(.subheadline.weight(.semibold).monospacedDigit())
                .lineLimit(1)
                .minimumScaleFactor(0.65)
        }
        .padding(.horizontal, 14)
        .frame(height: 42)
        .background(Color(white: 0.13), in: RoundedRectangle(cornerRadius: 14))
        .accessibilityElement(children: .combine)
    }

    private var keypadGrid: some View {
        VStack(spacing: 9) {
            keyRow(["C", "⌫", "AM/PM", "Start"])
            keyRow(["7", "8", "9", "+"])
            keyRow(["4", "5", "6", "−"])
            keyRow(["1", "2", "3", "="])
            keyRow(["0", "00", ":", "Reset"])
        }
    }

    private func keyRow(_ labels: [String]) -> some View {
        HStack(spacing: 9) {
            ForEach(labels, id: \.self) { label in
                Button { handle(label) } label: {
                    Text(label == "Start" && keypad?.editingStart == true ? "Set" : (label == "C" ? (keypad?.clearKeyTitle ?? "AC") : label))
                        .font(.system(size: isSmallKey(label) ? 15 : 29, weight: .medium, design: .rounded))
                        .lineLimit(1)
                        .minimumScaleFactor(0.7)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 62)
                        .background(keyColor(label), in: RoundedRectangle(cornerRadius: 22))
                }
                .buttonStyle(.plain)
                .accessibilityLabel(accessibleKey(label))
                .accessibilityHint(label == "=" ? "Repeat the last time adjustment each time" : "")
            }
        }
    }

    private func isSmallKey(_ label: String) -> Bool {
        ["AM/PM", "Start", "Reset", "C"].contains(label)
    }

    private func keyColor(_ label: String) -> Color {
        if ["+", "−", "="].contains(label) {
            return Color(red: 1, green: 0.59, blue: 0.08)
        }
        if ["C", "⌫", "AM/PM", "Start", "Reset"].contains(label) {
            return Color(white: 0.34)
        }
        return Color(white: 0.21)
    }

    private func accessibleKey(_ label: String) -> String {
        switch label {
        case "⌫": return "Backspace"
        case "C": return keypad?.clearKeyTitle == "C" ? "Clear current entry" : "All clear; blank the display"
        case "Start": return keypad?.editingStart == true ? "Set starting time" : "Enter starting time"
        case "Reset": return "Reset calculation and blank display"
        case "=": return "Equals, repeat adjustment"
        case "+": return "Add time"
        case "−": return "Subtract time"
        case ":": return "Hours and minutes separator"
        default: return label
        }
    }

    private func handle(_ label: String) {
        update { model in
            switch label {
            case "C": model.pressClearKey()
            case "⌫": model.backspace()
            case "AM/PM": model.toggleAMPM()
            case "Start": try model.pressStart()
            case "+": model.chooseOperation(adding: true)
            case "−": model.chooseOperation(adding: false)
            case "=": try model.pressEquals()
            case "Reset": model.pressReset()
            case ":": model.typeColon()
            default: model.typeDigits(label)
            }
        }
    }

    private func initialize() {
        guard keypad == nil else { return }
        // Preserve existing Build 1 app data; reset only invalid/corrupted values.
        let oldClock = try? ClockEngine.Calculator(startMinuteOfDay: startMinute,
                                                   currentTotalMinutes: totalMinute,
                                                   equalPresses: equalPresses)
        let fallback = try? ClockEngine.Calculator(startMinuteOfDay: 9 * 60)
        guard let clock = oldClock ?? fallback else { return }
        keypad = KeypadCalculator(clock: clock,
                                  stepHours: Int(stepHours) ?? 4,
                                  stepMinutes: Int(stepMinutes) ?? 0,
                                  adding: adding,
                                  displayBlank: displayBlank,
                                  allCleared: allCleared)
    }

    private func update(_ action: (inout KeypadCalculator) throws -> Void) {
        guard var model = keypad else { return }
        do {
            try action(&model)
            keypad = model
            startMinute = model.clock.startMinuteOfDay
            totalMinute = model.clock.currentTotalMinutes
            equalPresses = model.clock.equalPresses
            stepHours = String(model.stepHours)
            stepMinutes = String(model.stepMinutes)
            adding = model.adding
            displayBlank = model.displayBlank
            allCleared = model.allCleared
            errorMessage = nil
        } catch KeypadCalculator.InputError.invalidStartTime {
            errorMessage = "Enter a clock hour 1–12 and minutes 00–59."
        } catch KeypadCalculator.InputError.invalidNumber {
            errorMessage = "Enter 0–99,999 hours and 00–59 minutes."
        } catch ClockEngine.CalculatorError.calculationOverflow {
            errorMessage = "Too many repeats. Tap Reset."
        } catch {
            errorMessage = "Invalid time. Check your numbers."
        }
    }
}

private struct TestAndAboutView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var results: [SafeSelfTest.CaseResult] = []

    var body: some View {
        NavigationStack {
            List {
                Section("About") {
                    Text("Time Step · Version 1.0.0 · Build 5")
                    Text("Native iPhone calculator · iOS 16+")
                    Text("Offline. No ads, tracking, or network access.")
                }
                Section("Safe Self-Test") {
                    Button("Run Safe Self-Test") { results = SafeSelfTest.run() }
                    if !results.isEmpty {
                        let passed = results.filter(\.passed).count
                        Text("\(passed) PASS · \(results.count - passed) FAIL")
                            .font(.headline)
                        ForEach(results) { item in
                            VStack(alignment: .leading, spacing: 3) {
                                Text("\(item.passed ? "PASS" : "FAIL") · \(item.name)")
                                    .font(.subheadline.weight(.semibold))
                                if !item.passed {
                                    Text(item.actual).font(.caption).foregroundColor(.red)
                                }
                            }
                        }
                    }
                }
            }
            .navigationTitle("About & Tests")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") { dismiss() }
                }
            }
        }
    }
}
