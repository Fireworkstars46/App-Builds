import Foundation

/// Production keypad state shared by the native view and host-side tests.
/// No timers: equals always applies exactly one duration adjustment.
public struct KeypadCalculator {
    public enum InputError: Error, Equatable {
        case invalidNumber
        case invalidStartTime
    }

    public private(set) var clock: ClockEngine.Calculator
    public private(set) var stepHours: Int
    public private(set) var stepMinutes: Int
    public private(set) var adding: Bool
    public private(set) var pending = ""
    public private(set) var editingStart = false
    public private(set) var startPM = false
    public private(set) var entryCleared = false
    /// Blank means no visible clock result, even though the saved start time remains intact.
    public private(set) var displayBlank: Bool
    /// AC/Reset clears the calculation session; C only clears the entered digits.
    public private(set) var allCleared: Bool

    /// The large calculator display shows digits as they are typed, otherwise a time result.
    public var displayedTime12: String {
        if !pending.isEmpty { return pending + (editingStart ? (startPM ? " PM" : " AM") : "") }
        return displayBlank ? "" : clock.reading.text12
    }

    public var displayedTime24: String {
        (displayBlank || !pending.isEmpty) ? "" : clock.reading.text24
    }

    public var displayedStart: String { displayBlank ? "" : clockStartText }
    public var displayedDay: String { (displayBlank || !pending.isEmpty) ? "" : clock.reading.dayDescription }
    public var displayedPresses: String { displayBlank ? "" : String(clock.equalPresses) }

    /// iOS-style clear key: C for a pending entry, AC otherwise.
    public var clearKeyTitle: String { pending.isEmpty ? "AC" : "C" }

    public init(clock: ClockEngine.Calculator, stepHours: Int = 4, stepMinutes: Int = 0,
                adding: Bool = true, displayBlank: Bool = false, allCleared: Bool = false) {
        self.clock = clock
        self.stepHours = (0...ClockEngine.maximumStepHours).contains(stepHours) ? stepHours : 4
        self.stepMinutes = (0..<60).contains(stepMinutes) ? stepMinutes : 0
        self.adding = adding
        self.startPM = clock.startMinuteOfDay >= 720
        self.displayBlank = displayBlank || allCleared
        self.allCleared = allCleared
    }

    public var enteredTime: String {
        if pending.isEmpty && (entryCleared || displayBlank) { return "" }
        if editingStart {
            return "Start: \(pending.isEmpty ? clockStartText : pending + " " + (startPM ? "PM" : "AM"))"
        }
        let step = pending.isEmpty ? String(format: "%d:%02d", stepHours, stepMinutes) : pending
        return "\(adding ? "+" : "−") \(step)  hours:minutes"
    }

    public var clockStartText: String {
        ClockEngine.Reading(totalMinutes: clock.startMinuteOfDay).text12
    }

    public mutating func typeDigits(_ digits: String) {
        guard !digits.isEmpty, digits.allSatisfy({ $0.isNumber && $0.isASCII }) else { return }
        let parts = pending.split(separator: ":", omittingEmptySubsequences: false)
        let maxDigits = editingStart ? 4 : 5
        if parts.count == 2 {
            guard parts[1].count + digits.count <= 2 else { return }
        } else {
            guard parts[0].count + digits.count <= maxDigits else { return }
        }
        pending += digits
        entryCleared = false
        allCleared = false
    }

    public mutating func typeColon() {
        guard !pending.contains(":"), !pending.isEmpty else { return }
        pending += ":"
        entryCleared = false
        allCleared = false
    }

    public mutating func clearEntry() {
        pending = ""
        entryCleared = true
        displayBlank = true
        allCleared = false // The previous result/repeat step still exists after C.
    }

    /// Tap C to clear typed numbers; tap AC when empty to reset the whole calculation.
    public mutating func pressClearKey() {
        if pending.isEmpty { pressReset() } else { clearEntry() }
    }

    public mutating func backspace() {
        guard !pending.isEmpty else { return }
        pending.removeLast()
        if pending.isEmpty {
            entryCleared = true
            displayBlank = true
        }
    }

    public mutating func chooseOperation(adding nextAdding: Bool) {
        if editingStart { return }
        adding = nextAdding
        entryCleared = false
    }

    public mutating func toggleAMPM() {
        if !editingStart {
            editingStart = true
            pending = ""
            startPM = clock.startMinuteOfDay >= 720
            displayBlank = true
        }
        startPM.toggle()
        entryCleared = false
    }

    /// Enters time editing or commits an entered clock time. No automatic calculations.
    public mutating func pressStart() throws {
        guard editingStart else {
            editingStart = true
            pending = ""
            startPM = clock.startMinuteOfDay >= 720
            displayBlank = true
            return
        }
        if !pending.isEmpty {
            let start = try parsedStart()
            try clock.setStartTime(minuteOfDay: start)
            displayBlank = false
            allCleared = false
        }
        editingStart = false
        pending = ""
        entryCleared = false
    }

    public mutating func pressEquals() throws {
        if editingStart {
            try pressStart()
            return
        }
        // AC behaves like a fresh iPhone calculator: = does not resurrect a cleared result.
        if allCleared && pending.isEmpty { return }
        let hours: Int
        let minutes: Int
        if pending.isEmpty {
            hours = stepHours
            minutes = stepMinutes
        } else {
            (hours, minutes) = try parsedDuration()
        }
        // Perform operation before committing the new remembered duration.
        try clock.pressEquals(hours: hours, minutes: minutes, adding: adding)
        stepHours = hours
        stepMinutes = minutes
        pending = ""
        entryCleared = false
        displayBlank = false
        allCleared = false
    }

    public mutating func pressReset() {
        clock.reset()
        pending = ""
        entryCleared = true
        editingStart = false
        startPM = clock.startMinuteOfDay >= 720
        displayBlank = true
        allCleared = true
    }

    private func parts() throws -> (Int, Int) {
        let components = pending.split(separator: ":", omittingEmptySubsequences: false)
        guard (1...2).contains(components.count),
              let hours = Int(components[0]),
              let minutes = components.count == 1 || components[1].isEmpty ? 0 : Int(components[1]),
              minutes >= 0 && minutes < 60 else {
            throw InputError.invalidNumber
        }
        return (hours, minutes)
    }

    private func parsedDuration() throws -> (Int, Int) {
        let (hours, minutes) = try parts()
        guard (0...ClockEngine.maximumStepHours).contains(hours) else {
            throw InputError.invalidNumber
        }
        return (hours, minutes)
    }

    private func parsedStart() throws -> Int {
        let hour: Int
        let minute: Int
        if pending.contains(":") {
            (hour, minute) = try parts()
        } else {
            // Calculator-friendly shorthand: 930 becomes 9:30, 1130 becomes 11:30.
            guard let number = Int(pending) else { throw InputError.invalidStartTime }
            if pending.count >= 3 {
                hour = number / 100
                minute = number % 100
            } else {
                hour = number
                minute = 0
            }
        }
        guard (1...12).contains(hour), (0..<60).contains(minute) else {
            throw InputError.invalidStartTime
        }
        return ((hour % 12) + (startPM ? 12 : 0)) * 60 + minute
    }
}
