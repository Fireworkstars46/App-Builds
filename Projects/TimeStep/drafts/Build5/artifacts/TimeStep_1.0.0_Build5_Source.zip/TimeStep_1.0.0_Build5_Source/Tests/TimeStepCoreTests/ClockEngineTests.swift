import XCTest
@testable import TimeStepCore

final class ClockEngineTests: XCTestCase {
    func testSafeSelfTest() {
        let cases = SafeSelfTest.run()
        XCTAssertEqual(cases.count, 29)
        for item in cases {
            XCTAssertTrue(item.passed, "\(item.name): \(item.actual)")
        }
    }

    func testUnlimitedManualRepeatsHaveNoPresetCount() throws {
        var calculator = try ClockEngine.Calculator(startMinuteOfDay: 540)
        for index in 1...500 {
            try calculator.pressEquals(hours: 4, minutes: 0, adding: true)
            XCTAssertEqual(calculator.currentTotalMinutes, 540 + 240 * index)
            XCTAssertEqual(calculator.equalPresses, index)
        }
        XCTAssertEqual(calculator.reading.text12, "5:00 PM")
        XCTAssertEqual(calculator.reading.dayOffset, 83)
    }

    func testFormatBothClockStyles() {
        XCTAssertEqual(ClockEngine.Reading(totalMinutes: 0).text12, "12:00 AM")
        XCTAssertEqual(ClockEngine.Reading(totalMinutes: 0).text24, "00:00")
        XCTAssertEqual(ClockEngine.Reading(totalMinutes: 13 * 60).text12, "1:00 PM")
        XCTAssertEqual(ClockEngine.Reading(totalMinutes: 13 * 60).text24, "13:00")
    }

    func testSubtractAcrossMidnight() throws {
        var calculator = try ClockEngine.Calculator(startMinuteOfDay: 60)
        try calculator.pressEquals(hours: 4, minutes: 0, adding: false)
        XCTAssertEqual(calculator.reading.text12, "9:00 PM")
        XCTAssertEqual(calculator.reading.dayOffset, -1)
    }

    func testInvalidDurationDoesNotChangeState() throws {
        var calculator = try ClockEngine.Calculator(startMinuteOfDay: 540)
        let unchanged = calculator
        XCTAssertThrowsError(try calculator.pressEquals(hours: 3, minutes: 60, adding: true))
        XCTAssertEqual(calculator, unchanged)
    }

    func testOverflowDoesNotChangeState() throws {
        var calculator = try ClockEngine.Calculator(startMinuteOfDay: 0, currentTotalMinutes: Int.max)
        let unchanged = calculator
        XCTAssertThrowsError(try calculator.pressEquals(hours: 0, minutes: 1, adding: true))
        XCTAssertEqual(calculator, unchanged)
    }

    func testResetAndStartChange() throws {
        var calculator = try ClockEngine.Calculator()
        try calculator.pressEquals(hours: 4, minutes: 0, adding: true)
        calculator.reset()
        XCTAssertEqual(calculator.equalPresses, 0)
        XCTAssertEqual(calculator.reading.text12, "9:00 AM")
        try calculator.setStartTime(minuteOfDay: 1380)
        XCTAssertEqual(calculator.reading.text24, "23:00")
    }
}
