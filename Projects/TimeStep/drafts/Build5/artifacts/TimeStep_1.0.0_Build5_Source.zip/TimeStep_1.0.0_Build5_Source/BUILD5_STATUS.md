# Time Step 1.0.0 Build 5
Targeted fixes: truly blank calculator display on Reset/AC, plus explicit Home Screen icon PNG fallback and unchanged core calculation behavior.
Original bundle ID: com.fireworkstars46.timestep.
Keeps prior app storage identifiers and existing repeat-equals behavior.
iOS 16 deployment target retained.
Cloud compilation and host-side tests performed in the GitHub Actions run.
Actual device installation, iOS UI runtime and sign/update compatibility remain NOT TESTED.
This is an unsigned draft IPA for local Apple ID signing in Sideloadly.
