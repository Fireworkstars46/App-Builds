#!/bin/bash
# Build 5 iPhone launcher icon fallback for iOS Home Screen / Apple ID sideloading.
# Keep AppIcon in Assets.car *and* include explicit legacy PNGs referenced in Info.plist.
set -euo pipefail
APP="${1:?Expected full path to compiled TimeStep.app}"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CATALOG="$ROOT/TimeStep/Assets.xcassets/AppIcon.appiconset"
INFO="$APP/Info.plist"
test -d "$APP" && test -s "$INFO" && test -s "$APP/Assets.car"
/usr/libexec/PlistBuddy -c 'Print :CFBundleIcons:CFBundlePrimaryIcon:CFBundleIconName' "$INFO" | grep -x 'AppIcon'
for spec in '120:2' '180:3'; do
  size="${spec%%:*}"
  scale="${spec##*:}"
  icon="$CATALOG/icon-${size}.png"
  dest="$APP/AppIcon60x60@${scale}x.png"
  test -s "$icon"
  cp "$icon" "$dest"
  test -s "$dest"
  width=$(/usr/bin/sips -g pixelWidth "$dest" | awk '/pixelWidth/{print $2}')
  height=$(/usr/bin/sips -g pixelHeight "$dest" | awk '/pixelHeight/{print $2}')
  test "$width" = "$size" && test "$height" = "$size"
done
# Add legacy CFBundleIconFiles so that iOS still has icon filenames in addition to AppIcon Assets.car.
if /usr/libexec/PlistBuddy -c 'Print :CFBundleIcons:CFBundlePrimaryIcon:CFBundleIconFiles' "$INFO" >/dev/null 2>&1; then
  /usr/libexec/PlistBuddy -c 'Delete :CFBundleIcons:CFBundlePrimaryIcon:CFBundleIconFiles' "$INFO"
fi
/usr/libexec/PlistBuddy -c 'Add :CFBundleIcons:CFBundlePrimaryIcon:CFBundleIconFiles array' "$INFO"
/usr/libexec/PlistBuddy -c 'Add :CFBundleIcons:CFBundlePrimaryIcon:CFBundleIconFiles:0 string AppIcon60x60' "$INFO"
if /usr/libexec/PlistBuddy -c 'Print :CFBundleIconFile' "$INFO" >/dev/null 2>&1; then
  /usr/libexec/PlistBuddy -c 'Set :CFBundleIconFile AppIcon60x60' "$INFO"
else
  /usr/libexec/PlistBuddy -c 'Add :CFBundleIconFile string AppIcon60x60' "$INFO"
fi
/usr/libexec/PlistBuddy -c 'Print :CFBundleIcons:CFBundlePrimaryIcon:CFBundleIconFiles:0' "$INFO" | grep -x 'AppIcon60x60'
/usr/libexec/PlistBuddy -c 'Print :CFBundleIcons:CFBundlePrimaryIcon:CFBundleIconName' "$INFO" | grep -x 'AppIcon'
/usr/bin/plutil -lint "$INFO"
python3 - "$APP" <<'PY'
import pathlib, plistlib, struct, sys, zlib
app = pathlib.Path(sys.argv[1]); info = plistlib.loads((app/'Info.plist').read_bytes())
assert info['CFBundleIcons']['CFBundlePrimaryIcon']['CFBundleIconName'] == 'AppIcon'
assert 'AppIcon60x60' in info['CFBundleIcons']['CFBundlePrimaryIcon']['CFBundleIconFiles']
for scale, size in ((2,120),(3,180)):
    image = (app / f'AppIcon60x60@{scale}x.png').read_bytes()
    assert image[:8] == b'\x89PNG\r\n\x1a\n'
    assert struct.unpack('>II',image[16:24]) == (size,size)
    assert len(zlib.compress(image)) > 2500, 'Suspiciously empty/flat launcher image'
assert (app/'Assets.car').stat().st_size > 2000
print('PASS: Compiled AppIcon + explicit iPhone icon PNGs and Info.plist references are packaged')
PY
