#!/usr/bin/env python3
"""Package Program Diagnostic Monitor setup stub + payloads using PDMSET1! trailer."""
from __future__ import annotations
import argparse, hashlib, struct
from pathlib import Path

MAGIC = b"PDMSET1!"
TRAILER_SIZE = 88

def sha256(data: bytes) -> bytes:
    return hashlib.sha256(data).digest()

def package(stub: Path, app: Path, uninstaller: Path, output: Path) -> None:
    sb, ab, ub = stub.read_bytes(), app.read_bytes(), uninstaller.read_bytes()
    trailer = MAGIC + struct.pack("<QQ", len(ab), len(ub)) + sha256(ab) + sha256(ub)
    assert len(trailer) == TRAILER_SIZE
    output.write_bytes(sb + ab + ub + trailer)

def verify(path: Path) -> tuple[int, int, str, str]:
    data = path.read_bytes()
    if len(data) < TRAILER_SIZE:
        raise ValueError("setup too small")
    tr = data[-TRAILER_SIZE:]
    if tr[:8] != MAGIC:
        raise ValueError("missing PDMSET1! trailer")
    app_size, un_size = struct.unpack("<QQ", tr[8:24])
    stub_size = len(data) - TRAILER_SIZE - app_size - un_size
    if stub_size < 0:
        raise ValueError("invalid payload sizes")
    app = data[stub_size:stub_size+app_size]
    un = data[stub_size+app_size:stub_size+app_size+un_size]
    ah, uh = hashlib.sha256(app).digest(), hashlib.sha256(un).digest()
    if ah != tr[24:56] or uh != tr[56:88]:
        raise ValueError("payload hash mismatch")
    return app_size, un_size, ah.hex(), uh.hex()

def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("stub", type=Path)
    ap.add_argument("app", type=Path)
    ap.add_argument("uninstaller", type=Path)
    ap.add_argument("output", type=Path)
    args = ap.parse_args()
    package(args.stub, args.app, args.uninstaller, args.output)
    a, u, ah, uh = verify(args.output)
    print(f"OK {args.output}: app={a} uninstaller={u}")
    print(f"app_sha256={ah}")
    print(f"uninstaller_sha256={uh}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
