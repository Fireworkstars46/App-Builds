#!/usr/bin/env python3
"""Build 19 release-blocking static/regression audit.

This script validates source architecture, least-privilege rules, project identity,
release packaging, and PE imports. It deliberately does not claim physical Windows
GUI/runtime behavior; the in-app Safe Self-Test reports those items itself.
"""
from __future__ import annotations
import argparse, hashlib, re, shutil, struct, subprocess, sys
from pathlib import Path

FORBIDDEN_APP_APIS = [
    "CreateProcessW", "OpenThread", "Thread32First", "Thread32Next", "GetThreadTimes",
    "Module32First", "Module32Next", "OpenProcessToken", "GetTokenInformation",
    "OpenEventLogW", "ReadEventLogW", "GetExtendedTcpTable", "GetExtendedUdpTable",
    "CreateRemoteThread", "WriteProcessMemory", "VirtualAllocEx", "SetWindowsHookEx",
    "DebugActiveProcess", "ReadProcessMemory",
]

def h(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

def pe_import_text(path: Path) -> str:
    tool = shutil.which("llvm-objdump")
    if not tool:
        raise RuntimeError("llvm-objdump unavailable")
    return subprocess.check_output([tool, "-p", str(path)], text=True, errors="replace")

def verify_setup(path: Path, app: Path, uninstaller: Path) -> tuple[bool,str]:
    data=path.read_bytes()
    if len(data)<88 or data[-88:-80]!=b"PDMSET1!": return False,"PDMSET1 trailer missing"
    tr=data[-88:]; asz,usz=struct.unpack("<QQ",tr[8:24]); stub=len(data)-88-asz-usz
    if stub<0: return False,"invalid setup payload sizes"
    ab=data[stub:stub+asz]; ub=data[stub+asz:stub+asz+usz]
    if hashlib.sha256(ab).digest()!=tr[24:56]: return False,"embedded app hash mismatch"
    if hashlib.sha256(ub).digest()!=tr[56:88]: return False,"embedded uninstaller hash mismatch"
    if ab!=app.read_bytes(): return False,"embedded app differs from release app"
    if ub!=uninstaller.read_bytes(): return False,"embedded uninstaller differs from release uninstaller"
    return True,f"embedded app/uninstaller exact; stub={stub} app={asz} uninstaller={usz}"

def main() -> int:
    ap=argparse.ArgumentParser();ap.add_argument("--root",type=Path,default=Path(__file__).resolve().parents[1]);ap.add_argument("--setup",type=Path);ap.add_argument("--build17-app",type=Path);args=ap.parse_args()
    root=args.root.resolve(); src=root/"src"; build=root/"build"
    appc=(src/"app.c").read_text(errors="replace"); inst=(src/"installer.c").read_text(errors="replace"); un=(src/"uninstaller.c").read_text(errors="replace"); hdr=(src/"winmini.h").read_text(errors="replace"); imports=(build/"make_imports.py").read_text(errors="replace")
    app=build/"ProgramDiagnosticMonitor.exe"; stub=build/"SetupStub.exe"; unexe=build/"Uninstall.exe"; setup=args.setup or build/"Program_Diagnostic_Monitor_Setup_v1.0.18_Build_19.exe"
    tests=[]
    def ck(name, cond, detail=""):
        tests.append((name,bool(cond),detail))
    ck("Version is v1.0.18 Build 19", '#define APP_VERSION L"1.0.18"' in appc and '#define APP_BUILD 19' in appc and '#define APP_BUILD 19' in inst)
    ck("Isolated main window class preserved", 'ProgramDiagnosticMonitorIsolatedWindow' in appc)
    ck("Isolated installer class preserved", 'PDMIsolatedInstallerWindow' in inst)
    ck("Dedicated app-data namespace", '\\\\ProgramDiagnosticMonitor-Isolated' in appc)
    ck("Dedicated install namespace", '\\\\Programs\\\\ProgramDiagnosticMonitor-Isolated' in inst)
    ck("Isolated uninstall identity", 'Uninstall\\\\ProgramDiagnosticMonitor-Isolated' in inst and 'Uninstall\\\\ProgramDiagnosticMonitor-Isolated' in un)
    ck("No app-wide single-instance guard added", 'ERROR_ALREADY_EXISTS' not in appc and 'single-instance' not in appc.lower(), "settings-write mutex is allowed")
    ck("Settings write mutex exists", 'ProgramDiagnosticMonitor-Isolated-SettingsWrite' in appc and 'CreateMutexW' in appc)
    ck("Stale-writer merge path exists", 'persist_settings_mask' in appc and 'merge_settings_to_file' in appc and 'Multi-instance stale-writer protection' in appc)
    for key,mask in [("MinimizeToTray","SETF_MINIMIZE"),("CloseToTray","SETF_CLOSE"),("StartMinimized","SETF_STARTMIN"),("OpenSettingsAtStartup","SETF_OPENSETTINGS"),("StartPaused","SETF_STARTPAUSED"),("Notifications","SETF_NOTIFICATIONS"),("DebugMode","SETF_DEBUG"),("TrayClickMode","SETF_TRAYCLICK")]:
        ck(f"Setting persisted: {key}", key in appc and mask in appc)
    ck("Atomic settings replacement", 'MoveFileExW(tmp,path,MOVEFILE_REPLACE_EXISTING)' in appc)
    ck("Settings persistence self-test write/read/compare", 'Settings persistence write -> reload/read -> compare' in appc)
    ck("Debug Settings/main UI synchronization self-test", 'Settings <-> main UI Debug synchronization' in appc)
    ck("All Settings controls production-handler self-test", 'Settings controls production handlers + persistence' in appc and 'IDC_SET_RESETLAYOUT' in appc and 'Reset Window Layout production control' in appc)
    ck("Safe Self-Test explicit statuses", all(x in appc for x in ['L"PASS"','L"FAIL"','L"SKIPPED"','L"NOT TESTED"']))
    ck("Safe Self-Test temporary rotation cleanup", 'all temporary generations cleaned' in appc and 'ri<=4' in appc)
    ck("Cold-start runtime limitation reported", 'Cold-start decisions' in appc and 'NOT TESTED' in appc)
    ck("Exit runtime limitation reported", 'Actual Exit App process termination' in appc and 'SKIPPED' in appc)
    ck("Close/X destructive fallback reported", 'Close/X-to-tray destructive fallback' in appc and 'NOT TESTED' in appc)
    ck("Bounded five-file logs", '5ULL*1024ULL*1024ULL' in appc and 'for(INT i=3;i>=1;i--)' in appc)
    ck("Privacy-safe monitoring start/stop/freeze logging", all(x in appc for x in ['Diagnostic monitoring started in passive wait/attach mode','User requested diagnostic monitoring stop and analysis','Automatic freeze detected on selected target MAIN UI','Automatic lag detected on selected target MAIN UI']))
    ck("TaskbarCreated recovery", 'TaskbarCreated' in appc and 'Tray icon rebuilt after Explorer/taskbar restart' in appc)
    ck("Tray single/double click separation", 'WM_LBUTTONUP' in appc and 'WM_LBUTTONDBLCLK' in appc and 'trayClickMode==1' in appc and 'trayClickMode==2' in appc)
    ck("Minimize/Close/Exit paths are distinct", 'Main window minimized to tray' in appc and 'Main window closed to tray' in appc and 'request_exit()' in appc)
    ck("Window minimum size", 'WM_GETMINMAXINFO' in appc and 'sc(900)' in appc and 'sc(560)' in appc)
    ck("Reset Window Layout", 'Reset Window Layout' in appc and 'reset_window_layout' in appc)
    ck("Remembered window geometry", all(x in appc for x in ['WindowX','WindowY','WindowW','WindowH','WM_EXITSIZEMOVE']))
    ck("Multi-monitor offscreen recovery", 'MonitorFromRect' in appc and 'MONITOR_DEFAULTTONULL' in appc)
    ck("Passive monitor never launches target", 'CreateProcessW' not in appc and 'never launches' in appc.lower())
    ck("All app OpenProcess requests limited query", all('PROCESS_QUERY_LIMITED_INFORMATION' in line for line in appc.splitlines() if 'OpenProcess(' in line), "every OpenProcess source line")
    for api in FORBIDDEN_APP_APIS:
        # Check for actual source call syntax, not explanatory strings or longer WCT names (e.g. OpenThreadWaitChainSession).
        ck(f"Forbidden app source API absent: {api}", re.search(r"\b"+re.escape(api)+r"\s*\(", appc) is None)
    ck("No broad module implementation", 'module enumeration is intentionally disabled' in appc.lower() and 'Module32First' not in appc)
    ck("No broad event-log implementation", 'broad Application event-log scanning' in appc and 'OpenEventLogW' not in appc and 'ReadEventLogW' not in appc)
    ck("No network owner-table implementation", 'owner-table enumeration is intentionally disabled' in appc and 'GetExtendedTcpTable' not in appc)
    ck("Watched-folder recursion disabled", 'recursive watched-folder scanning is disabled' in appc.lower())
    ck("Protected peer classifier", 'CrashMonitor.exe' in appc and 'RitschyMirror.exe' in appc and 'Protected-peer classifier' in appc)
    ck("WCT dynamically resolved", all(x in appc for x in ['GetProcAddress(a,"OpenThreadWaitChainSession")','GetProcAddress(a,"GetThreadWaitChain")','GetProcAddress(a,"CloseThreadWaitChainSession")']))
    ck("WCT restricted to hung MAIN UI", 'hung MAIN UI threads only' in appc and 'MAX_WCT_THREADS_PER_FREEZE' in appc)
    ck("150 ms bounded WM_NULL probe", 'AUTO_PROBE_TIMEOUT_MS 150' in appc and 'WM_NULL' in appc and 'SendMessageTimeoutW' in appc)
    ck("Helper sampling refresh bounded", 'now-g_lastHelperRefresh>=5000' in appc)
    ck("Target restart watch remains 30 seconds", 'RESTART_WAIT_MS 30000' in appc)
    ck("Installer preserves app-data directories", all(x in inst for x in ['\\\\Data','\\\\Temp','\\\\Logs','\\\\Diagnostics']) and 'delete_tree' not in inst)
    ck("Installer Finish-only optional launch", 'when I click Finish' in inst and 'if(g_done)' in inst and 'ShellExecuteW' in inst)
    ck("Installer preserves desktop shortcut choice on upgrade", 'g_existingDesktop' in inst and 'g_isUpgrade' in inst)
    ck("Installer verifies embedded SHA-256", 'BCryptFinishHash' in inst and 'memcmp(ah,tr+24,32)' in inst and 'memcmp(uh,tr+56,32)' in inst)
    ck("Uninstaller preserves Logs/Diagnostics", 'Logs and Diagnostics intentionally remain' in un and 'delete_tree(p);' in un)
    ck("Uninstaller guards exact isolated delete roots", 'expected_roots' in un and 'path_eq_i' in un and 'Nothing was deleted' in un)
    ck("Uninstaller cleanup helper is project-local", 'PDM-Isolated-Uninstall-' in un and '\\\\Temp' in un)
    ck("Source header does not declare removed APIs", all(api not in hdr for api in ['OpenThread','Thread32First','GetThreadTimes','Module32First','OpenProcessToken','OpenEventLogW','GetExtendedTcpTable']))
    ck("Import generator does not request removed APIs", all(api not in imports for api in ['OpenThread','Thread32First','GetThreadTimes','Module32First','OpenProcessToken','OpenEventLogW','GetExtendedTcpTable']))
    ck("All three release component EXEs exist", app.exists() and stub.exists() and unexe.exists())
    if app.exists():
        try: imp=pe_import_text(app)
        except Exception as e: imp=""; ck("PE import table readable",False,str(e))
        else:
            ck("PE import table readable",True)
            for api in FORBIDDEN_APP_APIS: ck(f"Forbidden app PE import absent: {api}", api not in imp)
            ck("App imports limited-query process APIs only by source contract", 'OpenProcess' in imp and 'CreateToolhelp32Snapshot' in imp)
    if setup.exists() and app.exists() and unexe.exists():
        ok,detail=verify_setup(setup,app,unexe);ck("Combined setup payload hashes/exact bytes",ok,detail)
    else: ck("Combined setup exists",False,str(setup))
    if args.build17_app and args.build17_app.exists():
        b17=args.build17_app.read_bytes(); b19=app.read_bytes() if app.exists() else b""
        for token in ["ProgramDiagnosticMonitorIsolatedWindow","ProgramDiagnosticMonitor-Isolated"]:
            enc=token.encode("utf-16le")
            ck(f"Build17 identity token preserved: {token}",enc in b17 and enc in b19)
    print("=== Program Diagnostic Monitor v1.0.18 Build 19 STATIC/RELEASE AUDIT ===")
    fail=0
    for i,(name,ok,detail) in enumerate(tests,1):
        status="PASS" if ok else "FAIL"; fail += 0 if ok else 1
        print(f"{i:03d}. {status} - {name}" + (f" | {detail}" if detail else ""))
    print(f"SUMMARY: {len(tests)-fail} PASS, {fail} FAIL, {len(tests)} TOTAL")
    if app.exists(): print(f"APP_SHA256={h(app)}")
    if setup.exists(): print(f"SETUP_SHA256={h(setup)}")
    return 1 if fail else 0

if __name__=="__main__": raise SystemExit(main())
