#ifndef WINMINI_H
#define WINMINI_H

#define NULL ((void*)0)
#define WINAPI __stdcall
#define CALLBACK __stdcall
#define TRUE 1
#define FALSE 0

typedef void* HANDLE;
typedef HANDLE HINSTANCE;
typedef HANDLE HMODULE;
typedef HANDLE HWND;
typedef HANDLE HICON;
typedef HANDLE HCURSOR;
typedef HANDLE HBRUSH;
typedef HANDLE HMENU;
typedef HANDLE HFONT;
typedef HANDLE HDC;
typedef HANDLE HKEY;
typedef HANDLE HLOCAL;
typedef HANDLE LPITEMIDLIST;
typedef unsigned char BYTE;
typedef unsigned short WORD;
typedef WORD ATOM;
typedef unsigned short WCHAR;
typedef WCHAR* LPWSTR;
typedef const WCHAR* LPCWSTR;
typedef char CHAR;
typedef const CHAR* LPCSTR;
typedef unsigned int UINT;
typedef int INT;
typedef long LONG;
typedef unsigned long DWORD;
typedef long long LONGLONG;
typedef unsigned long long ULONGLONG;
typedef unsigned long long ULONG_PTR;
typedef long long LONG_PTR;
typedef unsigned long long DWORD_PTR;
typedef unsigned long long SIZE_T;
typedef unsigned long long WPARAM;
typedef long long LPARAM;
typedef long long LRESULT;
typedef long long INT_PTR;
typedef unsigned long long UINT_PTR;
typedef int BOOL;
typedef long HRESULT;
typedef void* LPVOID;
typedef const void* LPCVOID;
typedef DWORD* LPDWORD;
typedef unsigned long ULONG;
typedef unsigned long ACCESS_MASK;

typedef struct { LONG x; LONG y; } POINT;
typedef struct { LONG left; LONG top; LONG right; LONG bottom; } RECT;
typedef struct { POINT ptReserved; POINT ptMaxSize; POINT ptMaxPosition; POINT ptMinTrackSize; POINT ptMaxTrackSize; } MINMAXINFO;
typedef struct { DWORD dwLowDateTime; DWORD dwHighDateTime; } FILETIME;
typedef struct { WORD wYear,wMonth,wDayOfWeek,wDay,wHour,wMinute,wSecond,wMilliseconds; } SYSTEMTIME;
typedef struct { DWORD Data1; WORD Data2; WORD Data3; BYTE Data4[8]; } GUID;

typedef LRESULT (CALLBACK *WNDPROC)(HWND,UINT,WPARAM,LPARAM);
typedef BOOL (CALLBACK *WNDENUMPROC)(HWND,LPARAM);

typedef struct {
    UINT cbSize; UINT style; WNDPROC lpfnWndProc; INT cbClsExtra; INT cbWndExtra;
    HINSTANCE hInstance; HICON hIcon; HCURSOR hCursor; HBRUSH hbrBackground;
    LPCWSTR lpszMenuName; LPCWSTR lpszClassName; HICON hIconSm;
} WNDCLASSEXW;

typedef struct { HWND hwnd; UINT message; WPARAM wParam; LPARAM lParam; DWORD time; POINT pt; DWORD lPrivate; } MSG;

typedef struct {
    DWORD cbSize; HWND hWnd; UINT uID; UINT uFlags; UINT uCallbackMessage; HICON hIcon;
    WCHAR szTip[128]; DWORD dwState; DWORD dwStateMask; WCHAR szInfo[256];
    union { UINT uTimeout; UINT uVersion; }; WCHAR szInfoTitle[64]; DWORD dwInfoFlags; GUID guidItem; HICON hBalloonIcon;
} NOTIFYICONDATAW;

typedef struct {
    DWORD lStructSize; HWND hwndOwner; HINSTANCE hInstance; LPCWSTR lpstrFilter; LPWSTR lpstrCustomFilter;
    DWORD nMaxCustFilter; DWORD nFilterIndex; LPWSTR lpstrFile; DWORD nMaxFile; LPWSTR lpstrFileTitle;
    DWORD nMaxFileTitle; LPCWSTR lpstrInitialDir; LPCWSTR lpstrTitle; DWORD Flags; WORD nFileOffset;
    WORD nFileExtension; LPCWSTR lpstrDefExt; LPARAM lCustData; void* lpfnHook; LPCWSTR lpTemplateName;
    void* pvReserved; DWORD dwReserved; DWORD FlagsEx;
} OPENFILENAMEW;

typedef struct {
    HWND hwndOwner; LPITEMIDLIST pidlRoot; LPWSTR pszDisplayName; LPCWSTR lpszTitle; UINT ulFlags;
    INT_PTR (CALLBACK *lpfn)(HWND,UINT,LPARAM,LPARAM); LPARAM lParam; INT iImage;
} BROWSEINFOW;

typedef struct { HANDLE hProcess; HANDLE hThread; DWORD dwProcessId; DWORD dwThreadId; } PROCESS_INFORMATION;
typedef struct {
    DWORD cb; LPWSTR lpReserved; LPWSTR lpDesktop; LPWSTR lpTitle; DWORD dwX,dwY,dwXSize,dwYSize;
    DWORD dwXCountChars,dwYCountChars,dwFillAttribute,dwFlags; WORD wShowWindow,cbReserved2; BYTE* lpReserved2;
    HANDLE hStdInput,hStdOutput,hStdError;
} STARTUPINFOW;

typedef struct {
    DWORD dwSize; DWORD cntUsage; DWORD th32ProcessID; ULONG_PTR th32DefaultHeapID; DWORD th32ModuleID;
    DWORD cntThreads; DWORD th32ParentProcessID; LONG pcPriClassBase; DWORD dwFlags; WCHAR szExeFile[260];
} PROCESSENTRY32W;

typedef struct {
    DWORD dwSize; DWORD cntUsage; DWORD th32ThreadID; DWORD th32OwnerProcessID;
    LONG tpBasePri; LONG tpDeltaPri; DWORD dwFlags;
} THREADENTRY32;

typedef struct {
    DWORD dwSize; DWORD th32ModuleID; DWORD th32ProcessID; DWORD GlblcntUsage; DWORD ProccntUsage;
    BYTE* modBaseAddr; DWORD modBaseSize; HMODULE hModule; WCHAR szModule[256]; WCHAR szExePath[260];
} MODULEENTRY32W;

typedef struct {
    DWORD cb; DWORD PageFaultCount; SIZE_T PeakWorkingSetSize; SIZE_T WorkingSetSize; SIZE_T QuotaPeakPagedPoolUsage;
    SIZE_T QuotaPagedPoolUsage; SIZE_T QuotaPeakNonPagedPoolUsage; SIZE_T QuotaNonPagedPoolUsage;
    SIZE_T PagefileUsage; SIZE_T PeakPagefileUsage;
} PROCESS_MEMORY_COUNTERS;

typedef struct {
    ULONGLONG ReadOperationCount; ULONGLONG WriteOperationCount; ULONGLONG OtherOperationCount;
    ULONGLONG ReadTransferCount; ULONGLONG WriteTransferCount; ULONGLONG OtherTransferCount;
} IO_COUNTERS;

typedef struct {
    DWORD cb; DWORD PageFaultCount; SIZE_T PeakWorkingSetSize; SIZE_T WorkingSetSize; SIZE_T QuotaPeakPagedPoolUsage;
    SIZE_T QuotaPagedPoolUsage; SIZE_T QuotaPeakNonPagedPoolUsage; SIZE_T QuotaNonPagedPoolUsage;
    SIZE_T PagefileUsage; SIZE_T PeakPagefileUsage; SIZE_T PrivateUsage;
} PROCESS_MEMORY_COUNTERS_EX;

typedef struct {
    DWORD dwLength; DWORD dwMemoryLoad; ULONGLONG ullTotalPhys; ULONGLONG ullAvailPhys; ULONGLONG ullTotalPageFile;
    ULONGLONG ullAvailPageFile; ULONGLONG ullTotalVirtual; ULONGLONG ullAvailVirtual; ULONGLONG ullAvailExtendedVirtual;
} MEMORYSTATUSEX;

typedef struct {
    union { DWORD dwOemId; struct { WORD wProcessorArchitecture; WORD wReserved; }; };
    DWORD dwPageSize; LPVOID lpMinimumApplicationAddress; LPVOID lpMaximumApplicationAddress;
    ULONG_PTR dwActiveProcessorMask; DWORD dwNumberOfProcessors; DWORD dwProcessorType;
    DWORD dwAllocationGranularity; WORD wProcessorLevel; WORD wProcessorRevision;
} SYSTEM_INFO;

typedef struct {
    DWORD cb; WCHAR DeviceName[32]; WCHAR DeviceString[128]; DWORD StateFlags; WCHAR DeviceID[128]; WCHAR DeviceKey[128];
} DISPLAY_DEVICEW;

typedef struct {
    DWORD dwFileAttributes; FILETIME ftCreationTime; FILETIME ftLastAccessTime; FILETIME ftLastWriteTime;
    DWORD nFileSizeHigh; DWORD nFileSizeLow;
} WIN32_FILE_ATTRIBUTE_DATA;

typedef struct {
    DWORD dwSignature; DWORD dwStrucVersion; DWORD dwFileVersionMS; DWORD dwFileVersionLS;
    DWORD dwProductVersionMS; DWORD dwProductVersionLS; DWORD dwFileFlagsMask; DWORD dwFileFlags;
    DWORD dwFileOS; DWORD dwFileType; DWORD dwFileSubtype; DWORD dwFileDateMS; DWORD dwFileDateLS;
} VS_FIXEDFILEINFO;

typedef struct { DWORD TokenIsElevated; } TOKEN_ELEVATION;
typedef struct { void* Sid; DWORD Attributes; } SID_AND_ATTRIBUTES;
typedef struct { SID_AND_ATTRIBUTES Label; } TOKEN_MANDATORY_LABEL;

typedef struct {
    DWORD dwFileAttributes; FILETIME ftCreationTime; FILETIME ftLastAccessTime; FILETIME ftLastWriteTime;
    DWORD nFileSizeHigh; DWORD nFileSizeLow; DWORD dwReserved0; DWORD dwReserved1; WCHAR cFileName[260]; WCHAR cAlternateFileName[14];
} WIN32_FIND_DATAW;

typedef struct {
    DWORD Length; DWORD Reserved; DWORD RecordNumber; DWORD TimeGenerated; DWORD TimeWritten; DWORD EventID;
    WORD EventType; WORD NumStrings; WORD EventCategory; WORD ReservedFlags; DWORD ClosingRecordNumber; DWORD StringOffset;
    DWORD UserSidLength; DWORD UserSidOffset; DWORD DataLength; DWORD DataOffset;
} EVENTLOGRECORD;

typedef struct {
    DWORD dwState; DWORD dwLocalAddr; DWORD dwLocalPort; DWORD dwRemoteAddr; DWORD dwRemotePort; DWORD dwOwningPid;
} MIB_TCPROW_OWNER_PID;
typedef struct { DWORD dwNumEntries; MIB_TCPROW_OWNER_PID table[1]; } MIB_TCPTABLE_OWNER_PID;
typedef struct { DWORD dwLocalAddr; DWORD dwLocalPort; DWORD dwOwningPid; } MIB_UDPROW_OWNER_PID;
typedef struct { DWORD dwNumEntries; MIB_UDPROW_OWNER_PID table[1]; } MIB_UDPTABLE_OWNER_PID;

typedef struct {
    DWORD cbStruct; LPCWSTR pcwszFilePath; HANDLE hFile; GUID* pgKnownSubject;
} WINTRUST_FILE_INFO;
typedef struct {
    DWORD cbStruct; LPVOID pPolicyCallbackData; LPVOID pSIPClientData; DWORD dwUIChoice; DWORD fdwRevocationChecks;
    DWORD dwUnionChoice; LPVOID pFile; DWORD dwStateAction; HANDLE hWVTStateData; LPWSTR pwszURLReference;
    DWORD dwProvFlags; DWORD dwUIContext;
} WINTRUST_DATA;

typedef HANDLE BCRYPT_ALG_HANDLE;
typedef HANDLE BCRYPT_HASH_HANDLE;

typedef struct IUnknown IUnknown;
typedef struct IShellLinkW IShellLinkW;
typedef struct IPersistFile IPersistFile;

typedef struct IShellLinkWVtbl {
    HRESULT (WINAPI *QueryInterface)(IShellLinkW*,const GUID*,void**);
    ULONG (WINAPI *AddRef)(IShellLinkW*); ULONG (WINAPI *Release)(IShellLinkW*);
    HRESULT (WINAPI *GetPath)(IShellLinkW*,LPWSTR,INT,void*,DWORD);
    HRESULT (WINAPI *GetIDList)(IShellLinkW*,void**); HRESULT (WINAPI *SetIDList)(IShellLinkW*,void*);
    HRESULT (WINAPI *GetDescription)(IShellLinkW*,LPWSTR,INT); HRESULT (WINAPI *SetDescription)(IShellLinkW*,LPCWSTR);
    HRESULT (WINAPI *GetWorkingDirectory)(IShellLinkW*,LPWSTR,INT); HRESULT (WINAPI *SetWorkingDirectory)(IShellLinkW*,LPCWSTR);
    HRESULT (WINAPI *GetArguments)(IShellLinkW*,LPWSTR,INT); HRESULT (WINAPI *SetArguments)(IShellLinkW*,LPCWSTR);
    HRESULT (WINAPI *GetHotkey)(IShellLinkW*,WORD*); HRESULT (WINAPI *SetHotkey)(IShellLinkW*,WORD);
    HRESULT (WINAPI *GetShowCmd)(IShellLinkW*,INT*); HRESULT (WINAPI *SetShowCmd)(IShellLinkW*,INT);
    HRESULT (WINAPI *GetIconLocation)(IShellLinkW*,LPWSTR,INT,INT*); HRESULT (WINAPI *SetIconLocation)(IShellLinkW*,LPCWSTR,INT);
    HRESULT (WINAPI *SetRelativePath)(IShellLinkW*,LPCWSTR,DWORD); HRESULT (WINAPI *Resolve)(IShellLinkW*,HWND,DWORD);
    HRESULT (WINAPI *SetPath)(IShellLinkW*,LPCWSTR);
} IShellLinkWVtbl;
struct IShellLinkW { IShellLinkWVtbl* lpVtbl; };

typedef struct IPersistFileVtbl {
    HRESULT (WINAPI *QueryInterface)(IPersistFile*,const GUID*,void**);
    ULONG (WINAPI *AddRef)(IPersistFile*); ULONG (WINAPI *Release)(IPersistFile*);
    HRESULT (WINAPI *GetClassID)(IPersistFile*,GUID*); HRESULT (WINAPI *IsDirty)(IPersistFile*);
    HRESULT (WINAPI *Load)(IPersistFile*,LPCWSTR,DWORD); HRESULT (WINAPI *Save)(IPersistFile*,LPCWSTR,BOOL);
    HRESULT (WINAPI *SaveCompleted)(IPersistFile*,LPCWSTR); HRESULT (WINAPI *GetCurFile)(IPersistFile*,LPWSTR*);
} IPersistFileVtbl;
struct IPersistFile { IPersistFileVtbl* lpVtbl; };

/* constants */
#define MAX_PATH 260
#define INVALID_HANDLE_VALUE ((HANDLE)(LONG_PTR)-1)
#define INVALID_FILE_ATTRIBUTES 0xFFFFFFFFUL
#define HEAP_ZERO_MEMORY 0x00000008
#define GENERIC_READ 0x80000000UL
#define GENERIC_WRITE 0x40000000UL
#define FILE_SHARE_READ 0x00000001
#define FILE_SHARE_WRITE 0x00000002
#define OPEN_EXISTING 3
#define CREATE_ALWAYS 2
#define OPEN_ALWAYS 4
#define FILE_END 2
#define MOVEFILE_REPLACE_EXISTING 0x00000001
#define ERROR_ALREADY_EXISTS 183
#define FILE_ATTRIBUTE_NORMAL 0x00000080
#define FILE_ATTRIBUTE_DIRECTORY 0x00000010
#define FILE_FLAG_BACKUP_SEMANTICS 0x02000000
#define FILE_BEGIN 0
#define WAIT_OBJECT_0 0
#define WAIT_ABANDONED_0 0x00000080
#define WAIT_TIMEOUT 258
#define INFINITE 0xFFFFFFFFUL
#define STILL_ACTIVE 259
#define SYNCHRONIZE 0x00100000
#define PROCESS_QUERY_LIMITED_INFORMATION 0x1000
#define PROCESS_QUERY_INFORMATION 0x0400
#define THREAD_QUERY_LIMITED_INFORMATION 0x0800
#define GR_GDIOBJECTS 0
#define GR_USEROBJECTS 1
#define PROCESS_VM_READ 0x0010
#define TH32CS_SNAPTHREAD 0x00000004
#define TH32CS_SNAPPROCESS 0x00000002
#define TH32CS_SNAPMODULE 0x00000008
#define TH32CS_SNAPMODULE32 0x00000010
#define CREATE_UNICODE_ENVIRONMENT 0x00000400
#define STARTF_USESHOWWINDOW 0x00000001
#define SW_SHOWNORMAL 1
#define SW_SHOW 5
#define SW_HIDE 0
#define SW_RESTORE 9
#define SIZE_MINIMIZED 1
#define WM_CLOSE 0x0010
#define WM_GETMINMAXINFO 0x0024
#define WM_EXITSIZEMOVE 0x0232
#define WM_LBUTTONUP 0x0202
#define WM_LBUTTONDBLCLK 0x0203
#define WM_RBUTTONUP 0x0205
#define WM_CREATE 0x0001
#define WM_DESTROY 0x0002
#define WM_SIZE 0x0005
#define WM_COMMAND 0x0111
#define WM_TIMER 0x0113
#define WM_SETFONT 0x0030
#define WM_GETFONT 0x0031
#define WM_NULL 0x0000
#define WS_OVERLAPPED 0x00000000L
#define WS_CAPTION 0x00C00000L
#define WS_SYSMENU 0x00080000L
#define WS_THICKFRAME 0x00040000L
#define WS_MINIMIZEBOX 0x00020000L
#define WS_MAXIMIZEBOX 0x00010000L
#define WS_OVERLAPPEDWINDOW (WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU|WS_THICKFRAME|WS_MINIMIZEBOX|WS_MAXIMIZEBOX)
#define WS_VISIBLE 0x10000000L
#define WS_CHILD 0x40000000L
#define WS_BORDER 0x00800000L
#define WS_VSCROLL 0x00200000L
#define WS_HSCROLL 0x00100000L
#define ES_LEFT 0x0000L
#define ES_MULTILINE 0x0004L
#define ES_AUTOVSCROLL 0x0040L
#define ES_AUTOHSCROLL 0x0080L
#define ES_READONLY 0x0800L
#define BS_PUSHBUTTON 0x00000000L
#define BS_DEFPUSHBUTTON 0x00000001L
#define BS_AUTOCHECKBOX 0x00000003L
#define SS_LEFT 0x00000000L
#define CW_USEDEFAULT ((INT)0x80000000)
#define COLOR_WINDOW 5
#define IDC_ARROW ((LPCWSTR)32512)
#define IDI_APPLICATION ((LPCWSTR)32512)
#define MB_OK 0x00000000L
#define MB_ICONINFORMATION 0x00000040L
#define MB_ICONERROR 0x00000010L
#define MB_ICONWARNING 0x00000030L
#define MB_YESNO 0x00000004L
#define MB_ICONQUESTION 0x00000020L
#define IDYES 6
#define OFN_EXPLORER 0x00080000
#define OFN_FILEMUSTEXIST 0x00001000
#define OFN_PATHMUSTEXIST 0x00000800
#define OFN_HIDEREADONLY 0x00000004
#define OFN_NOCHANGEDIR 0x00000008
#define OFN_OVERWRITEPROMPT 0x00000002
#define BIF_RETURNONLYFSDIRS 0x00000001
#define BIF_NEWDIALOGSTYLE 0x00000040
#define BIF_EDITBOX 0x00000010
#define CP_UTF8 65001
#define TOKEN_QUERY 0x0008
#define TokenElevation 20
#define TokenIntegrityLevel 25
#define ERROR_INSUFFICIENT_BUFFER 122
#define KEY_READ 0x20019
#define KEY_WRITE 0x20006
#define KEY_SET_VALUE 0x0002
#define KEY_QUERY_VALUE 0x0001
#define HKEY_CURRENT_USER ((HKEY)(ULONG_PTR)0x80000001UL)
#define HKEY_LOCAL_MACHINE ((HKEY)(ULONG_PTR)0x80000002UL)
#define REG_SZ 1
#define REG_DWORD 4
#define REG_EXPAND_SZ 2
#define ERROR_SUCCESS 0
#define EVENTLOG_SEQUENTIAL_READ 0x0001
#define EVENTLOG_BACKWARDS_READ 0x0008
#define AF_INET 2
#define TCP_TABLE_OWNER_PID_ALL 5
#define UDP_TABLE_OWNER_PID 1
#define GWL_EXSTYLE (-20)
#define WS_EX_TOOLWINDOW 0x00000080L
#define WS_EX_CLIENTEDGE 0x00000200L
#define MONITOR_DEFAULTTONULL 0x00000000
#define SM_CMONITORS 80
#define SMTO_ABORTIFHUNG 0x0002
#define WTD_UI_NONE 2
#define WTD_REVOKE_NONE 0
#define WTD_CHOICE_FILE 1
#define WTD_STATEACTION_IGNORE 0
#define WTD_CACHE_ONLY_URL_RETRIEVAL 0x00000010
#define BCRYPT_HASH_REUSABLE_FLAG 0x00000020
#define CLSCTX_INPROC_SERVER 1
#define COINIT_APARTMENTTHREADED 0x2
#define STGM_READ 0x00000000L
#define CSIDL_PROGRAMS 0x0002
#define CSIDL_DESKTOPDIRECTORY 0x0010
#define SHGFP_TYPE_CURRENT 0
#define MOVEFILE_DELAY_UNTIL_REBOOT 0x00000004
#define NIM_ADD 0x00000000
#define NIM_MODIFY 0x00000001
#define NIM_DELETE 0x00000002
#define NIF_MESSAGE 0x00000001
#define NIF_ICON 0x00000002
#define NIF_TIP 0x00000004
#define NIF_INFO 0x00000010
#define NIIF_INFO 0x00000001
#define MF_STRING 0x00000000L
#define MF_SEPARATOR 0x00000800L
#define MF_CHECKED 0x00000008L
#define MF_GRAYED 0x00000001L
#define TPM_RIGHTBUTTON 0x0002L
#define TPM_RETURNCMD 0x0100L
#define HWND_TOPMOST ((HWND)(LONG_PTR)-1)
#define HWND_NOTOPMOST ((HWND)(LONG_PTR)-2)
#define VER_PLATFORM_WIN32_NT 2
#define FILE_ATTRIBUTE_HIDDEN 0x00000002
#define FILE_ATTRIBUTE_SYSTEM 0x00000004
#define ENABLE_PROCESSED_OUTPUT 0x0001
#define HWND_TOP ((HWND)0)
#define SWP_NOMOVE 0x0002
#define SWP_NOSIZE 0x0001
#define SWP_NOZORDER 0x0004
#define EM_SETSEL 0x00B1
#define EM_REPLACESEL 0x00C2
#define EM_SETLIMITTEXT 0x00C5
#define BST_CHECKED 1
#define BM_GETCHECK 0x00F0
#define BM_SETCHECK 0x00F1
#define DEFAULT_GUI_FONT 17
#define FW_NORMAL 400
#define FF_DONTCARE 0
#define DEFAULT_CHARSET 1
#define OUT_DEFAULT_PRECIS 0
#define CLIP_DEFAULT_PRECIS 0
#define DEFAULT_QUALITY 0
#define FIXED_PITCH 1
#define FF_MODERN 48
#define LF_FACESIZE 32
#define LOGPIXELSY 90

/* kernel32 */
__declspec(dllimport) HINSTANCE WINAPI GetModuleHandleW(LPCWSTR);
__declspec(dllimport) HANDLE WINAPI CreateMutexW(LPVOID,BOOL,LPCWSTR);
__declspec(dllimport) BOOL WINAPI ReleaseMutex(HANDLE);
__declspec(dllimport) void WINAPI ExitProcess(UINT);
__declspec(dllimport) HANDLE WINAPI GetProcessHeap(void);
__declspec(dllimport) LPVOID WINAPI HeapAlloc(HANDLE,DWORD,SIZE_T);
__declspec(dllimport) BOOL WINAPI HeapFree(HANDLE,DWORD,LPVOID);
__declspec(dllimport) DWORD WINAPI GetLastError(void);
__declspec(dllimport) void WINAPI SetLastError(DWORD);
__declspec(dllimport) HANDLE WINAPI CreateFileW(LPCWSTR,DWORD,DWORD,LPVOID,DWORD,DWORD,HANDLE);
__declspec(dllimport) BOOL WINAPI ReadFile(HANDLE,LPVOID,DWORD,LPDWORD,LPVOID);
__declspec(dllimport) BOOL WINAPI WriteFile(HANDLE,LPCVOID,DWORD,LPDWORD,LPVOID);
__declspec(dllimport) BOOL WINAPI CloseHandle(HANDLE);
__declspec(dllimport) BOOL WINAPI GetFileSizeEx(HANDLE,LONGLONG*);
__declspec(dllimport) BOOL WINAPI SetFilePointerEx(HANDLE,LONGLONG,LONGLONG*,DWORD);
__declspec(dllimport) BOOL WINAPI GetFileAttributesExW(LPCWSTR,INT,LPVOID);
__declspec(dllimport) BOOL WINAPI SetFileAttributesW(LPCWSTR,DWORD);
__declspec(dllimport) DWORD WINAPI GetFileAttributesW(LPCWSTR);
__declspec(dllimport) BOOL WINAPI CreateDirectoryW(LPCWSTR,LPVOID);
__declspec(dllimport) BOOL WINAPI RemoveDirectoryW(LPCWSTR);
__declspec(dllimport) BOOL WINAPI DeleteFileW(LPCWSTR);
__declspec(dllimport) BOOL WINAPI CopyFileW(LPCWSTR,LPCWSTR,BOOL);
__declspec(dllimport) BOOL WINAPI MoveFileExW(LPCWSTR,LPCWSTR,DWORD);
__declspec(dllimport) DWORD WINAPI GetModuleFileNameW(HMODULE,LPWSTR,DWORD);
__declspec(dllimport) DWORD WINAPI GetTempPathW(DWORD,LPWSTR);
__declspec(dllimport) DWORD WINAPI GetCurrentProcessId(void);
__declspec(dllimport) LPWSTR WINAPI GetCommandLineW(void);
__declspec(dllimport) HANDLE WINAPI OpenProcess(DWORD,BOOL,DWORD);
__declspec(dllimport) BOOL WINAPI GetExitCodeProcess(HANDLE,LPDWORD);
__declspec(dllimport) DWORD WINAPI WaitForSingleObject(HANDLE,DWORD);
__declspec(dllimport) HANDLE WINAPI CreateThread(LPVOID,SIZE_T,DWORD (WINAPI*)(LPVOID),LPVOID,DWORD,LPDWORD);
__declspec(dllimport) void WINAPI Sleep(DWORD);
__declspec(dllimport) BOOL WINAPI CreateProcessW(LPCWSTR,LPWSTR,LPVOID,LPVOID,BOOL,DWORD,LPVOID,LPCWSTR,STARTUPINFOW*,PROCESS_INFORMATION*);
__declspec(dllimport) HANDLE WINAPI CreateToolhelp32Snapshot(DWORD,DWORD);
__declspec(dllimport) BOOL WINAPI Process32FirstW(HANDLE,PROCESSENTRY32W*);
__declspec(dllimport) BOOL WINAPI Process32NextW(HANDLE,PROCESSENTRY32W*);
__declspec(dllimport) BOOL WINAPI QueryFullProcessImageNameW(HANDLE,DWORD,LPWSTR,LPDWORD);
__declspec(dllimport) BOOL WINAPI GetProcessTimes(HANDLE,FILETIME*,FILETIME*,FILETIME*,FILETIME*);
__declspec(dllimport) BOOL WINAPI GetSystemTimes(FILETIME*,FILETIME*,FILETIME*);
__declspec(dllimport) BOOL WINAPI GetProcessHandleCount(HANDLE,LPDWORD);
__declspec(dllimport) BOOL WINAPI GetProcessIoCounters(HANDLE,IO_COUNTERS*);
__declspec(dllimport) DWORD WINAPI GetPriorityClass(HANDLE);
__declspec(dllimport) BOOL WINAPI IsWow64Process(HANDLE,BOOL*);
__declspec(dllimport) void WINAPI GetNativeSystemInfo(SYSTEM_INFO*);
__declspec(dllimport) BOOL WINAPI GlobalMemoryStatusEx(MEMORYSTATUSEX*);
__declspec(dllimport) void WINAPI GetLocalTime(SYSTEMTIME*);
__declspec(dllimport) void WINAPI GetSystemTimeAsFileTime(FILETIME*);
__declspec(dllimport) BOOL WINAPI FileTimeToLocalFileTime(const FILETIME*,FILETIME*);
__declspec(dllimport) BOOL WINAPI FileTimeToSystemTime(const FILETIME*,SYSTEMTIME*);
__declspec(dllimport) INT WINAPI WideCharToMultiByte(UINT,DWORD,LPCWSTR,INT,CHAR*,INT,LPCSTR,BOOL*);
__declspec(dllimport) INT WINAPI MultiByteToWideChar(UINT,DWORD,LPCSTR,INT,LPWSTR,INT);
__declspec(dllimport) BOOL WINAPI GetBinaryTypeW(LPCWSTR,LPDWORD);
__declspec(dllimport) HANDLE WINAPI FindFirstFileW(LPCWSTR,WIN32_FIND_DATAW*);
__declspec(dllimport) BOOL WINAPI FindNextFileW(HANDLE,WIN32_FIND_DATAW*);
__declspec(dllimport) BOOL WINAPI FindClose(HANDLE);
__declspec(dllimport) HMODULE WINAPI LoadLibraryW(LPCWSTR);
__declspec(dllimport) BOOL WINAPI FreeLibrary(HMODULE);
__declspec(dllimport) void* WINAPI GetProcAddress(HMODULE,LPCSTR);
__declspec(dllimport) HLOCAL WINAPI LocalFree(HLOCAL);
__declspec(dllimport) BOOL WINAPI GetComputerNameW(LPWSTR,LPDWORD);
__declspec(dllimport) DWORD WINAPI GetEnvironmentVariableW(LPCWSTR,LPWSTR,DWORD);

/* user32 */
__declspec(dllimport) ATOM WINAPI RegisterClassExW(const WNDCLASSEXW*);
__declspec(dllimport) HWND WINAPI CreateWindowExW(DWORD,LPCWSTR,LPCWSTR,DWORD,INT,INT,INT,INT,HWND,HMENU,HINSTANCE,LPVOID);
__declspec(dllimport) BOOL WINAPI ShowWindow(HWND,INT);
__declspec(dllimport) BOOL WINAPI UpdateWindow(HWND);
__declspec(dllimport) LRESULT WINAPI DefWindowProcW(HWND,UINT,WPARAM,LPARAM);
__declspec(dllimport) BOOL WINAPI GetMessageW(MSG*,HWND,UINT,UINT);
__declspec(dllimport) BOOL WINAPI TranslateMessage(const MSG*);
__declspec(dllimport) LRESULT WINAPI DispatchMessageW(const MSG*);
__declspec(dllimport) void WINAPI PostQuitMessage(INT);
__declspec(dllimport) BOOL WINAPI PostMessageW(HWND,UINT,WPARAM,LPARAM);
__declspec(dllimport) HCURSOR WINAPI LoadCursorW(HINSTANCE,LPCWSTR);
__declspec(dllimport) HICON WINAPI LoadIconW(HINSTANCE,LPCWSTR);
__declspec(dllimport) INT WINAPI MessageBoxW(HWND,LPCWSTR,LPCWSTR,UINT);
__declspec(dllimport) BOOL WINAPI SetWindowTextW(HWND,LPCWSTR);
__declspec(dllimport) INT WINAPI GetWindowTextW(HWND,LPWSTR,INT);
__declspec(dllimport) INT WINAPI GetWindowTextLengthW(HWND);
__declspec(dllimport) BOOL WINAPI EnableWindow(HWND,BOOL);
__declspec(dllimport) LRESULT WINAPI SendMessageW(HWND,UINT,WPARAM,LPARAM);
__declspec(dllimport) BOOL WINAPI EnumWindows(WNDENUMPROC,LPARAM);
__declspec(dllimport) BOOL WINAPI IsWindowVisible(HWND);
__declspec(dllimport) BOOL WINAPI IsIconic(HWND);
__declspec(dllimport) BOOL WINAPI IsZoomed(HWND);
__declspec(dllimport) BOOL WINAPI GetWindowRect(HWND,RECT*);
__declspec(dllimport) DWORD WINAPI GetWindowThreadProcessId(HWND,LPDWORD);
__declspec(dllimport) DWORD WINAPI GetGuiResources(HANDLE,DWORD);
__declspec(dllimport) INT WINAPI GetClassNameW(HWND,LPWSTR,INT);
__declspec(dllimport) LONG_PTR WINAPI GetWindowLongPtrW(HWND,INT);
__declspec(dllimport) HANDLE WINAPI MonitorFromRect(const RECT*,DWORD);
__declspec(dllimport) LRESULT WINAPI SendMessageTimeoutW(HWND,UINT,WPARAM,LPARAM,UINT,UINT,ULONG_PTR*);
__declspec(dllimport) UINT_PTR WINAPI SetTimer(HWND,UINT_PTR,UINT,void*);
__declspec(dllimport) BOOL WINAPI KillTimer(HWND,UINT_PTR);
__declspec(dllimport) BOOL WINAPI MoveWindow(HWND,INT,INT,INT,INT,BOOL);
__declspec(dllimport) INT WINAPI GetSystemMetrics(INT);
__declspec(dllimport) INT WINAPI wsprintfW(LPWSTR,LPCWSTR,...);
__declspec(dllimport) BOOL WINAPI SetForegroundWindow(HWND);
__declspec(dllimport) BOOL WINAPI BringWindowToTop(HWND);
__declspec(dllimport) UINT WINAPI RegisterWindowMessageW(LPCWSTR);
__declspec(dllimport) HWND WINAPI FindWindowW(LPCWSTR,LPCWSTR);
__declspec(dllimport) HMENU WINAPI CreatePopupMenu(void);
__declspec(dllimport) BOOL WINAPI AppendMenuW(HMENU,UINT,UINT_PTR,LPCWSTR);
__declspec(dllimport) UINT WINAPI TrackPopupMenu(HMENU,UINT,INT,INT,INT,HWND,LPCVOID);
__declspec(dllimport) BOOL WINAPI DestroyMenu(HMENU);
__declspec(dllimport) BOOL WINAPI SetWindowPos(HWND,HWND,INT,INT,INT,INT,UINT);
__declspec(dllimport) BOOL WINAPI EnumDisplayDevicesW(LPCWSTR,DWORD,DISPLAY_DEVICEW*,DWORD);
__declspec(dllimport) BOOL WINAPI GetClientRect(HWND,RECT*);
__declspec(dllimport) BOOL WINAPI GetCursorPos(POINT*);
__declspec(dllimport) BOOL WINAPI DestroyWindow(HWND);
__declspec(dllimport) HDC WINAPI GetDC(HWND);
__declspec(dllimport) INT WINAPI ReleaseDC(HWND,HDC);

/* gdi32 */
__declspec(dllimport) HFONT WINAPI CreateFontW(INT,INT,INT,INT,INT,DWORD,DWORD,DWORD,DWORD,DWORD,DWORD,DWORD,DWORD,LPCWSTR);
__declspec(dllimport) BOOL WINAPI DeleteObject(HANDLE);
__declspec(dllimport) INT WINAPI GetDeviceCaps(HDC,INT);

/* comdlg32 */
__declspec(dllimport) BOOL WINAPI GetOpenFileNameW(OPENFILENAMEW*);
__declspec(dllimport) BOOL WINAPI GetSaveFileNameW(OPENFILENAMEW*);

/* shell32 */
__declspec(dllimport) LPITEMIDLIST WINAPI SHBrowseForFolderW(BROWSEINFOW*);
__declspec(dllimport) BOOL WINAPI SHGetPathFromIDListW(LPITEMIDLIST,LPWSTR);
__declspec(dllimport) HRESULT WINAPI SHGetFolderPathW(HWND,INT,HANDLE,DWORD,LPWSTR);
__declspec(dllimport) LPWSTR* WINAPI CommandLineToArgvW(LPCWSTR,INT*);
__declspec(dllimport) INT_PTR WINAPI ShellExecuteW(HWND,LPCWSTR,LPCWSTR,LPCWSTR,LPCWSTR,INT);
__declspec(dllimport) BOOL WINAPI Shell_NotifyIconW(DWORD,NOTIFYICONDATAW*);

/* advapi32 */
__declspec(dllimport) LONG WINAPI RegOpenKeyExW(HKEY,LPCWSTR,DWORD,DWORD,HKEY*);
__declspec(dllimport) LONG WINAPI RegCreateKeyExW(HKEY,LPCWSTR,DWORD,LPWSTR,DWORD,DWORD,LPVOID,HKEY*,LPDWORD);
__declspec(dllimport) LONG WINAPI RegQueryValueExW(HKEY,LPCWSTR,LPDWORD,LPDWORD,BYTE*,LPDWORD);
__declspec(dllimport) LONG WINAPI RegSetValueExW(HKEY,LPCWSTR,DWORD,DWORD,const BYTE*,DWORD);
__declspec(dllimport) LONG WINAPI RegEnumValueW(HKEY,DWORD,LPWSTR,LPDWORD,LPDWORD,LPDWORD,BYTE*,LPDWORD);
__declspec(dllimport) LONG WINAPI RegCloseKey(HKEY);
__declspec(dllimport) LONG WINAPI RegDeleteTreeW(HKEY,LPCWSTR);

/* psapi */
__declspec(dllimport) BOOL WINAPI GetProcessMemoryInfo(HANDLE,PROCESS_MEMORY_COUNTERS*,DWORD);

/* version */
__declspec(dllimport) DWORD WINAPI GetFileVersionInfoSizeW(LPCWSTR,LPDWORD);
__declspec(dllimport) BOOL WINAPI GetFileVersionInfoW(LPCWSTR,DWORD,DWORD,LPVOID);
__declspec(dllimport) BOOL WINAPI VerQueryValueW(LPCVOID,LPCWSTR,LPVOID*,UINT*);

/* wintrust */
__declspec(dllimport) LONG WINAPI WinVerifyTrust(HWND,const GUID*,LPVOID);

/* bcrypt */
__declspec(dllimport) LONG WINAPI BCryptOpenAlgorithmProvider(BCRYPT_ALG_HANDLE*,LPCWSTR,LPCWSTR,DWORD);
__declspec(dllimport) LONG WINAPI BCryptGetProperty(BCRYPT_ALG_HANDLE,LPCWSTR,BYTE*,DWORD,LPDWORD,DWORD);
__declspec(dllimport) LONG WINAPI BCryptCreateHash(BCRYPT_ALG_HANDLE,BCRYPT_HASH_HANDLE*,BYTE*,DWORD,BYTE*,DWORD,DWORD);
__declspec(dllimport) LONG WINAPI BCryptHashData(BCRYPT_HASH_HANDLE,BYTE*,DWORD,DWORD);
__declspec(dllimport) LONG WINAPI BCryptFinishHash(BCRYPT_HASH_HANDLE,BYTE*,DWORD,DWORD);
__declspec(dllimport) LONG WINAPI BCryptDestroyHash(BCRYPT_HASH_HANDLE);
__declspec(dllimport) LONG WINAPI BCryptCloseAlgorithmProvider(BCRYPT_ALG_HANDLE,DWORD);

/* iphlpapi */

/* ole32 */
__declspec(dllimport) HRESULT WINAPI CoInitializeEx(LPVOID,DWORD);
__declspec(dllimport) void WINAPI CoUninitialize(void);
__declspec(dllimport) HRESULT WINAPI CoCreateInstance(const GUID*,IUnknown*,DWORD,const GUID*,void**);
__declspec(dllimport) void WINAPI CoTaskMemFree(LPVOID);

#endif
