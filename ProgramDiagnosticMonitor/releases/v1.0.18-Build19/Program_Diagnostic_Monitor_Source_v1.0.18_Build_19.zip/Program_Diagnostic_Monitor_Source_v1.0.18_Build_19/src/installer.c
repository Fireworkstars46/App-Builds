#include "winmini.h"
#define APP_NAME L"Program Diagnostic Monitor"
#define APP_VERSION L"1.0.18"
#define APP_BUILD 19
#define MAX_WPATH 1024
#define IDC_DESKTOP 2001
#define IDC_LAUNCH 2002
#define IDC_INSTALL 2003
#define IDC_STATUS 2004
#define IDC_PATHLBL 2005

static HINSTANCE g_hInst;
static HWND g_hwnd,g_status,g_install,g_desktop,g_launch,g_pathlbl;
static HFONT g_font;
static BOOL g_done=FALSE,g_installSucceeded=FALSE,g_isUpgrade=FALSE,g_existingDesktop=FALSE;
static WCHAR g_installDir[MAX_WPATH];
static const GUID CLSID_ShellLink={0x00021401,0x0000,0x0000,{0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}};
static const GUID IID_IShellLinkW_={0x000214F9,0x0000,0x0000,{0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}};
static const GUID IID_IPersistFile_={0x0000010b,0x0000,0x0000,{0xC0,0x00,0x00,0x00,0x00,0x00,0x00,0x46}};

void *memset(void* d,int c,SIZE_T n){BYTE*p=d;while(n--)*p++=(BYTE)c;return d;}
void *memcpy(void*d,const void*s,SIZE_T n){BYTE*a=d;const BYTE*b=s;while(n--)*a++=*b++;return d;}
int memcmp(const void*a,const void*b,SIZE_T n){const BYTE*x=a,*y=b;while(n--){if(*x!=*y)return*x-*y;x++;y++;}return 0;}
static DWORD wlen(LPCWSTR s){DWORD n=0;while(s&&s[n])n++;return n;}
static void wcopy(LPWSTR d,LPCWSTR s,DWORD c){DWORD i=0;if(!c)return;while(s&&s[i]&&i+1<c){d[i]=s[i];i++;}d[i]=0;}
static void wcat(LPWSTR d,LPCWSTR s,DWORD c){DWORD n=wlen(d),i=0;while(s&&s[i]&&n+i+1<c){d[n+i]=s[i];i++;}d[n+i]=0;}
static void dirnamew(LPCWSTR p,LPWSTR o,DWORD c){wcopy(o,p,c);DWORD n=wlen(o);while(n){if(o[n-1]==L'\\'||o[n-1]==L'/'){o[n-1]=0;return;}n--;}o[0]=0;}
static ULONGLONG rd64(const BYTE*p){ULONGLONG v=0;for(int i=7;i>=0;i--)v=(v<<8)|p[i];return v;}
static BOOL exists(LPCWSTR p){return GetFileAttributesW(p)!=INVALID_FILE_ATTRIBUTES;}
static void ensure_dir(LPCWSTR p){if(p&&p[0])CreateDirectoryW(p,NULL);}

static BOOL create_link(LPCWSTR target,LPCWSTR lnk,LPCWSTR desc){
    IShellLinkW* sl=NULL;IPersistFile* pf=NULL;
    HRESULT hr=CoCreateInstance(&CLSID_ShellLink,NULL,CLSCTX_INPROC_SERVER,&IID_IShellLinkW_,(void**)&sl);if(hr<0||!sl)return FALSE;
    sl->lpVtbl->SetPath(sl,target);sl->lpVtbl->SetDescription(sl,desc);WCHAR wd[MAX_WPATH];dirnamew(target,wd,MAX_WPATH);sl->lpVtbl->SetWorkingDirectory(sl,wd);sl->lpVtbl->SetIconLocation(sl,target,0);
    hr=sl->lpVtbl->QueryInterface(sl,&IID_IPersistFile_,(void**)&pf);BOOL ok=FALSE;if(hr>=0&&pf){hr=pf->lpVtbl->Save(pf,lnk,TRUE);ok=hr>=0;pf->lpVtbl->Release(pf);}sl->lpVtbl->Release(sl);return ok;
}
static void reg_sz(HKEY k,LPCWSTR n,LPCWSTR v){RegSetValueExW(k,n,0,REG_SZ,(const BYTE*)v,(wlen(v)+1)*sizeof(WCHAR));}
static void reg_dw(HKEY k,LPCWSTR n,DWORD v){RegSetValueExW(k,n,0,REG_DWORD,(const BYTE*)&v,sizeof(v));}
static BOOL sha256_file(LPCWSTR path,BYTE out[32]){
    BCRYPT_ALG_HANDLE a=NULL;BCRYPT_HASH_HANDLE h=NULL;BYTE*obj=NULL,*buf=NULL;DWORD objlen=0,got=0;HANDLE f=INVALID_HANDLE_VALUE;BOOL ok=FALSE;
    if(BCryptOpenAlgorithmProvider(&a,L"SHA256",NULL,0)!=0)goto end;if(BCryptGetProperty(a,L"ObjectLength",(BYTE*)&objlen,sizeof(objlen),&got,0)!=0)goto end;obj=HeapAlloc(GetProcessHeap(),0,objlen);if(!obj)goto end;if(BCryptCreateHash(a,&h,obj,objlen,NULL,0,0)!=0)goto end;
    f=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);if(f==INVALID_HANDLE_VALUE)goto end;buf=HeapAlloc(GetProcessHeap(),0,65536);if(!buf)goto end;
    for(;;){DWORD rd=0;if(!ReadFile(f,buf,65536,&rd,NULL))goto end;if(!rd)break;if(BCryptHashData(h,buf,rd,0)!=0)goto end;}if(BCryptFinishHash(h,out,32,0)==0)ok=TRUE;
end:if(buf)HeapFree(GetProcessHeap(),0,buf);if(f!=INVALID_HANDLE_VALUE)CloseHandle(f);if(h)BCryptDestroyHash(h);if(obj)HeapFree(GetProcessHeap(),0,obj);if(a)BCryptCloseAlgorithmProvider(a,0);return ok;
}
static BOOL extract_range(HANDLE src,ULONGLONG off,ULONGLONG len,LPCWSTR dst){
    LONGLONG pos=(LONGLONG)off;if(!SetFilePointerEx(src,pos,NULL,FILE_BEGIN))return FALSE;HANDLE o=CreateFileW(dst,GENERIC_WRITE,0,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);if(o==INVALID_HANDLE_VALUE)return FALSE;BYTE*buf=HeapAlloc(GetProcessHeap(),0,65536);BOOL ok=buf?TRUE:FALSE;ULONGLONG left=len;
    while(ok&&left){DWORD want=left>65536?65536:(DWORD)left,rd=0,wr=0;if(!ReadFile(src,buf,want,&rd,NULL)||rd!=want){ok=FALSE;break;}if(!WriteFile(o,buf,rd,&wr,NULL)||wr!=rd){ok=FALSE;break;}left-=rd;}if(buf)HeapFree(GetProcessHeap(),0,buf);CloseHandle(o);if(!ok)DeleteFileW(dst);return ok;
}
static void ensure_appdata_dirs(LPCWSTR local){
    WCHAR root[MAX_WPATH],p[MAX_WPATH];wcopy(root,local,MAX_WPATH);wcat(root,L"\\ProgramDiagnosticMonitor-Isolated",MAX_WPATH);ensure_dir(root);
    LPCWSTR subs[]={L"\\Data",L"\\Temp",L"\\Logs",L"\\Diagnostics"};for(UINT i=0;i<4;i++){wcopy(p,root,MAX_WPATH);wcat(p,subs[i],MAX_WPATH);ensure_dir(p);}
}
static void startmenu_shortcuts(LPCWSTR app,LPCWSTR uninst){
    WCHAR sm[MAX_WPATH];if(SHGetFolderPathW(NULL,CSIDL_PROGRAMS,NULL,SHGFP_TYPE_CURRENT,sm)<0)return;wcat(sm,L"\\Program Diagnostic Monitor (Isolated)",MAX_WPATH);ensure_dir(sm);
    WCHAR lnk[MAX_WPATH];wcopy(lnk,sm,MAX_WPATH);wcat(lnk,L"\\Program Diagnostic Monitor (Isolated).lnk",MAX_WPATH);create_link(app,lnk,L"Isolated passive Windows freeze/lag diagnostics");
    wcopy(lnk,sm,MAX_WPATH);wcat(lnk,L"\\Uninstall Program Diagnostic Monitor (Isolated).lnk",MAX_WPATH);create_link(uninst,lnk,L"Uninstall Program Diagnostic Monitor (Isolated)");
}
static void apply_desktop_choice(LPCWSTR app){
    WCHAR p[MAX_WPATH];if(SHGetFolderPathW(NULL,CSIDL_DESKTOPDIRECTORY,NULL,SHGFP_TYPE_CURRENT,p)<0)return;wcat(p,L"\\Program Diagnostic Monitor (Isolated).lnk",MAX_WPATH);
    if(SendMessageW(g_desktop,BM_GETCHECK,0,0)==BST_CHECKED)create_link(app,p,L"Isolated passive Windows freeze/lag diagnostics");else DeleteFileW(p);
}
static void install_now(void){
    EnableWindow(g_install,FALSE);SetWindowTextW(g_status,L"Installing files...");
    WCHAR self[MAX_WPATH];GetModuleFileNameW(NULL,self,MAX_WPATH);HANDLE h=CreateFileW(self,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);if(h==INVALID_HANDLE_VALUE){MessageBoxW(g_hwnd,L"Could not read the installer.",APP_NAME,MB_OK|MB_ICONERROR);EnableWindow(g_install,TRUE);return;}
    LONGLONG total=0;if(!GetFileSizeEx(h,&total)||total<88){CloseHandle(h);MessageBoxW(g_hwnd,L"Installer payload is missing or damaged.",APP_NAME,MB_OK|MB_ICONERROR);EnableWindow(g_install,TRUE);return;}BYTE tr[88];SetFilePointerEx(h,total-88,NULL,FILE_BEGIN);DWORD rd=0;ReadFile(h,tr,88,&rd,NULL);if(rd!=88||memcmp(tr,"PDMSET1!",8)!=0){CloseHandle(h);MessageBoxW(g_hwnd,L"Installer payload header is invalid.",APP_NAME,MB_OK|MB_ICONERROR);EnableWindow(g_install,TRUE);return;}
    ULONGLONG as=rd64(tr+8),us=rd64(tr+16),stub=(ULONGLONG)total-88-as-us;if((LONGLONG)stub<0){CloseHandle(h);MessageBoxW(g_hwnd,L"Installer payload sizes are invalid.",APP_NAME,MB_OK|MB_ICONERROR);EnableWindow(g_install,TRUE);return;}
    WCHAR local[MAX_WPATH];DWORD n=GetEnvironmentVariableW(L"LOCALAPPDATA",local,MAX_WPATH);if(!n||n>=MAX_WPATH){CloseHandle(h);MessageBoxW(g_hwnd,L"LOCALAPPDATA is unavailable.",APP_NAME,MB_OK|MB_ICONERROR);EnableWindow(g_install,TRUE);return;}
    WCHAR programs[MAX_WPATH];wcopy(programs,local,MAX_WPATH);wcat(programs,L"\\Programs",MAX_WPATH);ensure_dir(programs);ensure_dir(g_installDir);
    WCHAR app[MAX_WPATH],uninst[MAX_WPATH];wcopy(app,g_installDir,MAX_WPATH);wcat(app,L"\\ProgramDiagnosticMonitor.exe",MAX_WPATH);wcopy(uninst,g_installDir,MAX_WPATH);wcat(uninst,L"\\Uninstall.exe",MAX_WPATH);
    if(!extract_range(h,stub,as,app)||!extract_range(h,stub+as,us,uninst)){CloseHandle(h);MessageBoxW(g_hwnd,L"Could not write the installed files. Close Program Diagnostic Monitor if it is already running, then try again.",APP_NAME,MB_OK|MB_ICONERROR);EnableWindow(g_install,TRUE);return;}CloseHandle(h);
    SetWindowTextW(g_status,L"Verifying installed files...");BYTE ah[32],uh[32];if(!sha256_file(app,ah)||!sha256_file(uninst,uh)||memcmp(ah,tr+24,32)!=0||memcmp(uh,tr+56,32)!=0){DeleteFileW(app);DeleteFileW(uninst);MessageBoxW(g_hwnd,L"File verification failed. Installation was stopped.",APP_NAME,MB_OK|MB_ICONERROR);EnableWindow(g_install,TRUE);return;}
    ensure_appdata_dirs(local);startmenu_shortcuts(app,uninst);apply_desktop_choice(app);
    HKEY k;DWORD disp;if(RegCreateKeyExW(HKEY_CURRENT_USER,L"Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\ProgramDiagnosticMonitor-Isolated",0,NULL,0,KEY_WRITE,NULL,&k,&disp)==ERROR_SUCCESS){WCHAR q[MAX_WPATH+32];reg_sz(k,L"DisplayName",L"Program Diagnostic Monitor (Isolated)");reg_sz(k,L"DisplayVersion",APP_VERSION);reg_sz(k,L"Publisher",L"Custom local utility");reg_sz(k,L"InstallLocation",g_installDir);reg_sz(k,L"DisplayIcon",app);wsprintfW(q,L"\"%s\"",uninst);reg_sz(k,L"UninstallString",q);reg_sz(k,L"QuietUninstallString",q);reg_dw(k,L"NoModify",1);reg_dw(k,L"NoRepair",1);RegCloseKey(k);}
    SetWindowTextW(g_status,L"Installation complete. Existing PDM Data/settings/Logs/Diagnostics were preserved. Click Finish to close Setup.");SetWindowTextW(g_install,L"Finish");EnableWindow(g_install,TRUE);SetWindowTextW(g_pathlbl,g_installDir);g_installSucceeded=TRUE;
}
static LRESULT CALLBACK proc(HWND h,UINT m,WPARAM w,LPARAM l){(void)l;switch(m){
case WM_CREATE:{
    HWND title=CreateWindowExW(0,L"STATIC",L"Program Diagnostic Monitor (Isolated)",WS_CHILD|WS_VISIBLE,22,18,510,34,h,0,g_hInst,NULL);
    HWND desc=CreateWindowExW(0,L"STATIC",L"Automatic passive freeze/lag diagnostics with a dedicated isolated namespace. Installs per-user and does not require administrator access.",WS_CHILD|WS_VISIBLE,22,58,520,42,h,0,g_hInst,NULL);
    HWND il=CreateWindowExW(0,L"STATIC",L"Install location:",WS_CHILD|WS_VISIBLE,22,112,120,22,h,0,g_hInst,NULL);
    g_pathlbl=CreateWindowExW(WS_BORDER,L"EDIT",g_installDir,WS_CHILD|WS_VISIBLE|ES_READONLY|ES_AUTOHSCROLL,22,136,520,26,h,(HMENU)IDC_PATHLBL,g_hInst,NULL);
    g_desktop=CreateWindowExW(0,L"BUTTON",L"Create desktop shortcut",WS_CHILD|WS_VISIBLE|BS_AUTOCHECKBOX,22,180,300,26,h,(HMENU)IDC_DESKTOP,g_hInst,NULL);
    g_launch=CreateWindowExW(0,L"BUTTON",L"Launch Program Diagnostic Monitor when I click Finish",WS_CHILD|WS_VISIBLE|BS_AUTOCHECKBOX,22,210,500,26,h,(HMENU)IDC_LAUNCH,g_hInst,NULL);
    SendMessageW(g_desktop,BM_SETCHECK,g_isUpgrade?(g_existingDesktop?BST_CHECKED:0):BST_CHECKED,0);SendMessageW(g_launch,BM_SETCHECK,BST_CHECKED,0);
    g_status=CreateWindowExW(0,L"STATIC",L"Ready to install. Dedicated install/data/temp/log/diagnostics locations; no shared custom-app helpers or settings.",WS_CHILD|WS_VISIBLE,22,252,520,40,h,(HMENU)IDC_STATUS,g_hInst,NULL);
    g_install=CreateWindowExW(0,L"BUTTON",L"Install",WS_CHILD|WS_VISIBLE|BS_DEFPUSHBUTTON,390,304,150,34,h,(HMENU)IDC_INSTALL,g_hInst,NULL);
    HDC dc=GetDC(h);INT dpi=dc?GetDeviceCaps(dc,LOGPIXELSY):96;if(dc)ReleaseDC(h,dc);g_font=CreateFontW(-((10*dpi)/72),0,0,0,FW_NORMAL,0,0,0,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,0,L"Segoe UI");HWND all[]={title,desc,il,g_pathlbl,g_desktop,g_launch,g_status,g_install};for(UINT i=0;i<sizeof(all)/sizeof(all[0]);i++)SendMessageW(all[i],WM_SETFONT,(WPARAM)g_font,TRUE);return 0;}
case WM_COMMAND:if((w&0xffff)==IDC_INSTALL){if(g_done){if(g_installSucceeded&&SendMessageW(g_launch,BM_GETCHECK,0,0)==BST_CHECKED){WCHAR app[MAX_WPATH];wcopy(app,g_installDir,MAX_WPATH);wcat(app,L"\\ProgramDiagnosticMonitor.exe",MAX_WPATH);ShellExecuteW(g_hwnd,L"open",app,NULL,g_installDir,SW_SHOWNORMAL);}PostQuitMessage(0);return 0;}install_now();if(g_installSucceeded)g_done=TRUE;return 0;}break;
case WM_DESTROY:if(g_font)DeleteObject(g_font);PostQuitMessage(0);return 0;}return DefWindowProcW(h,m,w,l);}

void wWinMainCRTStartup(void){
    g_hInst=GetModuleHandleW(NULL);CoInitializeEx(NULL,COINIT_APARTMENTTHREADED);WCHAR local[MAX_WPATH];DWORD n=GetEnvironmentVariableW(L"LOCALAPPDATA",local,MAX_WPATH);if(!n||n>=MAX_WPATH)wcopy(local,L"C:\\Program Diagnostic Monitor",MAX_WPATH);wcopy(g_installDir,local,MAX_WPATH);wcat(g_installDir,L"\\Programs\\ProgramDiagnosticMonitor-Isolated",MAX_WPATH);
    WCHAR app[MAX_WPATH];wcopy(app,g_installDir,MAX_WPATH);wcat(app,L"\\ProgramDiagnosticMonitor.exe",MAX_WPATH);g_isUpgrade=exists(app);WCHAR desk[MAX_WPATH];if(SHGetFolderPathW(NULL,CSIDL_DESKTOPDIRECTORY,NULL,SHGFP_TYPE_CURRENT,desk)>=0){wcat(desk,L"\\Program Diagnostic Monitor (Isolated).lnk",MAX_WPATH);g_existingDesktop=exists(desk);}
    WNDCLASSEXW c;memset(&c,0,sizeof(c));c.cbSize=sizeof(c);c.lpfnWndProc=proc;c.hInstance=g_hInst;c.hCursor=LoadCursorW(NULL,IDC_ARROW);c.hIcon=LoadIconW(g_hInst,(LPCWSTR)(ULONG_PTR)1);if(!c.hIcon)c.hIcon=LoadIconW(NULL,IDI_APPLICATION);c.hIconSm=c.hIcon;c.hbrBackground=(HBRUSH)(ULONG_PTR)(COLOR_WINDOW+1);c.lpszClassName=L"PDMIsolatedInstallerWindow";RegisterClassExW(&c);
    g_hwnd=CreateWindowExW(0,c.lpszClassName,L"Setup — Program Diagnostic Monitor 1.0.18 Build 19 (Isolated)",WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU,220,160,580,400,NULL,NULL,g_hInst,NULL);if(!g_hwnd)ExitProcess(2);ShowWindow(g_hwnd,SW_SHOW);UpdateWindow(g_hwnd);MSG m;while(GetMessageW(&m,NULL,0,0)>0){TranslateMessage(&m);DispatchMessageW(&m);}CoUninitialize();ExitProcess(0);
}
