#include "winmini.h"

#define APP_NAME L"Program Diagnostic Monitor"
#define APP_VERSION L"1.0.18"
#define APP_BUILD 19
#define APP_WINDOW_CLASS L"ProgramDiagnosticMonitorIsolatedWindow"
#define SETTINGS_MUTEX_NAME L"Local\\ProgramDiagnosticMonitor-Isolated-SettingsWrite"
#define MAX_WPATH 1024
#define REPORT_CAP (4*1024*1024)
#define TIMELINE_CAP (256*1024)
#define MAX_TRACKED_PIDS 1024
#define LIVE_MEMORY_SAMPLE_LIMIT 96
#define PROCESS_DETAIL_LIMIT 200
#define PROCESS_STORM_THRESHOLD 128
#define TIMELINE_PROCESS_LIMIT 120
#define RESTART_WAIT_MS 30000
#define MAX_WINDOWS 512
#define MAX_PERF_SAMPLES 3600
#define FREEZE_DETAIL_CAP (768*1024)
#define MAX_CHILD_STATES 512
#define MAX_WCT_THREADS_PER_FREEZE 4
#define AUTO_PROBE_TIMEOUT_MS 150
#define AUTO_LAG_THRESHOLD_MS 60
#define AUTO_LAG_STREAK_REQUIRED 2
#define AUTO_RECOVERY_STREAK_REQUIRED 2

#define IDC_PATH 1001
#define IDC_BROWSE 1002
#define IDC_ARGS 1003
#define IDC_WATCH 1004
#define IDC_WATCH_BROWSE 1005
#define IDC_START 1006
#define IDC_STOP 1007
#define IDC_SAVE 1008
#define IDC_BASELINE 1009
#define IDC_REPORT 1010
#define IDC_STATUS 1011
#define IDC_OPENFOLDER 1012
#define IDC_ATTACH_EXISTING 1013
#define IDC_SETTINGS 1014
#define IDC_SELFTEST 1015
#define IDC_DEBUG 1016
#define IDC_EXITAPP 1017
#define IDC_SET_MINIMIZE 3001
#define IDC_SET_CLOSE 3002
#define IDC_SET_STARTMIN 3003
#define IDC_SET_OPENSETTINGS 3004
#define IDC_SET_STARTPAUSED 3005
#define IDC_SET_NOTIFICATIONS 3006
#define IDC_SET_DEBUG 3007
#define IDC_SET_SINGLECLICK 3008
#define IDC_SET_CLOSEBTN 3009
#define IDC_SET_EXITBTN 3010
#define IDC_SET_RESETLAYOUT 3011
#define IDM_TRAY_SHOW 4001
#define IDM_TRAY_SETTINGS 4002
#define IDM_TRAY_STARTSTOP 4003
#define IDM_TRAY_PAUSERESUME 4004
#define IDM_TRAY_DEBUG 4005
#define IDM_TRAY_SELFTEST 4006
#define IDM_TRAY_LOGS 4007
#define IDM_TRAY_DIAGNOSTICS 4008
#define IDM_TRAY_EXPORT 4009
#define IDM_TRAY_EXIT 4010
#define EN_CHANGE 0x0300
#define BN_CLICKED 0
#define WM_APP 0x8000
#define WM_PDM_STATUS (WM_APP+1)
#define WM_PDM_ANALYSIS_COMPLETE (WM_APP+2)
#define WM_PDM_NO_INSTANCE (WM_APP+3)
#define WM_PDM_WORKER_ERROR (WM_APP+4)
#define WM_PDM_TRAY (WM_APP+5)
#define WM_PDM_APPLY_SETTINGS (WM_APP+6)

static HINSTANCE g_hInst;
static HWND g_hwnd, g_pathEdit, g_argsEdit, g_watchEdit, g_reportEdit, g_status;
static HWND g_programLabel, g_argsLabel, g_watchLabel;
static HWND g_browseBtn, g_watchBrowseBtn, g_startBtn, g_stopBtn, g_saveBtn, g_baseBtn, g_openFolderBtn, g_attachCheck, g_markBtn;
static HWND g_settingsBtn,g_selfTestBtn,g_debugCheck,g_exitBtn,g_settingsHwnd;
static HWND g_setMinimize,g_setClose,g_setStartMin,g_setOpenSettings,g_setStartPaused,g_setNotifications,g_setDebug,g_setSingleClick,g_setCloseBtn,g_setExitBtn,g_setResetLayout;
static INT g_dpi = 96;
static HFONT g_uiFont, g_monoFont;
static WCHAR g_program[MAX_WPATH];
static WCHAR g_args[2048];
static WCHAR g_watchFolder[MAX_WPATH];
/* v1.0.14: keep target Browse and report Save folders independent. */
static WCHAR g_lastExeDir[MAX_WPATH];
static WCHAR g_lastReportDir[MAX_WPATH];
static WCHAR g_appDataDir[MAX_WPATH];
static WCHAR g_dataDir[MAX_WPATH];
static WCHAR g_tempDir[MAX_WPATH];
static WCHAR g_logsDir[MAX_WPATH];
static WCHAR g_diagDir[MAX_WPATH];
static WCHAR g_settingsPath[MAX_WPATH];
static WCHAR g_logPath[MAX_WPATH];
typedef struct {BOOL minimizeToTray;BOOL closeToTray;BOOL startMinimized;BOOL openSettingsAtStartup;BOOL startPaused;BOOL notifications;BOOL debugMode;DWORD trayClickMode;INT winX;INT winY;INT winW;INT winH;} APPSETTINGS;
static APPSETTINGS g_settings={FALSE,FALSE,FALSE,FALSE,FALSE,TRUE,FALSE,2,70,55,1120,800};
#define SETF_MINIMIZE      0x0001u
#define SETF_CLOSE         0x0002u
#define SETF_STARTMIN      0x0004u
#define SETF_OPENSETTINGS  0x0008u
#define SETF_STARTPAUSED   0x0010u
#define SETF_NOTIFICATIONS 0x0020u
#define SETF_DEBUG         0x0040u
#define SETF_TRAYCLICK     0x0080u
#define SETF_GEOMETRY      0x0100u
#define SETF_ALL           0x01FFu
static BOOL g_paused=FALSE;
static BOOL g_exiting=FALSE;
static BOOL g_trayAdded=FALSE;
static UINT g_taskbarCreated=0;
static ULONGLONG g_lastHelperRefresh=0;
static WCHAR* g_report;
static WCHAR* g_timeline;
static DWORD g_reportLen, g_timelineLen;
static HANDLE g_rootHandle;
static DWORD g_rootPid;
static ULONGLONG g_startTick;
static DWORD g_startUnix;
static BOOL g_monitoring;
static HANDLE g_workerHandle;
static volatile LONG g_stopRequested;
static volatile LONG g_shutdownRequested;
static BOOL g_preferExisting;
static BOOL g_attachedExisting;
static DWORD g_attachSeedCount;
static DWORD g_attachMatchedCount;
static DWORD g_uniquePids[MAX_TRACKED_PIDS];
static ULONGLONG g_uniqueCreateTimes[MAX_TRACKED_PIDS];
static DWORD g_uniqueParentPids[MAX_TRACKED_PIDS];
static ULONGLONG g_uniqueLastSeenMs[MAX_TRACKED_PIDS];
static DWORD g_uniquePidCount;
static DWORD g_activePids[MAX_TRACKED_PIDS];
static ULONGLONG g_activeCreateTimes[MAX_TRACKED_PIDS];
static DWORD g_activePidCount;
static ULONGLONG g_rootCreateTime;
static BOOL g_trackingTruncated;
static BOOL g_processStorm;
static BOOL g_memorySamplingUsed;
static BOOL g_timelineProcessSuppressed;
static ULONGLONG g_zeroActiveSinceTick;
static BOOL g_targetExitAutoDetected;
static DWORD g_restartCount;
static DWORD g_restartWaitEpisodes;
static DWORD g_maxProcessCount;
static ULONGLONG g_maxWorkingSet;
static BOOL g_everVisibleWindow;
static BOOL g_everHiddenWindow;
static DWORD g_firstVisibleMs;
static BOOL g_rootExited;
static DWORD g_rootExitCode;
static DWORD g_lastCrashEvents;
static DWORD g_lastHangEvents;
static DWORD g_lastNetworkCount;
static DWORD g_lastModuleCount;
static DWORD g_lastFolderChanges;
static WCHAR* g_freezeDetails;
static DWORD g_freezeDetailsLen;
static DWORD g_wctCycleCount;
static DWORD g_memoryGrowthFlags;
static DWORD g_peakChildCpuPermille;
static ULONGLONG g_peakChildWorkingSet;
static DWORD g_peakSystemCpuPermille;
static DWORD g_peakDiskPercent;
static BOOL g_diskCounterEverValid;
static DWORD g_peakGdiObjects;
static DWORD g_peakUserObjects;
static ULONGLONG g_prevSysIdle100ns,g_prevSysKernel100ns,g_prevSysUser100ns;

typedef struct {
    DWORD pid; ULONGLONG createTime; ULONGLONG lastCpu100ns; ULONGLONG lastTickMs;
    ULONGLONG lastReadBytes; ULONGLONG lastWriteBytes; DWORD lastCpuPermille;
    ULONGLONG lastWorkingSet; ULONGLONG lastPrivateBytes; DWORD lastThreads; DWORD lastHandles;
} CHILDSTATE;
static CHILDSTATE g_childStates[MAX_CHILD_STATES];
static DWORD g_childStateCount;

/* Optional PDH disk counter is loaded dynamically so the executable keeps a small, documented import surface. */
typedef LONG (WINAPI *PFN_PDH_OPEN_QUERY_W)(LPCWSTR,ULONG_PTR,HANDLE*);
typedef LONG (WINAPI *PFN_PDH_ADD_ENGLISH_COUNTER_W)(HANDLE,LPCWSTR,ULONG_PTR,HANDLE*);
typedef LONG (WINAPI *PFN_PDH_COLLECT_QUERY_DATA)(HANDLE);
typedef LONG (WINAPI *PFN_PDH_GET_FORMATTED_COUNTER_VALUE)(HANDLE,DWORD,LPDWORD,LPVOID);
typedef LONG (WINAPI *PFN_PDH_CLOSE_QUERY)(HANDLE);
typedef struct { DWORD CStatus; union { LONG longValue; LONGLONG largeValue; LPCWSTR wideStringValue; } u; } PDM_PDH_FMT_COUNTERVALUE;
static HMODULE g_pdhModule; static HANDLE g_pdhQuery,g_pdhDiskCounter;
static PFN_PDH_OPEN_QUERY_W g_pdhOpenQuery; static PFN_PDH_ADD_ENGLISH_COUNTER_W g_pdhAddEnglishCounter;
static PFN_PDH_COLLECT_QUERY_DATA g_pdhCollect; static PFN_PDH_GET_FORMATTED_COUNTER_VALUE g_pdhGetFormatted; static PFN_PDH_CLOSE_QUERY g_pdhClose;

typedef struct {
    ULONGLONG offsetMs;
    DWORD cpuPermille;
    ULONGLONG workingSet;
    ULONGLONG privateBytes;
    DWORD threads;
    DWORD handles;
    DWORD pageFaults;
    ULONGLONG readBytes;
    ULONGLONG writeBytes;
    DWORD windowCount;
    DWORD visibleCount;
    DWORD hungCount;
    DWORD probeMaxMs;
    DWORD systemCpuPermille;
    DWORD systemMemoryLoad;
    ULONGLONG systemAvailPhys;
    DWORD diskPercent;
    DWORD gdiObjects;
    DWORD userObjects;
    DWORD childCount;
    DWORD childCpuPermille;
    ULONGLONG childWorkingSet;
    ULONGLONG childPrivateBytes;
    ULONGLONG childReadDelta;
    ULONGLONG childWriteDelta;
    DWORD topChildPid;
    DWORD topChildCpuPermille;
    BYTE autoSeverity; /* 0 none, 1 lag, 2 freeze */
    BOOL marked;       /* automatic event start/escalation */
} PERFSAMPLE;
static PERFSAMPLE g_perfSamples[MAX_PERF_SAMPLES];
static DWORD g_perfCount;
static BOOL g_perfTruncated;
static ULONGLONG g_prevCpu100ns;
static ULONGLONG g_prevCpuWallMs;
static DWORD g_peakCpuPermille;
static ULONGLONG g_sumCpuPermille;
static DWORD g_cpuSampleCount;
static ULONGLONG g_peakPrivateBytes;
static DWORD g_peakThreads;
static DWORD g_peakHandles;
static DWORD g_peakPageFaults;
static ULONGLONG g_firstReadBytes;
static ULONGLONG g_firstWriteBytes;
static ULONGLONG g_lastReadBytes;
static ULONGLONG g_lastWriteBytes;
static DWORD g_autoEventCount;
static DWORD g_autoLagEventCount;
static DWORD g_autoFreezeEventCount;
static DWORD g_autoSlowStreak;
static DWORD g_autoRecoveryStreak;
static BOOL g_autoEpisodeActive;
static BYTE g_autoEpisodeSeverity;
static BOOL g_waitedForTarget;
static ULONGLONG g_targetDetectedTick;

typedef struct {
    DWORD maxProcessCount;
    ULONGLONG maxWorkingSet;
    BOOL visible;
    BOOL rootExited;
    DWORD exitCode;
    DWORD crashEvents;
    DWORD hangEvents;
    DWORD networkCount;
    DWORD moduleCount;
    DWORD folderChanges;
    BOOL valid;
} BASELINE;
static BASELINE g_baseline;

typedef struct {
    HWND hwnd; DWORD pid; BOOL visible; BOOL minimized; BOOL maximized; BOOL hung; BOOL offscreen;
    DWORD probeMs;
    RECT rect; WCHAR title[512]; WCHAR cls[128];
} WININFO;
static WININFO g_windows[MAX_WINDOWS];
static DWORD g_windowCount;


/* basic CRT replacements */
void *memset(void* d, int c, SIZE_T n){ BYTE* p=(BYTE*)d; while(n--) *p++=(BYTE)c; return d; }
void *memcpy(void* d,const void* s,SIZE_T n){ BYTE* a=(BYTE*)d; const BYTE* b=(const BYTE*)s; while(n--) *a++=*b++; return d; }
int memcmp(const void* a,const void* b,SIZE_T n){ const BYTE* x=a; const BYTE* y=b; while(n--){ if(*x!=*y) return (int)*x-(int)*y; x++; y++; } return 0; }
static DWORD wlen(LPCWSTR s){ DWORD n=0; if(!s) return 0; while(s[n]) n++; return n; }
static void wcopy(LPWSTR d,LPCWSTR s,DWORD cap){ DWORD i=0; if(!cap)return; if(s){ while(i+1<cap && s[i]){d[i]=s[i];i++;}} d[i]=0; }
static void wcat(LPWSTR d,LPCWSTR s,DWORD cap){ DWORD n=wlen(d),i=0; if(n>=cap)return; while(s && s[i] && n+i+1<cap){d[n+i]=s[i];i++;} d[n+i]=0; }
static WCHAR lowerc(WCHAR c){ if(c>=L'A'&&c<=L'Z') return c+32; return c; }
static int wicmp(LPCWSTR a,LPCWSTR b){ while(*a&&*b){ WCHAR x=lowerc(*a),y=lowerc(*b); if(x!=y)return (int)x-(int)y; a++;b++; } return (int)lowerc(*a)-(int)lowerc(*b); }
static BOOL wcontainsi(LPCWSTR hay,LPCWSTR needle){ DWORD hn=wlen(hay), nn=wlen(needle); if(nn==0)return TRUE; if(nn>hn)return FALSE; for(DWORD i=0;i+nn<=hn;i++){ DWORD j=0; for(;j<nn;j++) if(lowerc(hay[i+j])!=lowerc(needle[j])) break; if(j==nn)return TRUE;} return FALSE; }
static LPCWSTR basenamew(LPCWSTR p){ LPCWSTR b=p; while(*p){ if(*p==L'\\'||*p==L'/') b=p+1; p++; } return b; }
static void dirnamew(LPCWSTR p,LPWSTR out,DWORD cap){ wcopy(out,p,cap); DWORD n=wlen(out); while(n){ if(out[n-1]==L'\\'||out[n-1]==L'/'){out[n-1]=0; return;} n--; } out[0]=0; }
static BOOL pid_in_list(DWORD pid,const DWORD* list,DWORD n){ for(DWORD i=0;i<n;i++) if(list[i]==pid)return TRUE; return FALSE; }
static BOOL is_protected_peer_name(LPCWSTR n){return wicmp(n,L"CrashMonitor.exe")==0||wicmp(n,L"Crash Monitor.exe")==0||wicmp(n,L"RitschyMirror.exe")==0;}
static BOOL selected_target_is_peer(void){return is_protected_peer_name(basenamew(g_program));}
static ULONGLONG ft64(FILETIME f){ return ((ULONGLONG)f.dwHighDateTime<<32)|f.dwLowDateTime; }
static ULONGLONG tick_now(void){ FILETIME f; GetSystemTimeAsFileTime(&f); return ft64(f)/10000ULL; }
static DWORD unix_now(void){ FILETIME f; GetSystemTimeAsFileTime(&f); ULONGLONG t=ft64(f); if(t<116444736000000000ULL)return 0; return (DWORD)((t-116444736000000000ULL)/10000000ULL); }
static void append_buf(WCHAR* buf,DWORD* len,DWORD cap,LPCWSTR s){ DWORD n=wlen(s); if(*len>=cap-1)return; if(n>cap-1-*len)n=cap-1-*len; memcpy(buf+*len,s,n*sizeof(WCHAR)); *len+=n; buf[*len]=0; }
static void rep(LPCWSTR s){ append_buf(g_report,&g_reportLen,REPORT_CAP,s); }
static void line(LPCWSTR s){ rep(s); rep(L"\r\n"); }
static void timeline(LPCWSTR s){ SYSTEMTIME st; WCHAR tmp[1024]; GetLocalTime(&st); wsprintfW(tmp,L"[%02u:%02u:%02u.%03u] %s\r\n",st.wHour,st.wMinute,st.wSecond,st.wMilliseconds,s); append_buf(g_timeline,&g_timelineLen,TIMELINE_CAP,tmp); }
static void set_status(LPCWSTR s){ SetWindowTextW(g_status,s); }
static WCHAR* heap_wdup(LPCWSTR s){DWORD n=wlen(s);WCHAR* p=(WCHAR*)HeapAlloc(GetProcessHeap(),0,(n+1)*sizeof(WCHAR));if(!p)return NULL;memcpy(p,s,(n+1)*sizeof(WCHAR));return p;}
static void post_status(LPCWSTR s){WCHAR* p=heap_wdup(s);if(!p)return;if(!PostMessageW(g_hwnd,WM_PDM_STATUS,0,(LPARAM)p))HeapFree(GetProcessHeap(),0,p);}
static void post_worker_error(LPCWSTR s){WCHAR* p=heap_wdup(s);if(!p)return;if(!PostMessageW(g_hwnd,WM_PDM_WORKER_ERROR,0,(LPARAM)p))HeapFree(GetProcessHeap(),0,p);}
static void report_to_ui(void){ SendMessageW(g_reportEdit,EM_SETSEL,0,-1); SendMessageW(g_reportEdit,EM_REPLACESEL,FALSE,(LPARAM)g_report); }
static void set_inputs_enabled(BOOL en){EnableWindow(g_pathEdit,en);EnableWindow(g_argsEdit,en);EnableWindow(g_watchEdit,FALSE);EnableWindow(g_browseBtn,en);EnableWindow(g_watchBrowseBtn,FALSE);EnableWindow(g_attachCheck,FALSE);EnableWindow(g_openFolderBtn,en&&g_program[0]);}
static void sep(LPCWSTR title){ WCHAR t[512]; wsprintfW(t,L"\r\n===== %s =====\r\n",title); rep(t); }
static void fmt_bytes(ULONGLONG b,LPWSTR out){ if(b>=1073741824ULL) wsprintfW(out,L"%I64u.%02I64u GB",b/1073741824ULL,(b%1073741824ULL)*100ULL/1073741824ULL); else if(b>=1048576ULL) wsprintfW(out,L"%I64u.%02I64u MB",b/1048576ULL,(b%1048576ULL)*100ULL/1048576ULL); else if(b>=1024ULL) wsprintfW(out,L"%I64u.%02I64u KB",b/1024ULL,(b%1024ULL)*100ULL/1024ULL); else wsprintfW(out,L"%I64u B",b); }
static void fmt_filetime(FILETIME ft,LPWSTR out){ FILETIME l; SYSTEMTIME s; if(FileTimeToLocalFileTime(&ft,&l)&&FileTimeToSystemTime(&l,&s)) wsprintfW(out,L"%04u-%02u-%02u %02u:%02u:%02u",s.wYear,s.wMonth,s.wDay,s.wHour,s.wMinute,s.wSecond); else wcopy(out,L"Unknown",64); }

/* v1.0.14 deeper read-only freeze diagnostics */
static DWORD logical_cpu_count(void);
static BOOL query_process_path(DWORD pid,LPWSTR out,DWORD cap);
static BOOL path_prefix_i(LPCWSTR path,LPCWSTR prefix);
static ULONGLONG process_create_time(DWORD pid);
static void freeze_append(LPCWSTR s){ if(g_freezeDetails)append_buf(g_freezeDetails,&g_freezeDetailsLen,FREEZE_DETAIL_CAP,s); }
static void freeze_line(LPCWSTR s){ freeze_append(s); freeze_append(L"\r\n"); }
static void show_main_window(void);
static void open_settings_window(void);
static void run_safe_self_test(void);
static void request_exit(void);
static void tray_add(void);
static void tray_remove(void);
static void tray_notify(LPCWSTR,LPCWSTR);
static void log_event(LPCWSTR,LPCWSTR);
static void log_debug(LPCWSTR);
static void font_all(HWND);

static void disk_counter_close(void){
    if(g_pdhQuery&&g_pdhClose)g_pdhClose(g_pdhQuery);g_pdhQuery=NULL;g_pdhDiskCounter=NULL;
    if(g_pdhModule)FreeLibrary(g_pdhModule);g_pdhModule=NULL;
    g_pdhOpenQuery=NULL;g_pdhAddEnglishCounter=NULL;g_pdhCollect=NULL;g_pdhGetFormatted=NULL;g_pdhClose=NULL;
}
static void disk_counter_init(void){
    disk_counter_close();g_pdhModule=LoadLibraryW(L"pdh.dll");if(!g_pdhModule)return;
    g_pdhOpenQuery=(PFN_PDH_OPEN_QUERY_W)GetProcAddress(g_pdhModule,"PdhOpenQueryW");
    g_pdhAddEnglishCounter=(PFN_PDH_ADD_ENGLISH_COUNTER_W)GetProcAddress(g_pdhModule,"PdhAddEnglishCounterW");
    g_pdhCollect=(PFN_PDH_COLLECT_QUERY_DATA)GetProcAddress(g_pdhModule,"PdhCollectQueryData");
    g_pdhGetFormatted=(PFN_PDH_GET_FORMATTED_COUNTER_VALUE)GetProcAddress(g_pdhModule,"PdhGetFormattedCounterValue");
    g_pdhClose=(PFN_PDH_CLOSE_QUERY)GetProcAddress(g_pdhModule,"PdhCloseQuery");
    if(!g_pdhOpenQuery||!g_pdhAddEnglishCounter||!g_pdhCollect||!g_pdhGetFormatted||!g_pdhClose){disk_counter_close();return;}
    if(g_pdhOpenQuery(NULL,0,&g_pdhQuery)!=0){disk_counter_close();return;}
    if(g_pdhAddEnglishCounter(g_pdhQuery,L"\\PhysicalDisk(_Total)\\% Disk Time",0,&g_pdhDiskCounter)!=0){disk_counter_close();return;}
    g_pdhCollect(g_pdhQuery);
}
static DWORD sample_disk_percent(void){
    if(!g_pdhQuery||!g_pdhDiskCounter||!g_pdhCollect||!g_pdhGetFormatted)return 0xFFFFFFFFu;
    if(g_pdhCollect(g_pdhQuery)!=0)return 0xFFFFFFFFu;
    PDM_PDH_FMT_COUNTERVALUE v;memset(&v,0,sizeof(v));DWORD type=0;
    if(g_pdhGetFormatted(g_pdhDiskCounter,0x00000100,&type,&v)!=0)return 0xFFFFFFFFu;
    if(v.CStatus!=0&&v.CStatus!=1)return 0xFFFFFFFFu;
    if(v.u.longValue<0)return 0;DWORD d=(DWORD)v.u.longValue;if(d>999)d=999;return d;
}
static DWORD sample_system_cpu(void){
    FILETIME idle,kern,user;if(!GetSystemTimes(&idle,&kern,&user))return 0;
    ULONGLONG i=ft64(idle),k=ft64(kern),u=ft64(user);DWORD pm=0;
    if(g_prevSysKernel100ns&&k>=g_prevSysKernel100ns&&u>=g_prevSysUser100ns&&i>=g_prevSysIdle100ns){
        ULONGLONG dk=k-g_prevSysKernel100ns,du=u-g_prevSysUser100ns,di=i-g_prevSysIdle100ns,total=dk+du;
        if(total){ULONGLONG busy=total>di?total-di:0;pm=(DWORD)(busy*1000ULL/total);if(pm>1000)pm=1000;}
    }
    g_prevSysIdle100ns=i;g_prevSysKernel100ns=k;g_prevSysUser100ns=u;return pm;
}
static void sample_system_memory(DWORD* load,ULONGLONG* avail){MEMORYSTATUSEX m;memset(&m,0,sizeof(m));m.dwLength=sizeof(m);if(GlobalMemoryStatusEx(&m)){*load=m.dwMemoryLoad;*avail=m.ullAvailPhys;}else{*load=0;*avail=0;}}
static void sample_gui_resources(DWORD* gdi,DWORD* user){*gdi=0;*user=0;for(DWORD i=0;i<g_activePidCount;i++){HANDLE p=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION,FALSE,g_activePids[i]);if(!p)continue;*gdi+=GetGuiResources(p,GR_GDIOBJECTS);*user+=GetGuiResources(p,GR_USEROBJECTS);CloseHandle(p);}}

typedef struct {DWORD count;DWORD cpuPermille;ULONGLONG workingSet;ULONGLONG privateBytes;ULONGLONG readDelta;ULONGLONG writeDelta;DWORD topPid;DWORD topCpuPermille;} CHILDMETRICS;
static CHILDSTATE* child_state_get(DWORD pid,ULONGLONG ct){for(DWORD i=0;i<g_childStateCount;i++)if(g_childStates[i].pid==pid&&g_childStates[i].createTime==ct)return &g_childStates[i];if(g_childStateCount>=MAX_CHILD_STATES)return NULL;CHILDSTATE* s=&g_childStates[g_childStateCount++];memset(s,0,sizeof(*s));s->pid=pid;s->createTime=ct;return s;}
static void collect_child_metrics(ULONGLONG now,CHILDMETRICS* out){
    memset(out,0,sizeof(*out));WCHAR selectedDir[MAX_WPATH];dirnamew(g_program,selectedDir,MAX_WPATH);LPCWSTR selectedBase=basenamew(g_program);
    HANDLE snap=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);if(snap==INVALID_HANDLE_VALUE)return;PROCESSENTRY32W pe;memset(&pe,0,sizeof(pe));pe.dwSize=sizeof(pe);
    if(Process32FirstW(snap,&pe)){do{
        if(wicmp(pe.szExeFile,selectedBase)!=0||pid_in_list(pe.th32ProcessID,g_activePids,g_activePidCount)){pe.dwSize=sizeof(pe);continue;}
        if(is_protected_peer_name(pe.szExeFile)&&!selected_target_is_peer()){pe.dwSize=sizeof(pe);continue;}
        WCHAR path[MAX_WPATH];if(!query_process_path(pe.th32ProcessID,path,MAX_WPATH)||(!(wicmp(path,g_program)==0)&&!(selectedDir[0]&&path_prefix_i(path,selectedDir)))){pe.dwSize=sizeof(pe);continue;}
        ULONGLONG ct=process_create_time(pe.th32ProcessID);if(!ct){pe.dwSize=sizeof(pe);continue;}HANDLE p=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION,FALSE,pe.th32ProcessID);if(!p){pe.dwSize=sizeof(pe);continue;}
        ULONGLONG cpu100=0,ws=0,priv=0,rb=0,wb=0;DWORD hc=0;FILETIME c,e,k,u;if(GetProcessTimes(p,&c,&e,&k,&u))cpu100=ft64(k)+ft64(u);PROCESS_MEMORY_COUNTERS_EX pm;memset(&pm,0,sizeof(pm));pm.cb=sizeof(pm);if(GetProcessMemoryInfo(p,(PROCESS_MEMORY_COUNTERS*)&pm,sizeof(pm))){ws=pm.WorkingSetSize;priv=pm.PrivateUsage;}GetProcessHandleCount(p,&hc);IO_COUNTERS io;memset(&io,0,sizeof(io));if(GetProcessIoCounters(p,&io)){rb=io.ReadTransferCount;wb=io.WriteTransferCount;}CloseHandle(p);
        CHILDSTATE* st=child_state_get(pe.th32ProcessID,ct);DWORD cpuPm=0;ULONGLONG rd=0,wd=0;if(st){if(st->lastTickMs&&now>st->lastTickMs&&cpu100>=st->lastCpu100ns){ULONGLONG wall=(now-st->lastTickMs)*10000ULL*(ULONGLONG)logical_cpu_count();if(wall)cpuPm=(DWORD)((cpu100-st->lastCpu100ns)*1000ULL/wall);if(cpuPm>1000)cpuPm=1000;}if(st->lastReadBytes&&rb>=st->lastReadBytes)rd=rb-st->lastReadBytes;if(st->lastWriteBytes&&wb>=st->lastWriteBytes)wd=wb-st->lastWriteBytes;st->lastCpu100ns=cpu100;st->lastTickMs=now;st->lastReadBytes=rb;st->lastWriteBytes=wb;st->lastCpuPermille=cpuPm;st->lastWorkingSet=ws;st->lastPrivateBytes=priv;st->lastThreads=pe.cntThreads;st->lastHandles=hc;}
        out->count++;out->cpuPermille+=cpuPm;if(out->cpuPermille>1000)out->cpuPermille=1000;out->workingSet+=ws;out->privateBytes+=priv;out->readDelta+=rd;out->writeDelta+=wd;if(cpuPm>out->topCpuPermille){out->topCpuPermille=cpuPm;out->topPid=pe.th32ProcessID;}
        pe.dwSize=sizeof(pe);
    }while(Process32NextW(snap,&pe));}CloseHandle(snap);
}

#define PDM_WCT_MAX_NODE_COUNT 16
#define PDM_WCT_OBJNAME_LENGTH 128
typedef struct {WCHAR ObjectName[PDM_WCT_OBJNAME_LENGTH];LONGLONG Timeout;BOOL Alertable;} PDM_WCT_LOCK_OBJECT;
typedef struct {DWORD ProcessId;DWORD ThreadId;DWORD WaitTime;DWORD ContextSwitches;} PDM_WCT_THREAD_OBJECT;
typedef union {PDM_WCT_LOCK_OBJECT LockObject;PDM_WCT_THREAD_OBJECT ThreadObject;} PDM_WCT_UNION;
typedef struct {DWORD ObjectType;DWORD ObjectStatus;PDM_WCT_UNION u;} PDM_WCT_NODE;
typedef HANDLE (WINAPI *PFN_WCT_OPEN)(DWORD,LPVOID);typedef BOOL (WINAPI *PFN_WCT_GET)(HANDLE,ULONG_PTR,DWORD,DWORD,LPDWORD,PDM_WCT_NODE*,BOOL*);typedef void (WINAPI *PFN_WCT_CLOSE)(HANDLE);
static LPCWSTR wct_type_name(DWORD t){switch(t){case 1:return L"CriticalSection";case 2:return L"SendMessage";case 3:return L"Mutex";case 4:return L"ALPC";case 5:return L"COM";case 6:return L"ThreadWait";case 7:return L"ProcessWait";case 8:return L"Thread";case 9:return L"COMActivation";default:return L"Unknown";}}
static LPCWSTR wct_status_name(DWORD s){switch(s){case 1:return L"NoAccess";case 2:return L"Running";case 3:return L"Blocked";case 4:return L"PidOnly";case 5:return L"PidOnlyRpcss";case 6:return L"Owned";case 7:return L"NotOwned";case 8:return L"Abandoned";case 9:return L"Unknown";case 10:return L"Error";default:return L"?";}}
static BOOL tid_in_array(DWORD tid,const DWORD* a,DWORD n){for(DWORD i=0;i<n;i++)if(a[i]==tid)return TRUE;return FALSE;}
static void capture_wait_chain_for_tid(DWORD tid){
    HMODULE a=LoadLibraryW(L"advapi32.dll");if(!a){freeze_line(L"  Wait Chain Traversal unavailable (advapi32 load failed).");return;}PFN_WCT_OPEN op=(PFN_WCT_OPEN)GetProcAddress(a,"OpenThreadWaitChainSession");PFN_WCT_GET gt=(PFN_WCT_GET)GetProcAddress(a,"GetThreadWaitChain");PFN_WCT_CLOSE cl=(PFN_WCT_CLOSE)GetProcAddress(a,"CloseThreadWaitChainSession");if(!op||!gt||!cl){freeze_line(L"  Wait Chain Traversal unavailable on this Windows build.");FreeLibrary(a);return;}HANDLE h=op(0,NULL);if(!h){freeze_line(L"  Wait Chain Traversal session could not be opened.");FreeLibrary(a);return;}PDM_WCT_NODE nodes[PDM_WCT_MAX_NODE_COUNT];memset(nodes,0,sizeof(nodes));DWORD count=PDM_WCT_MAX_NODE_COUNT;BOOL cyc=FALSE;WCHAR tmp[768];if(gt(h,0,0,tid,&count,nodes,&cyc)){wsprintfW(tmp,L"  WCT thread %u: %u node(s)%s",tid,count,cyc?L" — CYCLE/DEADLOCK SUSPECTED":L"");freeze_line(tmp);if(cyc)g_wctCycleCount++;DWORD lim=count<PDM_WCT_MAX_NODE_COUNT?count:PDM_WCT_MAX_NODE_COUNT;for(DWORD i=0;i<lim;i++){PDM_WCT_NODE* n=&nodes[i];if(n->ObjectType==8){wsprintfW(tmp,L"    [%u] %s / %s  PID %u TID %u wait=%u ms switches=%u",i,wct_type_name(n->ObjectType),wct_status_name(n->ObjectStatus),n->u.ThreadObject.ProcessId,n->u.ThreadObject.ThreadId,n->u.ThreadObject.WaitTime,n->u.ThreadObject.ContextSwitches);}else{LPCWSTR nm=n->u.LockObject.ObjectName[0]?n->u.LockObject.ObjectName:L"(unnamed)";wsprintfW(tmp,L"    [%u] %s / %s  object=%s",i,wct_type_name(n->ObjectType),wct_status_name(n->ObjectStatus),nm);}freeze_line(tmp);}}else{wsprintfW(tmp,L"  WCT thread %u: unavailable/error %u",tid,GetLastError());freeze_line(tmp);}cl(h);FreeLibrary(a);
}
static void capture_child_detail(void){WCHAR tmp[768];freeze_line(L"Helper/subprocess snapshot (same executable family; command lines are intentionally not inspected):");BOOL used[MAX_CHILD_STATES];memset(used,0,sizeof(used));DWORD shown=0;ULONGLONG now=tick_now();for(DWORD pass=0;pass<24;pass++){INT best=-1;DWORD bestCpu=0;ULONGLONG bestMem=0;for(DWORD i=0;i<g_childStateCount;i++){if(used[i]||!g_childStates[i].lastTickMs||now-g_childStates[i].lastTickMs>7000)continue;if(best<0||g_childStates[i].lastCpuPermille>bestCpu||(g_childStates[i].lastCpuPermille==bestCpu&&g_childStates[i].lastWorkingSet>bestMem)){best=(INT)i;bestCpu=g_childStates[i].lastCpuPermille;bestMem=g_childStates[i].lastWorkingSet;}}if(best<0)break;used[best]=TRUE;CHILDSTATE* c=&g_childStates[best];WCHAR wb[64],pb[64];fmt_bytes(c->lastWorkingSet,wb);fmt_bytes(c->lastPrivateBytes,pb);wsprintfW(tmp,L"  PID %u  CPU %u.%u%%  WS %s  Private %s  threads %u  handles %u",c->pid,c->lastCpuPermille/10,c->lastCpuPermille%10,wb,pb,c->lastThreads,c->lastHandles);freeze_line(tmp);shown++;}if(!shown)freeze_line(L"  No live helper/subprocess metrics were available at this freeze.");}
static void capture_freeze_deep_snapshot(DWORD freezeNo){
    if(!g_freezeDetails)return;WCHAR tmp[1024];wsprintfW(tmp,L"\r\n===== AUTO FREEZE #%u — ISOLATED READ-ONLY SNAPSHOT =====",freezeNo);freeze_line(tmp);freeze_line(L"Captured automatically at freeze onset. No injection, suspension, debugger attach, stack walking, target-thread opening, or target modification is used.");
    if(g_perfCount){PERFSAMPLE* q=&g_perfSamples[g_perfCount-1];WCHAR mw[64],cw[64],av[64];fmt_bytes(q->workingSet,mw);fmt_bytes(q->childWorkingSet,cw);fmt_bytes(q->systemAvailPhys,av);if(q->diskPercent==0xFFFFFFFFu)wsprintfW(tmp,L"At trigger: main CPU %u.%u%%, main WS %s, helpers %u / CPU %u.%u%% / WS %s, system CPU %u.%u%%, RAM %u%% used (%s available), disk counter unavailable, GDI %u, USER %u",q->cpuPermille/10,q->cpuPermille%10,mw,q->childCount,q->childCpuPermille/10,q->childCpuPermille%10,cw,q->systemCpuPermille/10,q->systemCpuPermille%10,q->systemMemoryLoad,av,q->gdiObjects,q->userObjects);else wsprintfW(tmp,L"At trigger: main CPU %u.%u%%, main WS %s, helpers %u / CPU %u.%u%% / WS %s, system CPU %u.%u%%, RAM %u%% used (%s available), disk %u%%, GDI %u, USER %u",q->cpuPermille/10,q->cpuPermille%10,mw,q->childCount,q->childCpuPermille/10,q->childCpuPermille%10,cw,q->systemCpuPermille/10,q->systemCpuPermille%10,q->systemMemoryLoad,av,q->diskPercent,q->gdiObjects,q->userObjects);freeze_line(tmp);}
    capture_child_detail();
    DWORD uiTids[MAX_WCT_THREADS_PER_FREEZE];DWORD uiCount=0;for(DWORD i=0;i<g_windowCount&&uiCount<MAX_WCT_THREADS_PER_FREEZE;i++){if(!g_windows[i].hung)continue;DWORD pid=0;DWORD tid=GetWindowThreadProcessId(g_windows[i].hwnd,&pid);if(tid&&!tid_in_array(tid,uiTids,uiCount))uiTids[uiCount++]=tid;}
    freeze_line(L"Wait Chain Traversal: hung MAIN UI threads only (no system-wide thread snapshot, no OpenThread, in-process WCT flags only):");for(DWORD i=0;i<uiCount;i++)capture_wait_chain_for_tid(uiTids[i]);if(!uiCount)freeze_line(L"  No hung MAIN UI thread ID was available for WCT.");
}

static INT sc(INT v){ return (INT)(((LONGLONG)v * g_dpi + 48) / 96); }
static void init_dpi_awareness(void){
    HMODULE u=LoadLibraryW(L"user32.dll");
    if(u){
        typedef BOOL (WINAPI *PFN_SETDPI)(void);
        PFN_SETDPI f=(PFN_SETDPI)GetProcAddress(u,"SetProcessDPIAware");
        if(f) f();
        FreeLibrary(u);
    }
    HDC dc=GetDC(NULL);
    if(dc){ INT d=GetDeviceCaps(dc,LOGPIXELSY); if(d>=96 && d<=480) g_dpi=d; ReleaseDC(NULL,dc); }
}

static void init_dialog_dirs(void){
    DWORD n=GetEnvironmentVariableW(L"ProgramFiles",g_lastExeDir,MAX_WPATH);
    if(!n||n>=MAX_WPATH)g_lastExeDir[0]=0;
    WCHAR home[MAX_WPATH];home[0]=0;n=GetEnvironmentVariableW(L"USERPROFILE",home,MAX_WPATH);
    if(n&&n<MAX_WPATH){wcopy(g_lastReportDir,home,MAX_WPATH);wcat(g_lastReportDir,L"\\Documents",MAX_WPATH);}
    else g_lastReportDir[0]=0;
}
static BOOL choose_exe(HWND owner){
    WCHAR f[MAX_WPATH]={0},typedDir[MAX_WPATH]={0};
    /* If a program path was typed/pasted, Browse should naturally start beside that program. */
    if(g_program[0]){dirnamew(g_program,typedDir,MAX_WPATH);if(typedDir[0])wcopy(g_lastExeDir,typedDir,MAX_WPATH);}
    OPENFILENAMEW o; memset(&o,0,sizeof(o)); o.lStructSize=sizeof(o); o.hwndOwner=owner;
    o.lpstrFilter=L"Programs (*.exe)\0*.exe\0All files (*.*)\0*.*\0\0"; o.lpstrFile=f; o.nMaxFile=MAX_WPATH;
    o.lpstrInitialDir=g_lastExeDir[0]?g_lastExeDir:NULL; o.lpstrTitle=L"Select a program to diagnose";
    o.Flags=OFN_EXPLORER|OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST|OFN_HIDEREADONLY|OFN_NOCHANGEDIR;
    if(GetOpenFileNameW(&o)){dirnamew(f,g_lastExeDir,MAX_WPATH);wcopy(g_program,f,MAX_WPATH); SetWindowTextW(g_pathEdit,g_program); EnableWindow(g_startBtn,TRUE); EnableWindow(g_openFolderBtn,TRUE); set_status(L"Program selected. Click Start Diagnostic when ready."); return TRUE;}
    return FALSE;
}
static BOOL save_text_file(HWND owner,LPCWSTR text){
    WCHAR f[MAX_WPATH]={0},name[160]={0}; SYSTEMTIME st; GetLocalTime(&st);
    wsprintfW(name,L"ProgramDiagnostic-%04u%02u%02u-%02u%02u%02u.txt",st.wYear,st.wMonth,st.wDay,st.wHour,st.wMinute,st.wSecond);
    /* Give Save Report its own folder history. It never borrows the executable Browse folder. */
    if(g_lastReportDir[0]){wcopy(f,g_lastReportDir,MAX_WPATH);DWORD n=wlen(f);if(n&&f[n-1]!=L'\\'&&f[n-1]!=L'/')wcat(f,L"\\",MAX_WPATH);wcat(f,name,MAX_WPATH);}
    else wcopy(f,name,MAX_WPATH);
    OPENFILENAMEW o; memset(&o,0,sizeof(o)); o.lStructSize=sizeof(o); o.hwndOwner=owner;
    o.lpstrFilter=L"Text report (*.txt)\0*.txt\0All files (*.*)\0*.*\0\0"; o.lpstrFile=f; o.nMaxFile=MAX_WPATH; o.lpstrDefExt=L"txt";
    o.lpstrInitialDir=g_lastReportDir[0]?g_lastReportDir:NULL; o.lpstrTitle=L"Save diagnostic report";
    o.Flags=OFN_EXPLORER|OFN_PATHMUSTEXIST|OFN_OVERWRITEPROMPT|OFN_NOCHANGEDIR;
    if(!GetSaveFileNameW(&o))return FALSE;
    dirnamew(f,g_lastReportDir,MAX_WPATH);
    HANDLE h=CreateFileW(f,GENERIC_WRITE,FILE_SHARE_READ,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL); if(h==INVALID_HANDLE_VALUE){MessageBoxW(owner,L"Could not create the report file.",APP_NAME,MB_OK|MB_ICONERROR);return FALSE;} INT need=WideCharToMultiByte(CP_UTF8,0,text,-1,NULL,0,NULL,NULL); if(need<=0){CloseHandle(h);return FALSE;} CHAR* u=(CHAR*)HeapAlloc(GetProcessHeap(),0,need); if(!u){CloseHandle(h);return FALSE;} WideCharToMultiByte(CP_UTF8,0,text,-1,u,need,NULL,NULL); DWORD wr=0; BYTE bom[3]={0xEF,0xBB,0xBF}; WriteFile(h,bom,3,&wr,NULL); WriteFile(h,u,(DWORD)(need-1),&wr,NULL); HeapFree(GetProcessHeap(),0,u); CloseHandle(h); MessageBoxW(owner,L"Report saved.",APP_NAME,MB_OK|MB_ICONINFORMATION); return TRUE;
}

static void sha256_file(LPCWSTR path,LPWSTR hexOut,DWORD cap){ if(cap<65){if(cap)hexOut[0]=0;return;} BCRYPT_ALG_HANDLE alg=NULL; BCRYPT_HASH_HANDLE hh=NULL; BYTE hash[32]; DWORD objLen=0,got=0; BYTE* obj=NULL; HANDLE f=INVALID_HANDLE_VALUE; BYTE* chunk=NULL; hexOut[0]=0; if(BCryptOpenAlgorithmProvider(&alg,L"SHA256",NULL,0)!=0)goto done; if(BCryptGetProperty(alg,L"ObjectLength",(BYTE*)&objLen,sizeof(objLen),&got,0)!=0)goto done; obj=(BYTE*)HeapAlloc(GetProcessHeap(),0,objLen); if(!obj)goto done; if(BCryptCreateHash(alg,&hh,obj,objLen,NULL,0,0)!=0)goto done; f=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL); if(f==INVALID_HANDLE_VALUE)goto done; chunk=(BYTE*)HeapAlloc(GetProcessHeap(),0,65536); if(!chunk)goto done; for(;;){DWORD rd=0;if(!ReadFile(f,chunk,65536,&rd,NULL))goto done;if(!rd)break;if(BCryptHashData(hh,chunk,rd,0)!=0)goto done;} if(BCryptFinishHash(hh,hash,32,0)!=0)goto done; static const WCHAR hx[]=L"0123456789abcdef"; for(DWORD i=0;i<32;i++){hexOut[i*2]=hx[hash[i]>>4];hexOut[i*2+1]=hx[hash[i]&15];} hexOut[64]=0;
done: if(chunk)HeapFree(GetProcessHeap(),0,chunk); if(f!=INVALID_HANDLE_VALUE)CloseHandle(f); if(hh)BCryptDestroyHash(hh); if(obj)HeapFree(GetProcessHeap(),0,obj); if(alg)BCryptCloseAlgorithmProvider(alg,0); }

static void executable_info(void){ sep(L"EXECUTABLE"); WCHAR tmp[2048],buf[128],hash[80]; WIN32_FILE_ATTRIBUTE_DATA fd; if(GetFileAttributesExW(g_program,0,&fd)){ ULONGLONG size=((ULONGLONG)fd.nFileSizeHigh<<32)|fd.nFileSizeLow; fmt_bytes(size,buf); wsprintfW(tmp,L"Path: %s\r\nFile size: %s\r\n",g_program,buf); rep(tmp); fmt_filetime(fd.ftLastWriteTime,buf); wsprintfW(tmp,L"Last modified: %s\r\n",buf); rep(tmp);} DWORD bt=0; if(GetBinaryTypeW(g_program,&bt)){ LPCWSTR a=L"Unknown"; if(bt==0)a=L"32-bit Windows"; else if(bt==6)a=L"64-bit Windows"; else if(bt==5)a=L"DOS"; wsprintfW(tmp,L"Binary type: %s\r\n",a);rep(tmp);} DWORD dummy=0,vs=GetFileVersionInfoSizeW(g_program,&dummy); if(vs){ BYTE* v=(BYTE*)HeapAlloc(GetProcessHeap(),0,vs); if(v&&GetFileVersionInfoW(g_program,0,vs,v)){ VS_FIXEDFILEINFO* fi=NULL; UINT n=0; if(VerQueryValueW(v,L"\\",(void**)&fi,&n)&&fi){ wsprintfW(tmp,L"File version: %u.%u.%u.%u\r\n",(fi->dwFileVersionMS>>16)&0xffff,fi->dwFileVersionMS&0xffff,(fi->dwFileVersionLS>>16)&0xffff,fi->dwFileVersionLS&0xffff);rep(tmp);} } if(v)HeapFree(GetProcessHeap(),0,v);} GUID action={0x00AAC56B,0xCD44,0x11d0,{0x8C,0xC2,0x00,0xC0,0x4F,0xC2,0x95,0xEE}}; WINTRUST_FILE_INFO wf; WINTRUST_DATA wd; memset(&wf,0,sizeof(wf)); memset(&wd,0,sizeof(wd)); wf.cbStruct=sizeof(wf);wf.pcwszFilePath=g_program;wd.cbStruct=sizeof(wd);wd.dwUIChoice=WTD_UI_NONE;wd.fdwRevocationChecks=WTD_REVOKE_NONE;wd.dwUnionChoice=WTD_CHOICE_FILE;wd.pFile=&wf;wd.dwStateAction=WTD_STATEACTION_IGNORE;wd.dwProvFlags=WTD_CACHE_ONLY_URL_RETRIEVAL; LONG vr=WinVerifyTrust(NULL,&action,&wd); wsprintfW(tmp,L"Digital signature verification: %s (0x%08X)\r\n",vr==0?L"Valid / trusted":L"Not verified or not trusted",(DWORD)vr);rep(tmp); line(L"Signature check is cache-only; this diagnostic tool does not contact the internet."); post_status(L"Analyzing — hashing selected executable..."); sha256_file(g_program,hash,80); if(hash[0]){wsprintfW(tmp,L"SHA-256: %s\r\n",hash);rep(tmp);} else line(L"SHA-256: unavailable"); }

static void system_info(void){ sep(L"SYSTEM"); WCHAR tmp[2048]; HKEY k; DWORD type=0,sz; if(RegOpenKeyExW(HKEY_LOCAL_MACHINE,L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion",0,KEY_READ,&k)==ERROR_SUCCESS){ WCHAR product[256]=L"Windows",display[64]=L"",build[64]=L""; sz=sizeof(product);RegQueryValueExW(k,L"ProductName",NULL,&type,(BYTE*)product,&sz);sz=sizeof(display);RegQueryValueExW(k,L"DisplayVersion",NULL,&type,(BYTE*)display,&sz);sz=sizeof(build);RegQueryValueExW(k,L"CurrentBuildNumber",NULL,&type,(BYTE*)build,&sz); wsprintfW(tmp,L"OS: %s %s (build %s)\r\n",product,display,build);rep(tmp);RegCloseKey(k);} SYSTEM_INFO si; memset(&si,0,sizeof(si));GetNativeSystemInfo(&si); LPCWSTR arch=L"Unknown"; if(si.wProcessorArchitecture==9)arch=L"x64 (AMD64)"; else if(si.wProcessorArchitecture==0)arch=L"x86"; else if(si.wProcessorArchitecture==12)arch=L"ARM64"; wsprintfW(tmp,L"System architecture: %s\r\nLogical processors: %u\r\n",arch,si.dwNumberOfProcessors);rep(tmp); MEMORYSTATUSEX ms; memset(&ms,0,sizeof(ms));ms.dwLength=sizeof(ms);if(GlobalMemoryStatusEx(&ms)){WCHAR total[64],avail[64];fmt_bytes(ms.ullTotalPhys,total);fmt_bytes(ms.ullAvailPhys,avail);wsprintfW(tmp,L"Physical memory: %s total, %s available (%u%% used)\r\n",total,avail,ms.dwMemoryLoad);rep(tmp);} INT monitors=GetSystemMetrics(SM_CMONITORS);wsprintfW(tmp,L"Display monitors: %d\r\n",monitors);rep(tmp); line(L"Display adapters:"); for(DWORD i=0;i<16;i++){DISPLAY_DEVICEW d;memset(&d,0,sizeof(d));d.cb=sizeof(d);if(!EnumDisplayDevicesW(NULL,i,&d,0))break;wsprintfW(tmp,L"  [%u] %s — %s (flags 0x%08X)\r\n",i,d.DeviceName,d.DeviceString,d.StateFlags);rep(tmp);} }


static ULONGLONG process_create_time(DWORD pid){HANDLE p=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION,FALSE,pid);if(!p)return 0;FILETIME c,e,k,u;ULONGLONG v=0;if(GetProcessTimes(p,&c,&e,&k,&u))v=ft64(c);CloseHandle(p);return v;}
static INT unique_find(DWORD pid,ULONGLONG ct){for(DWORD i=0;i<g_uniquePidCount;i++)if(g_uniquePids[i]==pid&&g_uniqueCreateTimes[i]==ct)return (INT)i;return -1;}
static INT active_find(DWORD pid){for(DWORD i=0;i<g_activePidCount;i++)if(g_activePids[i]==pid)return (INT)i;return -1;}
static DWORD unique_add(DWORD pid,ULONGLONG ct,DWORD ppid){if(!pid)return 0;if(!ct)ct=process_create_time(pid);if(unique_find(pid,ct)>=0)return 0;if(g_uniquePidCount>=MAX_TRACKED_PIDS){g_trackingTruncated=TRUE;return 0;}DWORD i=g_uniquePidCount++;g_uniquePids[i]=pid;g_uniqueCreateTimes[i]=ct;g_uniqueParentPids[i]=ppid;g_uniqueLastSeenMs[i]=tick_now();if(i<TIMELINE_PROCESS_LIMIT){WCHAR t[320];wsprintfW(t,L"Process discovered: PID %u  PPID %u  identity=%I64X",pid,ppid,ct);timeline(t);}else if(!g_timelineProcessSuppressed){timeline(L"Additional process-discovery timeline entries suppressed for performance; totals remain tracked.");g_timelineProcessSuppressed=TRUE;}return 1;}
static void active_add(DWORD pid,ULONGLONG ct){if(!pid||active_find(pid)>=0)return;if(g_activePidCount>=MAX_TRACKED_PIDS){g_trackingTruncated=TRUE;return;}g_activePids[g_activePidCount]=pid;g_activeCreateTimes[g_activePidCount]=ct;g_activePidCount++;INT u=unique_find(pid,ct);if(u>=0)g_uniqueLastSeenMs[u]=tick_now();}
static BOOL path_prefix_i(LPCWSTR path,LPCWSTR prefix){DWORD n=wlen(prefix);if(!n)return FALSE;for(DWORD i=0;i<n;i++){if(!path[i]||lowerc(path[i])!=lowerc(prefix[i]))return FALSE;}return path[n]==0||path[n]==L'\\'||path[n]==L'/';}
static BOOL query_process_path(DWORD pid,LPWSTR out,DWORD cap){if(!cap)return FALSE;out[0]=0;HANDLE h=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION,FALSE,pid);if(!h)return FALSE;DWORD n=cap;BOOL ok=QueryFullProcessImageNameW(h,0,out,&n);CloseHandle(h);if(!ok)out[0]=0;return ok;}
static DWORD seed_existing_program_family(void){
    /* v1.0.9: attach to MAIN matching process(es) only. Chromium-style apps can have many
       renderer/GPU/utility subprocesses with the same exe name; those are intentionally not
       deep-scanned because doing so can overload a machine when the target is already hung. */
    WCHAR selectedDir[MAX_WPATH];dirnamew(g_program,selectedDir,MAX_WPATH);LPCWSTR selectedBase=basenamew(g_program);
    HANDLE s=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);if(s==INVALID_HANDLE_VALUE)return 0;
    DWORD* pids=(DWORD*)HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,sizeof(DWORD)*MAX_TRACKED_PIDS);
    DWORD* ppids=(DWORD*)HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,sizeof(DWORD)*MAX_TRACKED_PIDS);
    ULONGLONG* cts=(ULONGLONG*)HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,sizeof(ULONGLONG)*MAX_TRACKED_PIDS);
    if(!pids||!ppids||!cts){if(pids)HeapFree(GetProcessHeap(),0,pids);if(ppids)HeapFree(GetProcessHeap(),0,ppids);if(cts)HeapFree(GetProcessHeap(),0,cts);CloseHandle(s);return 0;}
    PROCESSENTRY32W pe;memset(&pe,0,sizeof(pe));pe.dwSize=sizeof(pe);DWORD n=0;
    if(Process32FirstW(s,&pe)){do{
        if(wicmp(pe.szExeFile,selectedBase)!=0){pe.dwSize=sizeof(pe);continue;}
        if(is_protected_peer_name(pe.szExeFile)&&!selected_target_is_peer()){pe.dwSize=sizeof(pe);continue;}
        WCHAR path[MAX_WPATH];if(!query_process_path(pe.th32ProcessID,path,MAX_WPATH)){pe.dwSize=sizeof(pe);continue;}
        BOOL family=(wicmp(path,g_program)==0)||(selectedDir[0]&&path_prefix_i(path,selectedDir));
        if(!family){pe.dwSize=sizeof(pe);continue;}
        ULONGLONG ct=process_create_time(pe.th32ProcessID);if(!ct){pe.dwSize=sizeof(pe);continue;}
        if(n<MAX_TRACKED_PIDS){pids[n]=pe.th32ProcessID;ppids[n]=pe.th32ParentProcessID;cts[n]=ct;n++;}
        pe.dwSize=sizeof(pe);
    }while(Process32NextW(s,&pe));}
    CloseHandle(s);g_attachMatchedCount=n;
    DWORD roots=0;
    for(DWORD i=0;i<n;i++){
        BOOL parentIsMatching=pid_in_list(ppids[i],pids,n);
        if(parentIsMatching)continue;
        unique_add(pids[i],cts[i],ppids[i]);
        if(!g_rootPid){g_rootPid=pids[i];g_rootCreateTime=cts[i];}
        roots++;
    }
    /* Fallback for an unusual/corrupt parent chain: choose one representative matching process,
       rather than attaching to every subprocess. */
    if(!roots&&n){unique_add(pids[0],cts[0],ppids[0]);g_rootPid=pids[0];g_rootCreateTime=cts[0];roots=1;}
    HeapFree(GetProcessHeap(),0,pids);HeapFree(GetProcessHeap(),0,ppids);HeapFree(GetProcessHeap(),0,cts);
    return roots;
}
static PROCESSENTRY32W* find_pe(PROCESSENTRY32W* arr,DWORD n,DWORD pid){for(DWORD i=0;i<n;i++)if(arr[i].th32ProcessID==pid)return &arr[i];return NULL;}
static BOOL historical_main_pid(DWORD pid){for(DWORD i=0;i<g_uniquePidCount;i++)if(g_uniquePids[i]==pid)return TRUE;return FALSE;}
static BOOL known_helper_identity(DWORD pid,ULONGLONG ct){for(DWORD i=0;i<g_childStateCount;i++)if(g_childStates[i].pid==pid&&g_childStates[i].createTime==ct)return TRUE;return FALSE;}
static DWORD discover_restart_main_roots(void){
    /* v1.0.18 Build 19: while the previous MAIN process is gone, look for a genuinely new root
       from the same executable family. Known helper identities and orphaned children of
       a historical MAIN PID are rejected so a leftover renderer/GPU process is not
       promoted into a false browser MAIN process. */
    WCHAR selectedDir[MAX_WPATH];dirnamew(g_program,selectedDir,MAX_WPATH);LPCWSTR selectedBase=basenamew(g_program);
    HANDLE snap=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);if(snap==INVALID_HANDLE_VALUE)return 0;
    DWORD* pids=(DWORD*)HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,sizeof(DWORD)*MAX_TRACKED_PIDS);
    DWORD* ppids=(DWORD*)HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,sizeof(DWORD)*MAX_TRACKED_PIDS);
    ULONGLONG* cts=(ULONGLONG*)HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,sizeof(ULONGLONG)*MAX_TRACKED_PIDS);
    if(!pids||!ppids||!cts){if(pids)HeapFree(GetProcessHeap(),0,pids);if(ppids)HeapFree(GetProcessHeap(),0,ppids);if(cts)HeapFree(GetProcessHeap(),0,cts);CloseHandle(snap);return 0;}
    PROCESSENTRY32W pe;memset(&pe,0,sizeof(pe));pe.dwSize=sizeof(pe);DWORD n=0;
    if(Process32FirstW(snap,&pe)){do{
        if(wicmp(pe.szExeFile,selectedBase)!=0){pe.dwSize=sizeof(pe);continue;}
        if(is_protected_peer_name(pe.szExeFile)&&!selected_target_is_peer()){pe.dwSize=sizeof(pe);continue;}
        WCHAR path[MAX_WPATH];if(!query_process_path(pe.th32ProcessID,path,MAX_WPATH)){pe.dwSize=sizeof(pe);continue;}
        BOOL family=(wicmp(path,g_program)==0)||(selectedDir[0]&&path_prefix_i(path,selectedDir));
        if(!family){pe.dwSize=sizeof(pe);continue;}
        ULONGLONG ct=process_create_time(pe.th32ProcessID);if(!ct){pe.dwSize=sizeof(pe);continue;}
        if(n<MAX_TRACKED_PIDS){pids[n]=pe.th32ProcessID;ppids[n]=pe.th32ParentProcessID;cts[n]=ct;n++;}
        pe.dwSize=sizeof(pe);
    }while(Process32NextW(snap,&pe));}
    CloseHandle(snap);DWORD added=0;
    for(DWORD i=0;i<n;i++){
        if(pid_in_list(ppids[i],pids,n))continue; /* still a child of a live family process */
        if(unique_find(pids[i],cts[i])>=0)continue; /* an already-known MAIN identity */
        if(known_helper_identity(pids[i],cts[i]))continue; /* leftover helper we sampled earlier */
        if(historical_main_pid(ppids[i]))continue; /* orphan whose parent was an old MAIN */
        if(unique_add(pids[i],cts[i],ppids[i]))added++;
    }
    HeapFree(GetProcessHeap(),0,pids);HeapFree(GetProcessHeap(),0,ppids);HeapFree(GetProcessHeap(),0,cts);
    return added;
}
static void reset_restart_metric_baselines(void){
    g_prevCpu100ns=0;g_prevCpuWallMs=0;g_prevSysIdle100ns=0;g_prevSysKernel100ns=0;g_prevSysUser100ns=0;
    g_autoSlowStreak=0;g_autoRecoveryStreak=0;g_autoEpisodeActive=FALSE;g_autoEpisodeSeverity=0;
}
static void build_active_pids(void){
    g_activePidCount=0;
    HANDLE s=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);if(s==INVALID_HANDLE_VALUE)return;
    PROCESSENTRY32W pe;memset(&pe,0,sizeof(pe));pe.dwSize=sizeof(pe);
    PROCESSENTRY32W* arr=(PROCESSENTRY32W*)HeapAlloc(GetProcessHeap(),0,sizeof(PROCESSENTRY32W)*4096);DWORD n=0;
    if(arr&&Process32FirstW(s,&pe)){do{if(n<4096)arr[n++]=pe;pe.dwSize=sizeof(pe);}while(Process32NextW(s,&pe));}
    CloseHandle(s);if(!arr)return;
    /* Re-activate only identities we have already observed and whose creation time still matches. This prevents PID reuse from attaching unrelated programs. */
    for(DWORD u=0;u<g_uniquePidCount;u++){
        PROCESSENTRY32W* q=find_pe(arr,n,g_uniquePids[u]);if(!q)continue;
        ULONGLONG ct=process_create_time(q->th32ProcessID);if(ct&&ct==g_uniqueCreateTimes[u])active_add(q->th32ProcessID,ct);
    }
    /* Very first scan: seed the launched root identity if it is still present. */
    if(g_rootPid&&active_find(g_rootPid)<0){PROCESSENTRY32W* q=find_pe(arr,n,g_rootPid);if(q){ULONGLONG ct=process_create_time(g_rootPid);if(ct&&(!g_rootCreateTime||ct==g_rootCreateTime)){if(!g_rootCreateTime)g_rootCreateTime=ct;unique_add(g_rootPid,ct,q->th32ParentProcessID);active_add(g_rootPid,ct);}}}
    /* Main-process-only mode: do NOT recursively attach renderer/GPU/utility/helper children.
       The main identity/identities above are enough for startup/window/hang diagnostics and keep
       the monitor lightweight even when a browser spawns many subprocesses. */
    HeapFree(GetProcessHeap(),0,arr);
}

static BOOL g_checkHungDuringEnum;
static BOOL g_captureWindowTextDuringEnum;
static BOOL CALLBACK enum_win_cb(HWND h,LPARAM l){
    (void)l;DWORD pid=0;GetWindowThreadProcessId(h,&pid);if(!pid_in_list(pid,g_activePids,g_activePidCount))return TRUE;if(g_windowCount>=MAX_WINDOWS)return TRUE;
    WININFO* w=&g_windows[g_windowCount++];memset(w,0,sizeof(*w));w->hwnd=h;w->pid=pid;w->visible=IsWindowVisible(h);w->minimized=IsIconic(h);w->maximized=IsZoomed(h);GetWindowRect(h,&w->rect);w->offscreen=MonitorFromRect(&w->rect,MONITOR_DEFAULTTONULL)==NULL;
    if(g_captureWindowTextDuringEnum){GetWindowTextW(h,w->title,512);GetClassNameW(h,w->cls,128);}else{w->title[0]=0;w->cls[0]=0;}
    if(g_checkHungDuringEnum){ULONG_PTR res=0;ULONGLONG t0=tick_now();SetLastError(0);LRESULT r=SendMessageTimeoutW(h,WM_NULL,0,0,SMTO_ABORTIFHUNG,AUTO_PROBE_TIMEOUT_MS,&res);ULONGLONG t1=tick_now();w->probeMs=(DWORD)(t1>=t0?t1-t0:0);w->hung=(r==0);if(w->hung&&w->probeMs<AUTO_PROBE_TIMEOUT_MS)w->probeMs=AUTO_PROBE_TIMEOUT_MS;}else{w->probeMs=0;w->hung=FALSE;}
    return TRUE;
}
static void collect_windows_ex(BOOL checkHung,BOOL captureText){g_windowCount=0;g_checkHungDuringEnum=checkHung;g_captureWindowTextDuringEnum=captureText;EnumWindows(enum_win_cb,0);g_checkHungDuringEnum=FALSE;g_captureWindowTextDuringEnum=FALSE;}
static void collect_windows(BOOL checkHung){collect_windows_ex(checkHung,checkHung);}

static DWORD query_thread_count_for_active(void){
    DWORD total=0;HANDLE s=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);if(s==INVALID_HANDLE_VALUE)return 0;
    PROCESSENTRY32W pe;memset(&pe,0,sizeof(pe));pe.dwSize=sizeof(pe);
    if(Process32FirstW(s,&pe)){do{if(pid_in_list(pe.th32ProcessID,g_activePids,g_activePidCount))total+=pe.cntThreads;pe.dwSize=sizeof(pe);}while(Process32NextW(s,&pe));}
    CloseHandle(s);return total;
}
static DWORD logical_cpu_count(void){SYSTEM_INFO si;memset(&si,0,sizeof(si));GetNativeSystemInfo(&si);return si.dwNumberOfProcessors?si.dwNumberOfProcessors:1;}
static void collect_perf_sample(BOOL marked,DWORD hungCount,DWORD probeMaxMs,BYTE autoSeverity){
    if(!g_activePidCount)return;
    ULONGLONG cpu100=0,ws=0,priv=0,readb=0,writeb=0;DWORD handles=0,pfaults=0;
    for(DWORD i=0;i<g_activePidCount;i++){
        HANDLE p=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION,FALSE,g_activePids[i]);if(!p)continue;
        FILETIME c,e,k,u;if(GetProcessTimes(p,&c,&e,&k,&u))cpu100+=ft64(k)+ft64(u);
        PROCESS_MEMORY_COUNTERS_EX pm;memset(&pm,0,sizeof(pm));pm.cb=sizeof(pm);if(GetProcessMemoryInfo(p,(PROCESS_MEMORY_COUNTERS*)&pm,sizeof(pm))){ws+=pm.WorkingSetSize;priv+=pm.PrivateUsage;pfaults+=pm.PageFaultCount;}
        DWORD hc=0;if(GetProcessHandleCount(p,&hc))handles+=hc;
        IO_COUNTERS io;memset(&io,0,sizeof(io));if(GetProcessIoCounters(p,&io)){readb+=io.ReadTransferCount;writeb+=io.WriteTransferCount;}
        CloseHandle(p);
    }
    ULONGLONG now=tick_now();DWORD cpuPm=0;if(g_prevCpuWallMs&&now>g_prevCpuWallMs&&cpu100>=g_prevCpu100ns){ULONGLONG dCpu=cpu100-g_prevCpu100ns;ULONGLONG dWall=(now-g_prevCpuWallMs)*10000ULL*(ULONGLONG)logical_cpu_count();if(dWall)cpuPm=(DWORD)((dCpu*1000ULL)/dWall);if(cpuPm>1000)cpuPm=1000;}
    g_prevCpu100ns=cpu100;g_prevCpuWallMs=now;
    DWORD threads=query_thread_count_for_active();DWORD visible=0;for(DWORD i=0;i<g_windowCount;i++)if(g_windows[i].visible)visible++;
    if(!g_perfCount){g_firstReadBytes=readb;g_firstWriteBytes=writeb;}g_lastReadBytes=readb;g_lastWriteBytes=writeb;
    if(cpuPm>g_peakCpuPermille)g_peakCpuPermille=cpuPm;if(g_perfCount>0){g_sumCpuPermille+=cpuPm;g_cpuSampleCount++;}
    if(priv>g_peakPrivateBytes)g_peakPrivateBytes=priv;if(threads>g_peakThreads)g_peakThreads=threads;if(handles>g_peakHandles)g_peakHandles=handles;if(pfaults>g_peakPageFaults)g_peakPageFaults=pfaults;

    DWORD sysCpu=sample_system_cpu(),memLoad=0,disk=sample_disk_percent(),gdi=0,user=0;ULONGLONG avail=0;sample_system_memory(&memLoad,&avail);sample_gui_resources(&gdi,&user);CHILDMETRICS cm;memset(&cm,0,sizeof(cm));static CHILDMETRICS cachedCm;if(!g_lastHelperRefresh||now-g_lastHelperRefresh>=5000){collect_child_metrics(now,&cachedCm);g_lastHelperRefresh=now;}cm=cachedCm;
    if(sysCpu>g_peakSystemCpuPermille)g_peakSystemCpuPermille=sysCpu;if(disk!=0xFFFFFFFFu){g_diskCounterEverValid=TRUE;if(disk>g_peakDiskPercent)g_peakDiskPercent=disk;}if(gdi>g_peakGdiObjects)g_peakGdiObjects=gdi;if(user>g_peakUserObjects)g_peakUserObjects=user;if(cm.cpuPermille>g_peakChildCpuPermille)g_peakChildCpuPermille=cm.cpuPermille;if(cm.workingSet>g_peakChildWorkingSet)g_peakChildWorkingSet=cm.workingSet;

    if(g_perfCount<MAX_PERF_SAMPLES){PERFSAMPLE* q=&g_perfSamples[g_perfCount++];memset(q,0,sizeof(*q));q->offsetMs=now-g_startTick;q->cpuPermille=cpuPm;q->workingSet=ws;q->privateBytes=priv;q->threads=threads;q->handles=handles;q->pageFaults=pfaults;q->readBytes=readb;q->writeBytes=writeb;q->windowCount=g_windowCount;q->visibleCount=visible;q->hungCount=hungCount;q->probeMaxMs=probeMaxMs;q->systemCpuPermille=sysCpu;q->systemMemoryLoad=memLoad;q->systemAvailPhys=avail;q->diskPercent=disk;q->gdiObjects=gdi;q->userObjects=user;q->childCount=cm.count;q->childCpuPermille=cm.cpuPermille;q->childWorkingSet=cm.workingSet;q->childPrivateBytes=cm.privateBytes;q->childReadDelta=cm.readDelta;q->childWriteDelta=cm.writeDelta;q->topChildPid=cm.topPid;q->topChildCpuPermille=cm.topCpuPermille;q->autoSeverity=autoSeverity;q->marked=marked;}else g_perfTruncated=TRUE;
}

static void performance_report(void){
    sep(L"FREEZE / LAG PERFORMANCE TRACE");
    if(!g_perfCount){line(L"No performance samples were captured (the target may not have appeared before monitoring stopped).");return;}
    WCHAR tmp[3072],wsb[64],prb[64],rdb[64],wrb[64],cwb[64];fmt_bytes(g_maxWorkingSet,wsb);fmt_bytes(g_peakPrivateBytes,prb);fmt_bytes(g_peakChildWorkingSet,cwb);
    ULONGLONG rd=(g_lastReadBytes>=g_firstReadBytes)?g_lastReadBytes-g_firstReadBytes:0;ULONGLONG wr=(g_lastWriteBytes>=g_firstWriteBytes)?g_lastWriteBytes-g_firstWriteBytes:0;fmt_bytes(rd,rdb);fmt_bytes(wr,wrb);
    DWORD avg=g_cpuSampleCount?(DWORD)(g_sumCpuPermille/g_cpuSampleCount):0;
    wsprintfW(tmp,L"Sampling: about once per second. MAIN process is deep-monitored; same-family helper subprocesses receive lightweight aggregate metrics only.\r\nSamples captured: %u%s\r\nAutomatic freeze/lag detections: %u (lag %u, freeze %u)\r\nAutomatic UI probe: %u ms timeout; lag candidate >= %u ms for %u consecutive samples\r\nMain peak CPU: %u.%u%%  Main average CPU: %u.%u%%\r\nMain peak working set: %s\r\nMain peak private committed memory: %s\r\nMain peak threads: %u  Peak handles: %u  Peak page faults counter: %u\r\nMain I/O transferred during trace: read %s, write %s\r\nHelper/subprocess peak aggregate CPU: %u.%u%%  peak working set: %s\r\nSystem peak CPU: %u.%u%%  peak main GDI objects: %u  peak main USER objects: %u\r\n",g_perfCount,g_perfTruncated?L" (trace sample buffer reached its 1-hour cap)":L"",g_autoEventCount,g_autoLagEventCount,g_autoFreezeEventCount,AUTO_PROBE_TIMEOUT_MS,AUTO_LAG_THRESHOLD_MS,AUTO_LAG_STREAK_REQUIRED,g_peakCpuPermille/10,g_peakCpuPermille%10,avg/10,avg%10,wsb,prb,g_peakThreads,g_peakHandles,g_peakPageFaults,rdb,wrb,g_peakChildCpuPermille/10,g_peakChildCpuPermille%10,cwb,g_peakSystemCpuPermille/10,g_peakSystemCpuPermille%10,g_peakGdiObjects,g_peakUserObjects);rep(tmp);if(g_diskCounterEverValid){wsprintfW(tmp,L"Peak PhysicalDisk(_Total) busy: %u%%\r\n",g_peakDiskPercent);rep(tmp);}else line(L"Peak PhysicalDisk(_Total) busy: n/a (PDH counter unavailable or no valid sample). ");
    line(L"The trace uses documented process/window query APIs, GetSystemTimes/GlobalMemoryStatusEx, optional PDH disk counters, GetGuiResources, and a bounded WM_NULL responsiveness probe. It does not inject, hook, debug, suspend, or modify the target.");
    line(L"Columns include main + helper CPU/memory, system CPU/RAM/disk, GDI/USER objects, I/O, window responsiveness, and event markers.");
    for(DWORD i=0;i<g_perfCount;i++){PERFSAMPLE* q=&g_perfSamples[i];WCHAR a[64],b[64],r[64],w[64],ca[64],av[64],cr[64],cw[64];fmt_bytes(q->workingSet,a);fmt_bytes(q->privateBytes,b);ULONGLONG qr=q->readBytes>=g_firstReadBytes?q->readBytes-g_firstReadBytes:0;ULONGLONG qw=q->writeBytes>=g_firstWriteBytes?q->writeBytes-g_firstWriteBytes:0;fmt_bytes(qr,r);fmt_bytes(qw,w);fmt_bytes(q->childWorkingSet,ca);fmt_bytes(q->systemAvailPhys,av);fmt_bytes(q->childReadDelta,cr);fmt_bytes(q->childWriteDelta,cw);LPCWSTR ev=L"";if(q->marked)ev=q->autoSeverity>=2?L"  *** AUTO FREEZE DETECTED ***":L"  *** AUTO LAG DETECTED ***";if(q->diskPercent==0xFFFFFFFFu)wsprintfW(tmp,L"+%I64u ms  MAIN CPU %u.%u%% WS %s Private %s th %u h %u PF %u IO R%s/W%s | HELPERS %u CPU %u.%u%% WS %s top PID %u %u.%u%% IOΔ R%s/W%s | SYSTEM CPU %u.%u%% RAM %u%% avail %s disk n/a | GDI %u USER %u | windows %u/%u visible probe %u ms hung %u%s\r\n",q->offsetMs,q->cpuPermille/10,q->cpuPermille%10,a,b,q->threads,q->handles,q->pageFaults,r,w,q->childCount,q->childCpuPermille/10,q->childCpuPermille%10,ca,q->topChildPid,q->topChildCpuPermille/10,q->topChildCpuPermille%10,cr,cw,q->systemCpuPermille/10,q->systemCpuPermille%10,q->systemMemoryLoad,av,q->gdiObjects,q->userObjects,q->windowCount,q->visibleCount,q->probeMaxMs,q->hungCount,ev);else wsprintfW(tmp,L"+%I64u ms  MAIN CPU %u.%u%% WS %s Private %s th %u h %u PF %u IO R%s/W%s | HELPERS %u CPU %u.%u%% WS %s top PID %u %u.%u%% IOΔ R%s/W%s | SYSTEM CPU %u.%u%% RAM %u%% avail %s disk %u%% | GDI %u USER %u | windows %u/%u visible probe %u ms hung %u%s\r\n",q->offsetMs,q->cpuPermille/10,q->cpuPermille%10,a,b,q->threads,q->handles,q->pageFaults,r,w,q->childCount,q->childCpuPermille/10,q->childCpuPermille%10,ca,q->topChildPid,q->topChildCpuPermille/10,q->topChildCpuPermille%10,cr,cw,q->systemCpuPermille/10,q->systemCpuPermille%10,q->systemMemoryLoad,av,q->diskPercent,q->gdiObjects,q->userObjects,q->windowCount,q->visibleCount,q->probeMaxMs,q->hungCount,ev);rep(tmp);}

    sep(L"FREEZE EPISODE SUMMARY");g_memoryGrowthFlags=0;DWORD episodes=0;
    for(DWORD i=0;i<g_perfCount;i++){PERFSAMPLE* q=&g_perfSamples[i];if(!(q->marked&&q->autoSeverity>=2))continue;episodes++;DWORD end=i;while(end+1<g_perfCount&&g_perfSamples[end+1].autoSeverity>=2)end++;DWORD pre0=i>5?i-5:0;DWORD preCount=i-pre0;ULONGLONG preCpu=0;for(DWORD x=pre0;x<i;x++)preCpu+=g_perfSamples[x].cpuPermille;DWORD preAvg=preCount?(DWORD)(preCpu/preCount):0;DWORD afterEnd=end+3<g_perfCount?end+3:g_perfCount-1;DWORD afterCount=afterEnd>end?afterEnd-end:0;ULONGLONG afterCpu=0;for(DWORD x=end+1;x<=afterEnd&&x<g_perfCount;x++)afterCpu+=g_perfSamples[x].cpuPermille;DWORD afterAvg=afterCount?(DWORD)(afterCpu/afterCount):0;ULONGLONG startPriv=q->privateBytes,endPriv=g_perfSamples[end].privateBytes,growth=endPriv>startPriv?endPriv-startPriv:0;DWORD peakMain=0,peakChild=0,peakSys=0,peakDisk=0,maxHung=0;BOOL diskValid=FALSE;for(DWORD x=i;x<=end;x++){PERFSAMPLE* z=&g_perfSamples[x];if(z->cpuPermille>peakMain)peakMain=z->cpuPermille;if(z->childCpuPermille>peakChild)peakChild=z->childCpuPermille;if(z->systemCpuPermille>peakSys)peakSys=z->systemCpuPermille;if(z->diskPercent!=0xFFFFFFFFu){diskValid=TRUE;if(z->diskPercent>peakDisk)peakDisk=z->diskPercent;}if(z->hungCount>maxHung)maxHung=z->hungCount;}BOOL memFlag=(growth>=64ULL*1024ULL*1024ULL&&startPriv&&endPriv*100ULL>=startPriv*110ULL);if(memFlag)g_memoryGrowthFlags++;WCHAR sp[64],ep[64],gr[64];fmt_bytes(startPriv,sp);fmt_bytes(endPriv,ep);fmt_bytes(growth,gr);ULONGLONG dur=g_perfSamples[end].offsetMs>=q->offsetMs?g_perfSamples[end].offsetMs-q->offsetMs:0;if(diskValid)wsprintfW(tmp,L"Freeze episode %u: start +%I64u ms, observed duration %I64u ms%s; pre-freeze main CPU avg %u.%u%%; during peak MAIN %u.%u%% / helpers %u.%u%% / system %u.%u%% / disk %u%%; max hung windows %u; private memory %s -> %s (growth %s)%s; post-recovery main CPU avg %u.%u%%\r\n",episodes,q->offsetMs,dur,(end==g_perfCount-1&&g_perfSamples[end].autoSeverity>=2)?L" (still active when trace ended)":L"",preAvg/10,preAvg%10,peakMain/10,peakMain%10,peakChild/10,peakChild%10,peakSys/10,peakSys%10,peakDisk,maxHung,sp,ep,gr,memFlag?L"  *** SUSTAINED MEMORY GROWTH FLAG ***":L"",afterAvg/10,afterAvg%10);else wsprintfW(tmp,L"Freeze episode %u: start +%I64u ms, observed duration %I64u ms%s; pre-freeze main CPU avg %u.%u%%; during peak MAIN %u.%u%% / helpers %u.%u%% / system %u.%u%% / disk n/a; max hung windows %u; private memory %s -> %s (growth %s)%s; post-recovery main CPU avg %u.%u%%\r\n",episodes,q->offsetMs,dur,(end==g_perfCount-1&&g_perfSamples[end].autoSeverity>=2)?L" (still active when trace ended)":L"",preAvg/10,preAvg%10,peakMain/10,peakMain%10,peakChild/10,peakChild%10,peakSys/10,peakSys%10,maxHung,sp,ep,gr,memFlag?L"  *** SUSTAINED MEMORY GROWTH FLAG ***":L"",afterAvg/10,afterAvg%10);rep(tmp);i=end;}
    if(!episodes)line(L"No automatic freeze episode reached the 150 ms timeout threshold during this run.");
}
static void freeze_details_report(void){sep(L"AUTO FREEZE DEEP SNAPSHOTS");if(g_freezeDetails&&g_freezeDetailsLen)rep(g_freezeDetails);else line(L"No deep freeze snapshot was captured because no automatic freeze started during this run.");if(g_wctCycleCount){WCHAR t[256];wsprintfW(t,L"Wait Chain Traversal reported %u cycle(s); this is a strong deadlock/wait-cycle clue, but it still requires correlation with the affected thread/process.",g_wctCycleCount);line(t);}}

static ULONGLONG process_working_set(DWORD pid){HANDLE p=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION,FALSE,pid);if(!p)return 0;PROCESS_MEMORY_COUNTERS pm;memset(&pm,0,sizeof(pm));pm.cb=sizeof(pm);ULONGLONG v=0;if(GetProcessMemoryInfo(p,&pm,sizeof(pm)))v=pm.WorkingSetSize;CloseHandle(p);return v;}
static ULONGLONG current_working_set_exact(void){ULONGLONG sum=0;for(DWORD i=0;i<g_activePidCount;i++)sum+=process_working_set(g_activePids[i]);return sum;}

static INT monitor_sample_worker(void){
    if(g_shutdownRequested)return -1;
    build_active_pids();
    if(g_activePidCount>g_maxProcessCount)g_maxProcessCount=g_activePidCount;
    ULONGLONG sum=0;DWORD lim=g_activePidCount;
    if(lim>LIVE_MEMORY_SAMPLE_LIMIT){lim=LIVE_MEMORY_SAMPLE_LIMIT;g_memorySamplingUsed=TRUE;}
    for(DWORD i=0;i<lim;i++){if(g_shutdownRequested)return -1;sum+=process_working_set(g_activePids[i]);}
    if(sum>g_maxWorkingSet)g_maxWorkingSet=sum;
    /* Automatic responsiveness sampling: no user click is needed. Text/title capture is skipped here to keep the once-per-second probe lightweight. */
    collect_windows_ex(TRUE,FALSE);
    BOOL marked=FALSE;DWORD markedHung=0,maxProbeMs=0;BYTE eventSeverity=0;
    for(DWORD i=0;i<g_windowCount;i++){if(g_windows[i].hung)markedHung++;if(g_windows[i].probeMs>maxProbeMs)maxProbeMs=g_windows[i].probeMs;}
    if(markedHung){
        g_autoSlowStreak=0;g_autoRecoveryStreak=0;
        if(!g_autoEpisodeActive||g_autoEpisodeSeverity<2){g_autoEpisodeActive=TRUE;g_autoEpisodeSeverity=2;g_autoEventCount++;g_autoFreezeEventCount++;marked=TRUE;eventSeverity=2;WCHAR mt[512];wsprintfW(mt,L"AUTO FREEZE #%u: %u main top-level window(s), %u did not answer the %u ms WM_NULL probe (max probe %u ms)",g_autoFreezeEventCount,g_windowCount,markedHung,AUTO_PROBE_TIMEOUT_MS,maxProbeMs);timeline(mt);log_event(L"WARN",L"Automatic freeze detected on selected target MAIN UI; privacy-safe freeze snapshot initiated");post_status(L"Automatic freeze detected — tracing continues; no click needed.");}
    }else if(maxProbeMs>=AUTO_LAG_THRESHOLD_MS){
        g_autoSlowStreak++;g_autoRecoveryStreak=0;
        if(g_autoSlowStreak>=AUTO_LAG_STREAK_REQUIRED&&!g_autoEpisodeActive){g_autoEpisodeActive=TRUE;g_autoEpisodeSeverity=1;g_autoEventCount++;g_autoLagEventCount++;marked=TRUE;eventSeverity=1;WCHAR mt[512];wsprintfW(mt,L"AUTO LAG #%u: UI responsiveness probe stayed at/above %u ms for %u consecutive samples (current max %u ms)",g_autoLagEventCount,AUTO_LAG_THRESHOLD_MS,g_autoSlowStreak,maxProbeMs);timeline(mt);log_event(L"WARN",L"Automatic lag detected on selected target MAIN UI");post_status(L"Automatic lag detected — tracing continues; no click needed.");}
    }else{
        g_autoSlowStreak=0;
        if(g_autoEpisodeActive){g_autoRecoveryStreak++;if(g_autoRecoveryStreak>=AUTO_RECOVERY_STREAK_REQUIRED){WCHAR mt[320];wsprintfW(mt,L"Automatic responsiveness recovery: %u consecutive normal samples after %s episode",g_autoRecoveryStreak,g_autoEpisodeSeverity>=2?L"freeze":L"lag");timeline(mt);log_event(L"INFO",L"Selected target MAIN UI responsiveness recovered after automatic lag/freeze episode");g_autoEpisodeActive=FALSE;g_autoEpisodeSeverity=0;g_autoRecoveryStreak=0;}}
    }
    if(!eventSeverity&&g_autoEpisodeActive)eventSeverity=g_autoEpisodeSeverity;
    collect_perf_sample(marked,markedHung,maxProbeMs,eventSeverity);
    if(marked&&eventSeverity>=2)capture_freeze_deep_snapshot(g_autoFreezeEventCount);
    BOOL vis=FALSE,hid=FALSE;
    for(DWORD i=0;i<g_windowCount;i++){if(g_windows[i].visible)vis=TRUE;else hid=TRUE;}
    if(vis&&!g_everVisibleWindow){g_everVisibleWindow=TRUE;g_firstVisibleMs=(DWORD)(tick_now()-g_startTick);WCHAR t[256];wsprintfW(t,L"First visible window appeared after %u ms",g_firstVisibleMs);timeline(t);}
    if(hid)g_everHiddenWindow=TRUE;
    if(g_rootHandle&&!g_rootExited){DWORD ec=STILL_ACTIVE;if(GetExitCodeProcess(g_rootHandle,&ec)&&ec!=STILL_ACTIVE){g_rootExited=TRUE;g_rootExitCode=ec;WCHAR t[256];wsprintfW(t,L"Root process exited with code %u (0x%08X)",ec,ec);timeline(t);}}
    ULONGLONG now=tick_now();
    if(g_activePidCount==0&&g_uniquePidCount>0){
        if(!g_zeroActiveSinceTick){
            g_zeroActiveSinceTick=now;g_restartWaitEpisodes++;
            if(g_autoEpisodeActive){timeline(L"Active lag/freeze episode ended because the verified MAIN process exited.");g_autoEpisodeActive=FALSE;g_autoEpisodeSeverity=0;g_autoSlowStreak=0;g_autoRecoveryStreak=0;}
            timeline(L"No active verified MAIN target processes remain; entering the 30-second restart watch instead of analyzing immediately.");
        }
        DWORD newRoots=discover_restart_main_roots();
        if(newRoots){
            build_active_pids();
            if(g_activePidCount){
                g_restartCount++;g_zeroActiveSinceTick=0;reset_restart_metric_baselines();
                WCHAR rt[384];wsprintfW(rt,L"Target restart detected: %u new MAIN root identity/identities; continuing the SAME diagnostic run (restart #%u).",newRoots,g_restartCount);timeline(rt);log_event(L"INFO",L"Selected target restart detected; continuing same diagnostic run");
                post_status(L"Target restarted — continuing the same diagnostic automatically. Freeze/lag detection is ON.");
                return 0;
            }
        }
        ULONGLONG elapsed=now-g_zeroActiveSinceTick;
        if(elapsed>=RESTART_WAIT_MS){g_targetExitAutoDetected=TRUE;timeline(L"No genuine target restart appeared during the 30-second restart watch; monitoring stopped automatically for analysis.");log_event(L"INFO",L"Target exit restart-watch elapsed; monitoring ended automatically for analysis");post_status(L"Target stayed exited for 30 seconds — analyzing automatically in the background...");return 1;}
        DWORD left=(DWORD)((RESTART_WAIT_MS>elapsed?RESTART_WAIT_MS-elapsed:0)+999)/1000;WCHAR st0[384];wsprintfW(st0,L"Target exited — waiting up to %u more second(s) for an automatic/manual restart. You can reopen it now or click Stop & Analyze.",left);post_status(st0);return 0;
    }
    g_zeroActiveSinceTick=0;
    WCHAR st[320];
    if(g_processStorm)wsprintfW(st,L"Monitoring — AUTO detection ON — %u MAIN process(es) [safety], %u window(s), UI probe %u ms, detections %u%s",g_activePidCount,g_windowCount,maxProbeMs,g_autoEventCount,g_autoEpisodeActive?(g_autoEpisodeSeverity>=2?L" — FREEZE ACTIVE":L" — LAG ACTIVE"):L"");
    else wsprintfW(st,L"Monitoring — AUTO detection ON — %u MAIN process(es), %u window(s), UI probe %u ms, detections %u%s",g_activePidCount,g_windowCount,maxProbeMs,g_autoEventCount,g_autoEpisodeActive?(g_autoEpisodeSeverity>=2?L" — FREEZE ACTIVE":L" — LAG ACTIVE"):L"");
    post_status(st);return 0;
}

static void process_report(void){
    sep(L"MAIN PROCESS DETAILS");build_active_pids();
    WCHAR tmp[2048],path[MAX_WPATH],mems[64];HANDLE snap=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);
    PROCESSENTRY32W pe;memset(&pe,0,sizeof(pe));pe.dwSize=sizeof(pe);DWORD shown=0,currentMatched=0;
    if(snap!=INVALID_HANDLE_VALUE&&Process32FirstW(snap,&pe)){do{
        INT ai=active_find(pe.th32ProcessID);if(ai>=0){ULONGLONG ct=process_create_time(pe.th32ProcessID);if(ct&&ct==g_activeCreateTimes[ai]){
            currentMatched++;if(shown<PROCESS_DETAIL_LIMIT){
                HANDLE ph=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION,FALSE,pe.th32ProcessID);DWORD plen=MAX_WPATH;path[0]=0;
                ULONGLONG ws=0;DWORD handles=0,prio=0;BOOL wow=FALSE;ULONGLONG kernMs=0,userMs=0;WCHAR created[64]=L"unavailable";
                if(ph){QueryFullProcessImageNameW(ph,0,path,&plen);PROCESS_MEMORY_COUNTERS pm;memset(&pm,0,sizeof(pm));pm.cb=sizeof(pm);if(GetProcessMemoryInfo(ph,&pm,sizeof(pm)))ws=pm.WorkingSetSize;GetProcessHandleCount(ph,&handles);prio=GetPriorityClass(ph);IsWow64Process(ph,&wow);FILETIME cft,eft,kft,uft;if(GetProcessTimes(ph,&cft,&eft,&kft,&uft)){kernMs=ft64(kft)/10000ULL;userMs=ft64(uft)/10000ULL;fmt_filetime(cft,created);}}
                fmt_bytes(ws,mems);wsprintfW(tmp,L"PID %u  PPID %u  threads=%u  handles=%u  memory=%s\r\n  identity creation=0x%I64X\r\n  exe=%s\r\n  path=%s\r\n  created=%s  CPU kernel=%I64u ms user=%I64u ms\r\n  priority=0x%08X  WOW64=%s\r\n  security token: intentionally not queried in Build 19 isolated AV-safe mode\r\n",pe.th32ProcessID,pe.th32ParentProcessID,pe.cntThreads,handles,mems,ct,pe.szExeFile,path[0]?path:L"(unavailable)",created,kernMs,userMs,prio,wow?L"yes":L"no");rep(tmp);if(ph)CloseHandle(ph);shown++;
            }
        }}pe.dwSize=sizeof(pe);
    }while(Process32NextW(snap,&pe));CloseHandle(snap);}
    if(currentMatched>PROCESS_DETAIL_LIMIT){wsprintfW(tmp,L"Main-process detail truncated after %u identities to keep analysis responsive; main-process totals remain complete.\r\n",PROCESS_DETAIL_LIMIT);rep(tmp);}
    DWORD exited=g_uniquePidCount>currentMatched?g_uniquePidCount-currentMatched:0;wsprintfW(tmp,L"Observed unique process identities: %u\r\nCurrently active verified identities: %u\r\nHistorical/exited identities: %u\r\nMaximum simultaneous verified processes: %u\r\n",g_uniquePidCount,currentMatched,exited,g_maxProcessCount);rep(tmp);
    if(g_trackingTruncated)line(L"WARNING: main-process identity tracking reached its safety capacity.");if(g_processStorm)line(L"PROCESS STORM: unusually high main-process count detected; expensive live probes were throttled automatically.");
    ULONGLONG exact=current_working_set_exact();if(exact>g_maxWorkingSet)g_maxWorkingSet=exact;fmt_bytes(g_maxWorkingSet,mems);wsprintfW(tmp,L"Maximum/snapshot combined working set observed: %s%s\r\n",mems,g_memorySamplingUsed?L" (live peak sampling was throttled during high process counts)":L"");rep(tmp);if(g_rootExited){wsprintfW(tmp,L"Root exit code: %u (0x%08X)\r\n",g_rootExitCode,g_rootExitCode);rep(tmp);}else line(L"Root process exit: not observed during diagnostic");
}

static void windows_report(void){sep(L"WINDOWS / UI STATE");collect_windows(TRUE);WCHAR tmp[2048];DWORD vis=0,hid=0,hung=0,off=0;for(DWORD i=0;i<g_windowCount;i++){WININFO* w=&g_windows[i];if(w->visible)vis++;else hid++;if(w->hung)hung++;if(w->offscreen)off++;wsprintfW(tmp,L"HWND 0x%I64X  PID %u  %s%s%s%s\r\n  title: %s\r\n  class: %s\r\n  rect: L%d T%d R%d B%d (%dx%d)\r\n",(ULONGLONG)(ULONG_PTR)w->hwnd,w->pid,w->visible?L"VISIBLE":L"HIDDEN",w->minimized?L", minimized":L"",w->maximized?L", maximized":L"",w->hung?L", NOT RESPONDING":L"",w->title[0]?w->title:L"(no title)",w->cls,w->rect.left,w->rect.top,w->rect.right,w->rect.bottom,w->rect.right-w->rect.left,w->rect.bottom-w->rect.top);rep(tmp);if(w->offscreen)line(L"  WARNING: window rectangle does not intersect any current monitor.");}wsprintfW(tmp,L"Current top-level windows: %u (visible %u, hidden %u, hung %u, off-screen %u)\r\n",g_windowCount,vis,hid,hung,off);rep(tmp);wsprintfW(tmp,L"Visible window ever observed: %s\r\nHidden window ever observed: %s\r\n",g_everVisibleWindow?L"yes":L"no",g_everHiddenWindow?L"yes":L"no");rep(tmp);if(g_everVisibleWindow){wsprintfW(tmp,L"Time to first visible window: %u ms\r\n",g_firstVisibleMs);rep(tmp);} }




static void crashdump_report(void){sep(L"CRASH DUMPS");WCHAR base[MAX_WPATH],pat[MAX_WPATH],tmp[2048];DWORD n=0;DWORD len=GetEnvironmentVariableW(L"LOCALAPPDATA",base,MAX_WPATH);if(!len||len>=MAX_WPATH){line(L"LOCALAPPDATA unavailable.");return;}wcat(base,L"\\CrashDumps",MAX_WPATH);wcopy(pat,base,MAX_WPATH);wcat(pat,L"\\*",MAX_WPATH);WIN32_FIND_DATAW fd;HANDLE h=FindFirstFileW(pat,&fd);LPCWSTR exe=basenamew(g_program);if(h!=INVALID_HANDLE_VALUE){do{if(!(fd.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY)&&wcontainsi(fd.cFileName,exe)){WCHAR tm[64];fmt_filetime(fd.ftLastWriteTime,tm);ULONGLONG sz=((ULONGLONG)fd.nFileSizeHigh<<32)|fd.nFileSizeLow;WCHAR bs[64];fmt_bytes(sz,bs);wsprintfW(tmp,L"%s\\%s  (%s, %s)\r\n",base,fd.cFileName,bs,tm);rep(tmp);n++;}}while(FindNextFileW(h,&fd));FindClose(h);}if(!n)line(L"No matching dumps found in %LOCALAPPDATA%\\CrashDumps.");}

static void registry_report(void){sep(L"RELEVANT REGISTRY / COMPATIBILITY SETTINGS");WCHAR tmp[2048],data[2048];HKEY k;DWORD type,sz;BOOL any=FALSE;if(RegOpenKeyExW(HKEY_CURRENT_USER,L"Software\\Microsoft\\Windows NT\\CurrentVersion\\AppCompatFlags\\Layers",0,KEY_READ,&k)==ERROR_SUCCESS){sz=sizeof(data);if(RegQueryValueExW(k,g_program,NULL,&type,(BYTE*)data,&sz)==ERROR_SUCCESS){wsprintfW(tmp,L"AppCompat layer for selected executable: %s\r\n",data);rep(tmp);any=TRUE;}RegCloseKey(k);}WCHAR key[MAX_WPATH];wsprintfW(key,L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Image File Execution Options\\%s",basenamew(g_program));if(RegOpenKeyExW(HKEY_LOCAL_MACHINE,key,0,KEY_READ,&k)==ERROR_SUCCESS){line(L"Image File Execution Options entry exists for this executable:");DWORD idx=0;for(;;){WCHAR name[256];DWORD nc=256;BYTE val[1024];DWORD vc=sizeof(val),t=0;LONG r=RegEnumValueW(k,idx++,name,&nc,NULL,&t,val,&vc);if(r!=ERROR_SUCCESS)break;if(t==REG_SZ||t==REG_EXPAND_SZ){wsprintfW(tmp,L"  %s = %s\r\n",name,(WCHAR*)val);rep(tmp);}else{wsprintfW(tmp,L"  %s (type %u, %u bytes)\r\n",name,t,vc);rep(tmp);} }RegCloseKey(k);any=TRUE;}if(!any)line(L"No AppCompat layer or Image File Execution Options override was found for the selected executable.");line(L"This section checks known compatibility/debug override locations only; it does not hook or intercept the target's registry calls.");}

__declspec(dllimport) DWORD WINAPI GetEnvironmentVariableW(LPCWSTR,LPWSTR,DWORD);


static void timeline_report(void){sep(L"TIMELINE");rep(g_timeline);}
static void limitations_report(void){sep(L"SAFETY / SCOPE NOTES");line(L"Build 19 isolated AV-safe design: no code/DLL injection, API hooks, debugger attach, ETW/kernel trace, driver, thread suspension, target termination, service, scheduled task, or target launch.");line(L"No telemetry, updater, account, advertising, or network communication is built into this app.");line(L"Passive watch is mandatory: the monitor waits for or attaches to the program you open normally and never launches a duplicate copy.");line(L"MAIN process monitoring uses PROCESS_QUERY_LIMITED_INFORMATION only. Same-family helper subprocesses are refreshed about every 5 seconds for lightweight CPU/memory/I/O correlation and are excluded from deep scans.");line(L"Automatic freeze/lag detection uses one bounded 150 ms WM_NULL responsiveness probe per sample. At freeze onset, WCT is limited to hung MAIN UI thread IDs; there is no broad thread snapshot and no OpenThread.");line(L"Cross-process module enumeration, broad Application event-log scanning, system-wide network-owner-table enumeration, target security-token inspection, and recursive watched-folder scanning are intentionally disabled.");line(L"Crash Monitor and RitschyMirror are explicit protected peers: unless one is the selected target, they are not opened, queried, messaged, launched, modified, or folder-scanned by this diagnostic run.");line(L"Program Diagnostic Monitor uses a dedicated ProgramDiagnosticMonitor-Isolated install/data/log/temp/diagnostics namespace and no shared helper or IPC channel with peer apps.");line(L"Some protected/elevated targets may expose less memory/process/window detail; this is reported rather than escalating privileges.");line(L"This custom executable is unsigned, so SmartScreen or antivirus reputation warnings remain possible.");}


static void summary_report(void){
    WCHAR tmp[2300],mem[64];sep(L"SUMMARY");DWORD vis=0,hid=0,hung=0,off=0;
    for(DWORD i=0;i<g_windowCount;i++){if(g_windows[i].visible)vis++;else hid++;if(g_windows[i].hung)hung++;if(g_windows[i].offscreen)off++;}
    fmt_bytes(g_maxWorkingSet,mem);ULONGLONG runMs=tick_now()-g_startTick;
    wsprintfW(tmp,L"Program: %s\r\nArguments: %s\r\nStart mode: %s\r\nMatching processes present at attach: %u\r\nAttached MAIN seed processes: %u\r\nHelper subprocesses excluded from deep scan at attach: %u (lightweight helper trace remains enabled)\r\nRoot/representative PID: %u\r\nDiagnostic duration: %I64u ms\r\nObserved unique MAIN process identities: %u\r\nTarget restarts detected in same run: %u\r\nRestart-watch episodes: %u (30 seconds each)\r\nMax simultaneous verified MAIN processes: %u\r\nMax/snapshot combined MAIN working set: %s\r\nVisible window ever created: %s\r\nCurrent visible/hidden windows: %u / %u\r\nCurrent hung/off-screen windows: %u / %u\r\nCrash/error events around run: %u\r\nHang events around run: %u\r\nNetwork endpoints at analysis: %u\r\nLoaded module entries scanned: %u\r\nWatched-folder changes: %u\r\n",g_program,g_args[0]?g_args:L"(none)",L"PASSIVE AV-SAFE WATCH — waited for/attached to MAIN process; target was never launched by monitor",g_attachMatchedCount,g_attachSeedCount,(g_attachMatchedCount>g_attachSeedCount)?(g_attachMatchedCount-g_attachSeedCount):0,g_rootPid,runMs,g_uniquePidCount,g_restartCount,g_restartWaitEpisodes,g_maxProcessCount,mem,g_everVisibleWindow?L"YES":L"NO",vis,hid,hung,off,g_lastCrashEvents,g_lastHangEvents,g_lastNetworkCount,g_lastModuleCount,g_lastFolderChanges);rep(tmp);
    if(g_args[0])line(L"NOTE: command-line Arguments are not applied in passive watch mode because the monitor never launches the target.");
    if(g_waitedForTarget&&g_targetDetectedTick){WCHAR wt[256];wsprintfW(wt,L"Target was detected %I64u ms after passive watching started.\r\n",g_targetDetectedTick-g_startTick);rep(wt);}
    if(g_perfCount){WCHAR pt[768],pb[64],cb[64];fmt_bytes(g_peakPrivateBytes,pb);fmt_bytes(g_peakChildWorkingSet,cb);DWORD avg=g_cpuSampleCount?(DWORD)(g_sumCpuPermille/g_cpuSampleCount):0;if(g_diskCounterEverValid)wsprintfW(pt,L"Freeze/Lag trace: %u sample(s), %u automatic detection(s) (lag %u, freeze %u), MAIN peak CPU %u.%u%% / average %u.%u%%, peak private %s; helper peak CPU %u.%u%% / WS %s; system peak CPU %u.%u%% / disk %u%%; WCT cycles %u; memory-growth flags %u\r\n",g_perfCount,g_autoEventCount,g_autoLagEventCount,g_autoFreezeEventCount,g_peakCpuPermille/10,g_peakCpuPermille%10,avg/10,avg%10,pb,g_peakChildCpuPermille/10,g_peakChildCpuPermille%10,cb,g_peakSystemCpuPermille/10,g_peakSystemCpuPermille%10,g_peakDiskPercent,g_wctCycleCount,g_memoryGrowthFlags);else wsprintfW(pt,L"Freeze/Lag trace: %u sample(s), %u automatic detection(s) (lag %u, freeze %u), MAIN peak CPU %u.%u%% / average %u.%u%%, peak private %s; helper peak CPU %u.%u%% / WS %s; system peak CPU %u.%u%% / disk n/a; WCT cycles %u; memory-growth flags %u\r\n",g_perfCount,g_autoEventCount,g_autoLagEventCount,g_autoFreezeEventCount,g_peakCpuPermille/10,g_peakCpuPermille%10,avg/10,avg%10,pb,g_peakChildCpuPermille/10,g_peakChildCpuPermille%10,cb,g_peakSystemCpuPermille/10,g_peakSystemCpuPermille%10,g_wctCycleCount,g_memoryGrowthFlags);rep(pt);}
    if(!g_everVisibleWindow&&g_maxProcessCount>0)line(L"DIAGNOSTIC FLAG: process(es) ran but no visible top-level window was observed.");
    if(hung)line(L"DIAGNOSTIC FLAG: at least one monitored window is not responding.");if(g_wctCycleCount)line(L"DIAGNOSTIC FLAG: Wait Chain Traversal found at least one wait cycle/deadlock clue during an automatic freeze.");if(g_memoryGrowthFlags)line(L"DIAGNOSTIC FLAG: private memory grew substantially during at least one sustained freeze episode.");if(off)line(L"DIAGNOSTIC FLAG: at least one monitored window is positioned off all current monitors.");if(g_lastCrashEvents)line(L"DIAGNOSTIC FLAG: Windows logged a matching application error / WER event around this run.");if(g_processStorm)line(L"DIAGNOSTIC FLAG: PROCESS STORM detected; expensive probes were throttled to keep the monitor responsive.");if(g_trackingTruncated)line(L"DIAGNOSTIC FLAG: process identity tracking reached its safety capacity.");if(g_memorySamplingUsed)line(L"NOTE: live working-set probes were sampled during high process counts; final current snapshot was measured across verified active processes.");if(g_targetExitAutoDetected)line(L"NOTE: monitoring ended automatically only after the target stayed exited for the full 30-second restart watch with no genuine new MAIN process detected.");
    if(g_baseline.valid){sep(L"COMPARISON TO BASELINE");wsprintfW(tmp,L"Max processes: baseline %u -> current %u\r\nVisible window: baseline %s -> current %s\r\nMax working set bytes: baseline %I64u -> current %I64u\r\nCrash events: baseline %u -> current %u\r\nHang events: baseline %u -> current %u\r\nNetwork endpoints: baseline %u -> current %u\r\nModule entries: baseline %u -> current %u\r\nFolder changes: baseline %u -> current %u\r\n",g_baseline.maxProcessCount,g_maxProcessCount,g_baseline.visible?L"yes":L"no",g_everVisibleWindow?L"yes":L"no",g_baseline.maxWorkingSet,g_maxWorkingSet,g_baseline.crashEvents,g_lastCrashEvents,g_baseline.hangEvents,g_lastHangEvents,g_baseline.networkCount,g_lastNetworkCount,g_baseline.moduleCount,g_lastModuleCount,g_baseline.folderChanges,g_lastFolderChanges);rep(tmp);}
}

static void generate_full_report_core(void){post_status(L"Analyzing in the background... this can take a few seconds.");g_reportLen=0;g_report[0]=0;SYSTEMTIME st;GetLocalTime(&st);WCHAR tmp[2048];wsprintfW(tmp,L"Program Diagnostic Monitor %s Build %u\r\nGenerated: %04u-%02u-%02u %02u:%02u:%02u local time\r\n",APP_VERSION,APP_BUILD,st.wYear,st.wMonth,st.wDay,st.wHour,st.wMinute,st.wSecond);rep(tmp);line(L"Isolated, passive, read-only Windows freeze/lag diagnostic report.");build_active_pids();collect_windows(FALSE);g_lastCrashEvents=0;g_lastHangEvents=0;g_lastNetworkCount=0;g_lastModuleCount=0;g_lastFolderChanges=0;executable_info();system_info();process_report();performance_report();freeze_details_report();windows_report();sep(L"LOADED MODULES");line(L"Cross-process module enumeration is intentionally disabled in Build 19 isolated AV-safe mode.");sep(L"NETWORK ENDPOINTS");line(L"System-wide TCP/UDP owner-table enumeration is intentionally disabled in Build 19 isolated AV-safe mode.");crashdump_report();registry_report();sep(L"WATCHED FOLDER — BEFORE / AFTER CHANGES");line(L"Optional recursive watched-folder scanning is disabled in Build 19 isolated mode.");timeline_report();limitations_report();WCHAR* body=(WCHAR*)HeapAlloc(GetProcessHeap(),0,(g_reportLen+1)*sizeof(WCHAR));if(body){DWORD bl=g_reportLen;memcpy(body,g_report,(bl+1)*sizeof(WCHAR));g_reportLen=0;g_report[0]=0;wsprintfW(tmp,L"Program Diagnostic Monitor %s Build %u\r\n",APP_VERSION,APP_BUILD);rep(tmp);summary_report();rep(body);HeapFree(GetProcessHeap(),0,body);}}

static void reset_monitor_state(void){disk_counter_close();g_stopRequested=0;g_uniquePidCount=0;g_activePidCount=0;g_maxProcessCount=0;g_maxWorkingSet=0;g_rootCreateTime=0;g_attachedExisting=FALSE;g_attachSeedCount=0;g_attachMatchedCount=0;g_trackingTruncated=FALSE;g_processStorm=FALSE;g_memorySamplingUsed=FALSE;g_timelineProcessSuppressed=FALSE;g_zeroActiveSinceTick=0;g_targetExitAutoDetected=FALSE;g_restartCount=0;g_restartWaitEpisodes=0;g_everVisibleWindow=FALSE;g_everHiddenWindow=FALSE;g_firstVisibleMs=0;g_rootExited=FALSE;g_rootExitCode=STILL_ACTIVE;g_windowCount=0;g_timelineLen=0;g_perfCount=0;g_perfTruncated=FALSE;g_prevCpu100ns=0;g_prevCpuWallMs=0;g_peakCpuPermille=0;g_sumCpuPermille=0;g_cpuSampleCount=0;g_peakPrivateBytes=0;g_peakThreads=0;g_peakHandles=0;g_peakPageFaults=0;g_firstReadBytes=0;g_firstWriteBytes=0;g_lastReadBytes=0;g_lastWriteBytes=0;g_autoEventCount=0;g_autoLagEventCount=0;g_autoFreezeEventCount=0;g_autoSlowStreak=0;g_autoRecoveryStreak=0;g_autoEpisodeActive=FALSE;g_autoEpisodeSeverity=0;g_waitedForTarget=FALSE;g_targetDetectedTick=0;g_freezeDetailsLen=0;if(g_freezeDetails)g_freezeDetails[0]=0;g_wctCycleCount=0;g_memoryGrowthFlags=0;g_peakChildCpuPermille=0;g_peakChildWorkingSet=0;g_peakSystemCpuPermille=0;g_peakDiskPercent=0;g_diskCounterEverValid=FALSE;g_peakGdiObjects=0;g_peakUserObjects=0;g_prevSysIdle100ns=0;g_prevSysKernel100ns=0;g_prevSysUser100ns=0;g_childStateCount=0;g_lastHelperRefresh=0;memset(g_childStates,0,sizeof(g_childStates));if(g_timeline)g_timeline[0]=0;if(g_rootHandle){CloseHandle(g_rootHandle);g_rootHandle=NULL;}g_rootPid=0;}

static DWORD WINAPI diagnostic_worker(LPVOID unused){
    (void)unused;log_debug(L"Diagnostic worker thread entered");
    post_status(L"Taking optional before snapshot in the background...");
    
    if(g_shutdownRequested){g_monitoring=FALSE;return 0;}
    g_startTick=tick_now();g_startUnix=unix_now();

        g_attachedExisting=TRUE;
        post_status(L"Passive AV-safe watch active — open the program normally when ready...");
        timeline(L"Passive watch started. The monitor will not launch, terminate, inject into, or modify the target.");
        DWORD found=seed_existing_program_family();
        if(!found){g_waitedForTarget=TRUE;while(!found&&!g_shutdownRequested&&!g_stopRequested){if(g_paused){Sleep(200);continue;}for(INT i=0;i<10&&!g_shutdownRequested&&!g_stopRequested;i++)Sleep(50);if(g_shutdownRequested||g_stopRequested)break;if(g_paused)continue;found=seed_existing_program_family();}}
        if(found){g_targetDetectedTick=tick_now();g_attachSeedCount=found;disk_counter_init();log_event(L"INFO",L"Selected target detected; passive monitoring and sampling active");log_debug(L"Target detected; sampling initialized");WCHAR tl[768];DWORD ignored=(g_attachMatchedCount>found)?(g_attachMatchedCount-found):0;wsprintfW(tl,L"Target detected: %u matching process(es); attached to %u MAIN process(es); %u helper subprocess(es) excluded from deep scanning but included in lightweight metrics. Monitor launched nothing.",g_attachMatchedCount,found,ignored);timeline(tl);if(g_args[0])timeline(L"Arguments were ignored because passive watch never relaunches the program.");post_status(L"Target detected — automatic freeze/lag + helper/system diagnostics are ON. No clicking is needed; just reproduce the problem.");}
        else if(g_stopRequested&&!g_shutdownRequested){timeline(L"Passive watch stopped by user before a matching target process appeared.");}


    BOOL autoAnalyze=FALSE;
    while(!g_shutdownRequested&&!g_stopRequested){
        if(g_paused){Sleep(200);continue;}
        INT r=monitor_sample_worker();
        if(r<0){g_monitoring=FALSE;post_worker_error(L"A Windows query failed while sampling the selected target. No target process was modified. You can review Logs/Diagnostics and try again.");return 0;}
        if(r>0){autoAnalyze=TRUE;break;}
        for(INT i=0;i<20&&!g_shutdownRequested&&!g_stopRequested;i++)Sleep(50);
    }
    if(g_shutdownRequested){g_monitoring=FALSE;return 0;}
    if(g_stopRequested&&!autoAnalyze){timeline(L"Monitoring stopped by user; target process was not terminated.");post_status(L"Stop requested — analyzing in the background...");}
    g_monitoring=FALSE;
    generate_full_report_core();
    if(g_shutdownRequested)return 0;
    PostMessageW(g_hwnd,WM_PDM_ANALYSIS_COMPLETE,autoAnalyze?1:0,0);
    return 0;
}

static void start_diagnostic(void){
    if(g_workerHandle||g_monitoring)return;if(g_paused){MessageBoxW(g_hwnd,L"Monitoring is paused. Resume from the tray before starting a diagnostic.",APP_NAME,MB_OK|MB_ICONWARNING);return;}
    GetWindowTextW(g_pathEdit,g_program,MAX_WPATH);GetWindowTextW(g_argsEdit,g_args,2048);GetWindowTextW(g_watchEdit,g_watchFolder,MAX_WPATH);
    if(!g_program[0]){if(!choose_exe(g_hwnd))return;GetWindowTextW(g_pathEdit,g_program,MAX_WPATH);}
    if(GetFileAttributesW(g_program)==INVALID_FILE_ATTRIBUTES){MessageBoxW(g_hwnd,L"The selected executable path is invalid or no longer exists.",APP_NAME,MB_OK|MB_ICONERROR);return;}
    reset_monitor_state();g_reportLen=0;g_report[0]=0;line(L"Monitoring in progress...\r\n\r\nAV-oriented passive watch: click Start Diagnostic first, then open the program normally. The monitor waits for it and never launches a duplicate.\r\n\r\nAutomatic freeze/lag detection is ON. Version 1.0.18 Build 19 records MAIN + lightweight helper-process metrics, system CPU/RAM/disk, GDI/USER resources, and window responsiveness about once per second. At a freeze it automatically runs Wait Chain Traversal for hung MAIN UI threads only, without opening target threads. You do not need to click anything when the freeze happens; simply reproduce it, wait a little, then Stop & Analyze.");report_to_ui();
    g_preferExisting=TRUE;g_monitoring=TRUE;g_stopRequested=0;
    EnableWindow(g_startBtn,FALSE);EnableWindow(g_stopBtn,TRUE);EnableWindow(g_saveBtn,FALSE);EnableWindow(g_baseBtn,FALSE);set_inputs_enabled(FALSE);set_status(L"Starting passive diagnostic worker with automatic freeze/lag detection...");
    DWORD tid=0;g_workerHandle=CreateThread(NULL,0,diagnostic_worker,NULL,0,&tid);
    if(g_workerHandle)log_event(L"INFO",L"Diagnostic monitoring started in passive wait/attach mode");
    if(!g_workerHandle){DWORD e=GetLastError();log_event(L"ERROR",L"Diagnostic monitoring worker could not start");g_monitoring=FALSE;EnableWindow(g_startBtn,TRUE);EnableWindow(g_stopBtn,FALSE);set_inputs_enabled(TRUE);WCHAR m[512];wsprintfW(m,L"Could not start the background diagnostic worker. Error %u (0x%08X).",e,e);MessageBoxW(g_hwnd,m,APP_NAME,MB_OK|MB_ICONERROR);set_status(L"Ready — background worker could not start.");}
}
static void stop_diagnostic(void){if(!g_monitoring||!g_workerHandle)return;g_stopRequested=1;log_event(L"INFO",L"User requested diagnostic monitoring stop and analysis");EnableWindow(g_stopBtn,FALSE);set_status(L"Stopping monitoring — analysis continues in the background. The window will stay responsive.");}
static void set_baseline(void){if(!g_reportLen){MessageBoxW(g_hwnd,L"Run and analyze a diagnostic first.",APP_NAME,MB_OK|MB_ICONWARNING);return;}g_baseline.maxProcessCount=g_maxProcessCount;g_baseline.maxWorkingSet=g_maxWorkingSet;g_baseline.visible=g_everVisibleWindow;g_baseline.rootExited=g_rootExited;g_baseline.exitCode=g_rootExitCode;g_baseline.crashEvents=g_lastCrashEvents;g_baseline.hangEvents=g_lastHangEvents;g_baseline.networkCount=g_lastNetworkCount;g_baseline.moduleCount=g_lastModuleCount;g_baseline.folderChanges=g_lastFolderChanges;g_baseline.valid=TRUE;MessageBoxW(g_hwnd,L"Current diagnostic saved as the in-memory baseline. Run the program again; the next report will include a comparison section.",APP_NAME,MB_OK|MB_ICONINFORMATION);}
static void open_program_folder(void){if(!g_program[0])return;WCHAR d[MAX_WPATH];dirnamew(g_program,d,MAX_WPATH);if(d[0])ShellExecuteW(g_hwnd,L"open",d,NULL,NULL,SW_SHOWNORMAL);}


static BOOL path_exists(LPCWSTR p){DWORD a=GetFileAttributesW(p);return a!=INVALID_FILE_ATTRIBUTES;}
static void ensure_dir(LPCWSTR p){if(p&&p[0])CreateDirectoryW(p,NULL);}
static void init_app_paths(void){
    WCHAR base[MAX_WPATH];base[0]=0;DWORD n=GetEnvironmentVariableW(L"LOCALAPPDATA",base,MAX_WPATH);if(!n||n>=MAX_WPATH)wcopy(base,L".",MAX_WPATH);
    wcopy(g_appDataDir,base,MAX_WPATH);wcat(g_appDataDir,L"\\ProgramDiagnosticMonitor-Isolated",MAX_WPATH);ensure_dir(g_appDataDir);
    wcopy(g_dataDir,g_appDataDir,MAX_WPATH);wcat(g_dataDir,L"\\Data",MAX_WPATH);ensure_dir(g_dataDir);
    wcopy(g_tempDir,g_appDataDir,MAX_WPATH);wcat(g_tempDir,L"\\Temp",MAX_WPATH);ensure_dir(g_tempDir);
    wcopy(g_logsDir,g_appDataDir,MAX_WPATH);wcat(g_logsDir,L"\\Logs",MAX_WPATH);ensure_dir(g_logsDir);
    wcopy(g_diagDir,g_appDataDir,MAX_WPATH);wcat(g_diagDir,L"\\Diagnostics",MAX_WPATH);ensure_dir(g_diagDir);
    wcopy(g_settingsPath,g_dataDir,MAX_WPATH);wcat(g_settingsPath,L"\\settings.ini",MAX_WPATH);
    wcopy(g_logPath,g_logsDir,MAX_WPATH);wcat(g_logPath,L"\\ProgramDiagnosticMonitor.log",MAX_WPATH);
    wcopy(g_lastReportDir,g_logsDir,MAX_WPATH);
}
static BOOL write_wtext_file(LPCWSTR path,LPCWSTR text){HANDLE f=CreateFileW(path,GENERIC_WRITE,FILE_SHARE_READ,NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);if(f==INVALID_HANDLE_VALUE)return FALSE;DWORD bytes=wlen(text)*sizeof(WCHAR),wr=0;BOOL ok=WriteFile(f,text,bytes,&wr,NULL)&&wr==bytes;CloseHandle(f);return ok;}
static DWORD read_wtext_file(LPCWSTR path,WCHAR* out,DWORD cap){if(!cap)return 0;out[0]=0;HANDLE f=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);if(f==INVALID_HANDLE_VALUE)return 0;DWORD rd=0,max=(cap-1)*sizeof(WCHAR);if(!ReadFile(f,out,max,&rd,NULL)){CloseHandle(f);return 0;}CloseHandle(f);DWORD chars=rd/sizeof(WCHAR);out[chars]=0;return chars;}
static INT setting_int(LPCWSTR text,LPCWSTR key,INT def){DWORD kn=wlen(key);for(DWORD i=0;text&&text[i];){DWORD line=i;while(text[i]&&text[i]!=L'\r'&&text[i]!=L'\n')i++;if(i-line>kn+1){BOOL same=TRUE;for(DWORD j=0;j<kn;j++)if(text[line+j]!=key[j]){same=FALSE;break;}if(same&&text[line+kn]==L'='){INT sign=1,v=0;DWORD k=line+kn+1;if(text[k]==L'-'){sign=-1;k++;}BOOL any=FALSE;while(k<i&&text[k]>=L'0'&&text[k]<=L'9'){v=v*10+(text[k]-L'0');k++;any=TRUE;}if(any)return v*sign;}}while(text[i]==L'\r'||text[i]==L'\n')i++;}return def;}
static void settings_defaults(APPSETTINGS* a){a->minimizeToTray=FALSE;a->closeToTray=FALSE;a->startMinimized=FALSE;a->openSettingsAtStartup=FALSE;a->startPaused=FALSE;a->notifications=TRUE;a->debugMode=FALSE;a->trayClickMode=2;a->winX=sc(70);a->winY=sc(55);a->winW=sc(1120);a->winH=sc(800);}
static BOOL save_settings_to(LPCWSTR path,const APPSETTINGS* a){WCHAR text[4096],tmp[MAX_WPATH];wsprintfW(text,L"Version=1\r\nMinimizeToTray=%u\r\nCloseToTray=%u\r\nStartMinimized=%u\r\nOpenSettingsAtStartup=%u\r\nStartPaused=%u\r\nNotifications=%u\r\nDebugMode=%u\r\nTrayClickMode=%u\r\nWindowX=%d\r\nWindowY=%d\r\nWindowW=%d\r\nWindowH=%d\r\n",a->minimizeToTray,a->closeToTray,a->startMinimized,a->openSettingsAtStartup,a->startPaused,a->notifications,a->debugMode,a->trayClickMode,a->winX,a->winY,a->winW,a->winH);wcopy(tmp,path,MAX_WPATH);wcat(tmp,L".tmp",MAX_WPATH);if(!write_wtext_file(tmp,text))return FALSE;if(!MoveFileExW(tmp,path,MOVEFILE_REPLACE_EXISTING)){DeleteFileW(tmp);return FALSE;}return TRUE;}
static BOOL load_settings_from(LPCWSTR path,APPSETTINGS* a){WCHAR text[8192];if(!read_wtext_file(path,text,8192))return FALSE;a->minimizeToTray=setting_int(text,L"MinimizeToTray",a->minimizeToTray)?TRUE:FALSE;a->closeToTray=setting_int(text,L"CloseToTray",a->closeToTray)?TRUE:FALSE;a->startMinimized=setting_int(text,L"StartMinimized",a->startMinimized)?TRUE:FALSE;a->openSettingsAtStartup=setting_int(text,L"OpenSettingsAtStartup",a->openSettingsAtStartup)?TRUE:FALSE;a->startPaused=setting_int(text,L"StartPaused",a->startPaused)?TRUE:FALSE;a->notifications=setting_int(text,L"Notifications",a->notifications)?TRUE:FALSE;a->debugMode=setting_int(text,L"DebugMode",a->debugMode)?TRUE:FALSE;a->trayClickMode=(DWORD)setting_int(text,L"TrayClickMode",(INT)a->trayClickMode);if(a->trayClickMode!=1&&a->trayClickMode!=2)a->trayClickMode=2;a->winX=setting_int(text,L"WindowX",a->winX);a->winY=setting_int(text,L"WindowY",a->winY);a->winW=setting_int(text,L"WindowW",a->winW);a->winH=setting_int(text,L"WindowH",a->winH);if(a->winW<sc(900))a->winW=sc(1120);if(a->winH<sc(560))a->winH=sc(800);return TRUE;}
static void copy_settings_mask(APPSETTINGS* d,const APPSETTINGS* s,DWORD mask){if(mask&SETF_MINIMIZE)d->minimizeToTray=s->minimizeToTray;if(mask&SETF_CLOSE)d->closeToTray=s->closeToTray;if(mask&SETF_STARTMIN)d->startMinimized=s->startMinimized;if(mask&SETF_OPENSETTINGS)d->openSettingsAtStartup=s->openSettingsAtStartup;if(mask&SETF_STARTPAUSED)d->startPaused=s->startPaused;if(mask&SETF_NOTIFICATIONS)d->notifications=s->notifications;if(mask&SETF_DEBUG)d->debugMode=s->debugMode;if(mask&SETF_TRAYCLICK)d->trayClickMode=s->trayClickMode;if(mask&SETF_GEOMETRY){d->winX=s->winX;d->winY=s->winY;d->winW=s->winW;d->winH=s->winH;}}
static BOOL merge_settings_to_file(LPCWSTR path,const APPSETTINGS* desired,DWORD mask){APPSETTINGS merged;settings_defaults(&merged);load_settings_from(path,&merged);copy_settings_mask(&merged,desired,mask);return save_settings_to(path,&merged);}
static void load_settings(void){settings_defaults(&g_settings);load_settings_from(g_settingsPath,&g_settings);}
static BOOL persist_settings_mask(DWORD mask){BOOL ok=FALSE;HANDLE mx=CreateMutexW(NULL,FALSE,SETTINGS_MUTEX_NAME);if(mx){DWORD wr=WaitForSingleObject(mx,3000);if(wr==WAIT_OBJECT_0||wr==WAIT_ABANDONED_0){APPSETTINGS merged;settings_defaults(&merged);load_settings_from(g_settingsPath,&merged);copy_settings_mask(&merged,&g_settings,mask);ok=save_settings_to(g_settingsPath,&merged);if(ok)g_settings=merged;ReleaseMutex(mx);}CloseHandle(mx);}if(!ok)log_event(L"WARN",L"Settings atomic merge/save failed");return ok;}
static BOOL file_size(LPCWSTR path,ULONGLONG* sz){*sz=0;HANDLE f=CreateFileW(path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);if(f==INVALID_HANDLE_VALUE)return FALSE;LONGLONG s=0;BOOL ok=GetFileSizeEx(f,&s);CloseHandle(f);if(ok)*sz=(ULONGLONG)s;return ok;}
static void rotate_log_path(LPCWSTR base,ULONGLONG maxBytes){ULONGLONG sz=0;if(!file_size(base,&sz)||sz<maxBytes)return;WCHAR src[MAX_WPATH],dst[MAX_WPATH];for(INT i=3;i>=1;i--){wcopy(src,base,MAX_WPATH);WCHAR n[16];wsprintfW(n,L".%d",i);wcat(src,n,MAX_WPATH);wcopy(dst,base,MAX_WPATH);wsprintfW(n,L".%d",i+1);wcat(dst,n,MAX_WPATH);DeleteFileW(dst);MoveFileExW(src,dst,MOVEFILE_REPLACE_EXISTING);}wcopy(dst,base,MAX_WPATH);wcat(dst,L".1",MAX_WPATH);DeleteFileW(dst);MoveFileExW(base,dst,MOVEFILE_REPLACE_EXISTING);}
static BOOL append_log_path(LPCWSTR path,LPCWSTR level,LPCWSTR msg,ULONGLONG maxBytes){rotate_log_path(path,maxBytes);HANDLE f=CreateFileW(path,GENERIC_WRITE,FILE_SHARE_READ,NULL,OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);if(f==INVALID_HANDLE_VALUE)return FALSE;LONGLONG zero=0;SetFilePointerEx(f,zero,NULL,FILE_END);SYSTEMTIME st;GetLocalTime(&st);WCHAR linebuf[2048];wsprintfW(linebuf,L"%04u-%02u-%02u %02u:%02u:%02u [%s] v%s Build %u - %s\r\n",st.wYear,st.wMonth,st.wDay,st.wHour,st.wMinute,st.wSecond,level,APP_VERSION,APP_BUILD,msg);DWORD bytes=wlen(linebuf)*sizeof(WCHAR),wr=0;BOOL ok=WriteFile(f,linebuf,bytes,&wr,NULL)&&wr==bytes;CloseHandle(f);return ok;}
static void log_event(LPCWSTR level,LPCWSTR msg){append_log_path(g_logPath,level,msg,5ULL*1024ULL*1024ULL);}
static void log_debug(LPCWSTR msg){if(g_settings.debugMode)log_event(L"DEBUG",msg);}
static void settings_sync_ui(void){if(g_debugCheck)SendMessageW(g_debugCheck,BM_SETCHECK,g_settings.debugMode?BST_CHECKED:0,0);if(g_setMinimize)SendMessageW(g_setMinimize,BM_SETCHECK,g_settings.minimizeToTray?BST_CHECKED:0,0);if(g_setClose)SendMessageW(g_setClose,BM_SETCHECK,g_settings.closeToTray?BST_CHECKED:0,0);if(g_setStartMin)SendMessageW(g_setStartMin,BM_SETCHECK,g_settings.startMinimized?BST_CHECKED:0,0);if(g_setOpenSettings)SendMessageW(g_setOpenSettings,BM_SETCHECK,g_settings.openSettingsAtStartup?BST_CHECKED:0,0);if(g_setStartPaused)SendMessageW(g_setStartPaused,BM_SETCHECK,g_settings.startPaused?BST_CHECKED:0,0);if(g_setNotifications)SendMessageW(g_setNotifications,BM_SETCHECK,g_settings.notifications?BST_CHECKED:0,0);if(g_setDebug)SendMessageW(g_setDebug,BM_SETCHECK,g_settings.debugMode?BST_CHECKED:0,0);if(g_setSingleClick)SendMessageW(g_setSingleClick,BM_SETCHECK,g_settings.trayClickMode==1?BST_CHECKED:0,0);}
static void set_debug_mode(BOOL v,BOOL persist){g_settings.debugMode=v;if(persist)persist_settings_mask(SETF_DEBUG);settings_sync_ui();log_event(L"INFO",v?L"Debug Mode enabled":L"Debug Mode disabled");}
static void set_runtime_paused(BOOL v){g_paused=v;if(g_startBtn)EnableWindow(g_startBtn,!v&&g_program[0]&&!g_monitoring&&!g_workerHandle);if(v)set_status(g_monitoring?L"Paused — active diagnostic sampling is temporarily paused.":L"Paused — Resume from the tray to begin monitoring.");else set_status(g_monitoring?L"Monitoring resumed — automatic freeze/lag detection is active.":L"Ready — passive diagnostic monitoring available.");log_event(L"INFO",v?L"Runtime paused":L"Runtime resumed");}
static void tray_fill(NOTIFYICONDATAW* n){memset(n,0,sizeof(*n));n->cbSize=sizeof(*n);n->hWnd=g_hwnd;n->uID=1;n->uFlags=NIF_MESSAGE|NIF_ICON|NIF_TIP;n->uCallbackMessage=WM_PDM_TRAY;n->hIcon=LoadIconW(g_hInst,(LPCWSTR)(ULONG_PTR)1);wcopy(n->szTip,L"Program Diagnostic Monitor — Isolated",128);}
static void tray_add(void){if(!g_hwnd)return;NOTIFYICONDATAW n;tray_fill(&n);if(Shell_NotifyIconW(NIM_ADD,&n))g_trayAdded=TRUE;}
static void tray_remove(void){if(!g_trayAdded||!g_hwnd)return;NOTIFYICONDATAW n;tray_fill(&n);Shell_NotifyIconW(NIM_DELETE,&n);g_trayAdded=FALSE;}
static void tray_notify(LPCWSTR title,LPCWSTR msg){if(!g_settings.notifications||!g_trayAdded)return;NOTIFYICONDATAW n;tray_fill(&n);n.uFlags|=NIF_INFO;wcopy(n.szInfoTitle,title,64);wcopy(n.szInfo,msg,256);n.dwInfoFlags=NIIF_INFO;Shell_NotifyIconW(NIM_MODIFY,&n);}
static void show_main_window(void){ShowWindow(g_hwnd,SW_RESTORE);BringWindowToTop(g_hwnd);SetForegroundWindow(g_hwnd);}
static void open_folder_path(LPCWSTR p){if(p&&p[0])ShellExecuteW(g_hwnd,L"open",p,NULL,NULL,SW_SHOWNORMAL);}
static void export_diagnostic_report(void){SYSTEMTIME st;GetLocalTime(&st);WCHAR path[MAX_WPATH],text[16384];wcopy(path,g_diagDir,MAX_WPATH);WCHAR n[128];wsprintfW(n,L"\\PDM-Diagnostic-v1.0.18-Build19-%04u%02u%02u-%02u%02u%02u.txt",st.wYear,st.wMonth,st.wDay,st.wHour,st.wMinute,st.wSecond);wcat(path,n,MAX_WPATH);wsprintfW(text,L"Program Diagnostic Monitor %s Build %u\r\n\r\nInstall namespace: %%LOCALAPPDATA%%\\Programs\\ProgramDiagnosticMonitor-Isolated\r\nApp data: %s\r\nSettings: %s\r\nLogs: %s\r\nTemp: %s\r\nDiagnostics: %s\r\n\r\nState: monitoring=%u paused=%u debug=%u tray=%u\r\nSelected target: %s\r\n\r\nCurrent report follows when available:\r\n%s",APP_VERSION,APP_BUILD,g_appDataDir,g_settingsPath,g_logsDir,g_tempDir,g_diagDir,g_monitoring,g_paused,g_settings.debugMode,g_trayAdded,g_program[0]?g_program:L"(none)",g_reportLen?g_report:L"(no completed diagnostic report)");if(write_wtext_file(path,text)){log_event(L"INFO",L"Diagnostic report exported");tray_notify(L"Program Diagnostic Monitor",L"Diagnostic report exported to the dedicated Diagnostics folder.");open_folder_path(g_diagDir);}else MessageBoxW(g_hwnd,L"Could not export the diagnostic report.",APP_NAME,MB_OK|MB_ICONERROR);}
static void request_exit(void){if(g_exiting)return;g_exiting=TRUE;log_event(L"INFO",L"Exit requested");SendMessageW(g_hwnd,WM_CLOSE,0,0);}
static void tray_menu(void){POINT pt={0,0};GetCursorPos(&pt);HMENU m=CreatePopupMenu();if(!m)return;AppendMenuW(m,MF_STRING,IDM_TRAY_SHOW,L"Open / Show");AppendMenuW(m,MF_STRING,IDM_TRAY_SETTINGS,L"Settings");AppendMenuW(m,MF_SEPARATOR,0,NULL);AppendMenuW(m,MF_STRING,IDM_TRAY_STARTSTOP,g_monitoring?L"Stop && Analyze":L"Start Diagnostic");AppendMenuW(m,MF_STRING,IDM_TRAY_PAUSERESUME,g_paused?L"Resume":L"Pause");AppendMenuW(m,MF_STRING|(g_settings.debugMode?MF_CHECKED:0),IDM_TRAY_DEBUG,L"Debug Mode");AppendMenuW(m,MF_STRING,IDM_TRAY_SELFTEST,L"Run Safe Self-Test");AppendMenuW(m,MF_SEPARATOR,0,NULL);AppendMenuW(m,MF_STRING,IDM_TRAY_LOGS,L"Open Logs");AppendMenuW(m,MF_STRING,IDM_TRAY_DIAGNOSTICS,L"Open Diagnostics");AppendMenuW(m,MF_STRING,IDM_TRAY_EXPORT,L"Export Logs / Diagnostic Report");AppendMenuW(m,MF_SEPARATOR,0,NULL);AppendMenuW(m,MF_STRING,IDM_TRAY_EXIT,L"Exit App");SetForegroundWindow(g_hwnd);UINT cmd=TrackPopupMenu(m,TPM_RIGHTBUTTON|TPM_RETURNCMD,pt.x,pt.y,0,g_hwnd,NULL);DestroyMenu(m);if(cmd==IDM_TRAY_SHOW)show_main_window();else if(cmd==IDM_TRAY_SETTINGS)open_settings_window();else if(cmd==IDM_TRAY_STARTSTOP){if(g_monitoring)stop_diagnostic();else if(g_program[0]&&!g_paused)start_diagnostic();else{show_main_window();tray_notify(L"Program Diagnostic Monitor",g_paused?L"Resume monitoring first.":L"Choose a program before starting a diagnostic.");}}else if(cmd==IDM_TRAY_PAUSERESUME)set_runtime_paused(!g_paused);else if(cmd==IDM_TRAY_DEBUG)set_debug_mode(!g_settings.debugMode,TRUE);else if(cmd==IDM_TRAY_SELFTEST)run_safe_self_test();else if(cmd==IDM_TRAY_LOGS)open_folder_path(g_logsDir);else if(cmd==IDM_TRAY_DIAGNOSTICS)open_folder_path(g_diagDir);else if(cmd==IDM_TRAY_EXPORT)export_diagnostic_report();else if(cmd==IDM_TRAY_EXIT)request_exit();}
static void save_window_geometry(void){if(!g_hwnd||IsIconic(g_hwnd))return;RECT r;if(GetWindowRect(g_hwnd,&r)){INT w=r.right-r.left,h=r.bottom-r.top;if(w>=sc(900)&&h>=sc(560)){g_settings.winX=r.left;g_settings.winY=r.top;g_settings.winW=w;g_settings.winH=h;persist_settings_mask(SETF_GEOMETRY);}}}
static void clamp_window_geometry(void){INT sw=GetSystemMetrics(0),sh=GetSystemMetrics(1),vw=GetSystemMetrics(78),vh=GetSystemMetrics(79);if(sw<640)sw=1920;if(sh<480)sh=1080;if(vw<sw)vw=sw;if(vh<sh)vh=sh;INT minW=sc(900),minH=sc(560);if(minW>sw)minW=sw;if(minH>sh)minH=sh;if(g_settings.winW<minW)g_settings.winW=minW;if(g_settings.winH<minH)g_settings.winH=minH;if(g_settings.winW>vw)g_settings.winW=sw;if(g_settings.winH>vh)g_settings.winH=sh;RECT r={g_settings.winX,g_settings.winY,g_settings.winX+g_settings.winW,g_settings.winY+g_settings.winH};if(!MonitorFromRect(&r,MONITOR_DEFAULTTONULL)){g_settings.winX=sc(70);g_settings.winY=sc(55);if(g_settings.winX+g_settings.winW>sw)g_settings.winX=0;if(g_settings.winY+g_settings.winH>sh)g_settings.winY=0;}}
static void reset_window_layout(BOOL applyNow){g_settings.winX=sc(70);g_settings.winY=sc(55);g_settings.winW=sc(1120);g_settings.winH=sc(800);clamp_window_geometry();persist_settings_mask(SETF_GEOMETRY);if(applyNow&&g_hwnd)MoveWindow(g_hwnd,g_settings.winX,g_settings.winY,g_settings.winW,g_settings.winH,TRUE);log_event(L"INFO",L"Window layout reset to primary-monitor defaults");}
static void self_append(WCHAR* out,DWORD* len,LPCWSTR status,LPCWSTR name,LPCWSTR detail){WCHAR t[1024];wsprintfW(t,L"%s - %s%s%s\r\n",status,name,detail&&detail[0]?L" | ":L"",detail&&detail[0]?detail:L"");append_buf(out,len,32768,t);}
static void run_safe_self_test(void){
    WCHAR out[32768];DWORD len=0;out[0]=0;WCHAR hdr[512];wsprintfW(hdr,L"=== Program Diagnostic Monitor SAFE SELF-TEST v%s Build %u ===\r\n",APP_VERSION,APP_BUILD);append_buf(out,&len,32768,hdr);DWORD fail=0,skip=0,notTested=0;
    WCHAR tp[MAX_WPATH];wcopy(tp,g_tempDir,MAX_WPATH);wcat(tp,L"\\selftest-rw.tmp",MAX_WPATH);LPCWSTR sample=L"PDM19-SELFTEST";BOOL ok=write_wtext_file(tp,sample);WCHAR rb[64];DWORD rn=ok?read_wtext_file(tp,rb,64):0;BOOL rw=ok&&rn==wlen(sample)&&memcmp(rb,sample,wlen(sample)*sizeof(WCHAR))==0;DeleteFileW(tp);self_append(out,&len,rw?L"PASS":L"FAIL",L"Project Temp write -> read -> compare -> delete",g_tempDir);if(!rw)fail++;
    APPSETTINGS a,b;settings_defaults(&a);a.minimizeToTray=TRUE;a.closeToTray=TRUE;a.startMinimized=TRUE;a.openSettingsAtStartup=TRUE;a.startPaused=TRUE;a.notifications=FALSE;a.debugMode=TRUE;a.trayClickMode=1;a.winX=sc(123);a.winY=sc(145);a.winW=sc(1001);a.winH=sc(677);settings_defaults(&b);WCHAR sp[MAX_WPATH];wcopy(sp,g_tempDir,MAX_WPATH);wcat(sp,L"\\selftest-settings.ini",MAX_WPATH);DeleteFileW(sp);BOOL so=save_settings_to(sp,&a);BOOL lo=so&&load_settings_from(sp,&b);BOOL eq=lo&&a.minimizeToTray==b.minimizeToTray&&a.closeToTray==b.closeToTray&&a.startMinimized==b.startMinimized&&a.openSettingsAtStartup==b.openSettingsAtStartup&&a.startPaused==b.startPaused&&a.notifications==b.notifications&&a.debugMode==b.debugMode&&a.trayClickMode==b.trayClickMode&&a.winX==b.winX&&a.winY==b.winY&&a.winW==b.winW&&a.winH==b.winH;self_append(out,&len,eq?L"PASS":L"FAIL",L"Settings persistence write -> reload/read -> compare",L"all persisted settings; isolated temporary INI; real settings untouched");if(!eq)fail++;
    APPSETTINGS older,newer,stale,result;settings_defaults(&older);older.debugMode=FALSE;older.winX=sc(111);save_settings_to(sp,&older);newer=older;newer.debugMode=TRUE;save_settings_to(sp,&newer);stale=older;stale.winX=sc(333);BOOL merged=merge_settings_to_file(sp,&stale,SETF_GEOMETRY);settings_defaults(&result);BOOL staleOk=merged&&load_settings_from(sp,&result)&&result.debugMode==TRUE&&result.winX==stale.winX;self_append(out,&len,staleOk?L"PASS":L"FAIL",L"Multi-instance stale-writer protection",L"older instance geometry merge preserved newer Debug setting in isolated settings file");if(!staleOk)fail++;DeleteFileW(sp);
    BOOL settingsWasVisible=g_settingsHwnd&&IsWindowVisible(g_settingsHwnd);open_settings_window();APPSETTINGS handlerOrig=g_settings;WCHAR realSettingsPath[MAX_WPATH],handlerPath[MAX_WPATH];wcopy(realSettingsPath,g_settingsPath,MAX_WPATH);wcopy(handlerPath,g_tempDir,MAX_WPATH);wcat(handlerPath,L"\\selftest-handler-settings.ini",MAX_WPATH);DeleteFileW(handlerPath);BOOL handlersReady=g_settingsHwnd&&g_setMinimize&&g_setClose&&g_setStartMin&&g_setOpenSettings&&g_setStartPaused&&g_setNotifications&&g_setDebug&&g_setSingleClick;BOOL handlersOk=handlersReady&&save_settings_to(handlerPath,&handlerOrig);if(handlersOk){wcopy(g_settingsPath,handlerPath,MAX_WPATH);SendMessageW(g_setMinimize,BM_SETCHECK,!handlerOrig.minimizeToTray,0);SendMessageW(g_settingsHwnd,WM_COMMAND,IDC_SET_MINIMIZE,0);SendMessageW(g_setClose,BM_SETCHECK,!handlerOrig.closeToTray,0);SendMessageW(g_settingsHwnd,WM_COMMAND,IDC_SET_CLOSE,0);SendMessageW(g_setStartMin,BM_SETCHECK,!handlerOrig.startMinimized,0);SendMessageW(g_settingsHwnd,WM_COMMAND,IDC_SET_STARTMIN,0);SendMessageW(g_setOpenSettings,BM_SETCHECK,!handlerOrig.openSettingsAtStartup,0);SendMessageW(g_settingsHwnd,WM_COMMAND,IDC_SET_OPENSETTINGS,0);SendMessageW(g_setStartPaused,BM_SETCHECK,!handlerOrig.startPaused,0);SendMessageW(g_settingsHwnd,WM_COMMAND,IDC_SET_STARTPAUSED,0);SendMessageW(g_setNotifications,BM_SETCHECK,!handlerOrig.notifications,0);SendMessageW(g_settingsHwnd,WM_COMMAND,IDC_SET_NOTIFICATIONS,0);SendMessageW(g_setDebug,BM_SETCHECK,!handlerOrig.debugMode,0);SendMessageW(g_settingsHwnd,WM_COMMAND,IDC_SET_DEBUG,0);SendMessageW(g_setSingleClick,BM_SETCHECK,handlerOrig.trayClickMode==1?0:BST_CHECKED,0);SendMessageW(g_settingsHwnd,WM_COMMAND,IDC_SET_SINGLECLICK,0);APPSETTINGS hv;settings_defaults(&hv);handlersOk=load_settings_from(handlerPath,&hv)&&hv.minimizeToTray!=handlerOrig.minimizeToTray&&hv.closeToTray!=handlerOrig.closeToTray&&hv.startMinimized!=handlerOrig.startMinimized&&hv.openSettingsAtStartup!=handlerOrig.openSettingsAtStartup&&hv.startPaused!=handlerOrig.startPaused&&hv.notifications!=handlerOrig.notifications&&hv.debugMode!=handlerOrig.debugMode&&hv.trayClickMode!=(handlerOrig.trayClickMode);}
    self_append(out,&len,handlersOk?L"PASS":L"FAIL",L"Settings controls production handlers + persistence",L"all eight setting controls exercised through the real Settings WM_COMMAND path against an isolated temporary INI; immediate/next-launch values verified after reload");if(!handlersOk)fail++;
    RECT oldRect;BOOL haveOldRect=GetWindowRect(g_hwnd,&oldRect);BOOL resetOk=FALSE;if(handlersReady){SendMessageW(g_settingsHwnd,WM_COMMAND,IDC_SET_RESETLAYOUT,0);APPSETTINGS rv;settings_defaults(&rv);resetOk=load_settings_from(handlerPath,&rv)&&rv.winW>=sc(900)&&rv.winH>=sc(560)&&g_settings.winX==rv.winX&&g_settings.winY==rv.winY&&g_settings.winW==rv.winW&&g_settings.winH==rv.winH;}self_append(out,&len,resetOk?L"PASS":L"FAIL",L"Reset Window Layout production control",L"real Settings button handler reset and persisted geometry only to isolated self-test settings");if(!resetOk)fail++;if(haveOldRect)MoveWindow(g_hwnd,oldRect.left,oldRect.top,oldRect.right-oldRect.left,oldRect.bottom-oldRect.top,TRUE);wcopy(g_settingsPath,realSettingsPath,MAX_WPATH);g_settings=handlerOrig;settings_sync_ui();DeleteFileW(handlerPath);if(g_settingsHwnd&&!settingsWasVisible)ShowWindow(g_settingsHwnd,SW_HIDE);
    BOOL oldDbg=g_settings.debugMode;set_debug_mode(!oldDbg,FALSE);BOOL sync1=g_settings.debugMode==(!oldDbg)&&(!g_debugCheck||((SendMessageW(g_debugCheck,BM_GETCHECK,0,0)==BST_CHECKED)==(!oldDbg)))&&(!g_setDebug||((SendMessageW(g_setDebug,BM_GETCHECK,0,0)==BST_CHECKED)==(!oldDbg)));set_debug_mode(oldDbg,FALSE);BOOL sync2=g_settings.debugMode==oldDbg&&(!g_debugCheck||((SendMessageW(g_debugCheck,BM_GETCHECK,0,0)==BST_CHECKED)==oldDbg))&&(!g_setDebug||((SendMessageW(g_setDebug,BM_GETCHECK,0,0)==BST_CHECKED)==oldDbg));BOOL sy=sync1&&sync2;self_append(out,&len,sy?L"PASS":L"FAIL",L"Settings <-> main UI Debug synchronization",L"production setter toggled and restored without persisting test value");if(!sy)fail++;
    BOOL iso=wcontainsi(g_appDataDir,L"ProgramDiagnosticMonitor-Isolated")&&wcontainsi(g_settingsPath,L"\\Data\\settings.ini")&&wcontainsi(g_logsDir,L"\\Logs")&&wcontainsi(g_diagDir,L"\\Diagnostics");self_append(out,&len,iso?L"PASS":L"FAIL",L"Dedicated isolated project paths",g_appDataDir);if(!iso)fail++;
    BOOL peer=is_protected_peer_name(L"CrashMonitor.exe")&&is_protected_peer_name(L"RitschyMirror.exe")&&!is_protected_peer_name(L"notepad.exe");self_append(out,&len,peer?L"PASS":L"FAIL",L"Protected-peer classifier",L"Crash Monitor / RitschyMirror shield rule");if(!peer)fail++;
    WCHAR lp[MAX_WPATH];wcopy(lp,g_tempDir,MAX_WPATH);wcat(lp,L"\\selftest-log.log",MAX_WPATH);DeleteFileW(lp);for(INT ri=1;ri<=4;ri++){WCHAR rp[MAX_WPATH],rn[16];wcopy(rp,lp,MAX_WPATH);wsprintfW(rn,L".%d",ri);wcat(rp,rn,MAX_WPATH);DeleteFileW(rp);}for(INT i=0;i<20;i++)append_log_path(lp,L"TEST",L"012345678901234567890123456789012345678901234567890123456789",256);WCHAR l1[MAX_WPATH];wcopy(l1,lp,MAX_WPATH);wcat(l1,L".1",MAX_WPATH);BOOL rot=path_exists(lp)&&path_exists(l1);DeleteFileW(lp);for(INT ri=1;ri<=4;ri++){WCHAR rp[MAX_WPATH],rn[16];wcopy(rp,lp,MAX_WPATH);wsprintfW(rn,L".%d",ri);wcat(rp,rn,MAX_WPATH);DeleteFileW(rp);}self_append(out,&len,rot?L"PASS":L"FAIL",L"Bounded log rotation",L"isolated temporary log with tiny test cap; all temporary generations cleaned");if(!rot)fail++;
    if(!g_trayAdded)tray_add();BOOL tr=g_trayAdded;self_append(out,&len,tr?L"PASS":L"FAIL",L"Tray icon production add path",tr?L"tray registered":L"Shell_NotifyIcon add failed");if(!tr)fail++;
    BOOL oldPause=g_paused;set_runtime_paused(!oldPause);BOOL p1=g_paused==(!oldPause);set_runtime_paused(oldPause);BOOL p2=g_paused==oldPause;self_append(out,&len,(p1&&p2)?L"PASS":L"FAIL",L"Pause / Resume production state path",L"runtime state toggled and restored");if(!(p1&&p2))fail++;
    APPSETTINGS savedSettings=g_settings;g_settings.winX=-5000;g_settings.winY=-5000;g_settings.winW=10;g_settings.winH=10;clamp_window_geometry();INT stSw=GetSystemMetrics(0),stSh=GetSystemMetrics(1);INT stMinW=sc(900),stMinH=sc(560);if(stMinW>stSw)stMinW=stSw;if(stMinH>stSh)stMinH=stSh;BOOL geo=g_settings.winX>=0&&g_settings.winY>=0&&g_settings.winW>=stMinW&&g_settings.winH>=stMinH;g_settings=savedSettings;settings_sync_ui();self_append(out,&len,geo?L"PASS":L"FAIL",L"Window placement/minimum-size recovery",L"production clamp logic recovered deliberately invalid isolated in-memory geometry; saved settings restored");if(!geo)fail++;
    BOOL oldMin=g_settings.minimizeToTray;g_settings.minimizeToTray=TRUE;ShowWindow(g_hwnd,SW_SHOW);SendMessageW(g_hwnd,WM_SIZE,SIZE_MINIMIZED,0);BOOL mt=!IsWindowVisible(g_hwnd);ShowWindow(g_hwnd,SW_RESTORE);g_settings.minimizeToTray=oldMin;self_append(out,&len,mt?L"PASS":L"FAIL",L"Minimize-to-tray production handler",L"temporarily hid and restored the real main window without persisting the test toggle");if(!mt)fail++;
    self_append(out,&len,L"NOT TESTED",L"Close/X-to-tray destructive fallback",L"the production WM_CLOSE path is wired and statically validated, but the in-process self-test does not risk terminating itself if the handler regresses");notTested++;
    self_append(out,&len,L"NOT TESTED",L"Cold-start decisions",L"Start Minimized / Open Settings / Start Paused require a relaunch; the monitor intentionally does not add self-launch/CreateProcess behavior for testing");notTested++;
    self_append(out,&len,L"SKIPPED",L"Actual Exit App process termination",L"self-test does not terminate its own production process");skip++;
    self_append(out,&len,L"SKIPPED",L"Explorer/taskbar forced restart",L"forcing Explorer termination is intentionally not performed; TaskbarCreated rebuild path remains active");skip++;
    self_append(out,&len,L"NOT TESTED",L"Live target freeze/WCT capture",L"requires a real selected target and an actual hung MAIN UI thread");notTested++;
    WCHAR sum[512];wsprintfW(sum,L"\r\nResult: %u FAIL, %u SKIPPED, %u NOT TESTED; all remaining executed tests PASS.\r\n",fail,skip,notTested);append_buf(out,&len,32768,sum);
    SYSTEMTIME st;GetLocalTime(&st);WCHAR path[MAX_WPATH],nm[160];wcopy(path,g_diagDir,MAX_WPATH);wsprintfW(nm,L"\\SafeSelfTest-v1.0.18-Build19-%04u%02u%02u-%02u%02u%02u.txt",st.wYear,st.wMonth,st.wDay,st.wHour,st.wMinute,st.wSecond);wcat(path,nm,MAX_WPATH);write_wtext_file(path,out);SetWindowTextW(g_reportEdit,out);log_event(fail?L"ERROR":L"INFO",fail?L"Safe Self-Test completed with FAIL":L"Safe Self-Test completed with 0 FAIL");MessageBoxW(g_hwnd,fail?L"Safe Self-Test completed with one or more FAIL results. Details are shown in the main window and Diagnostics folder.":L"Safe Self-Test completed with 0 FAIL. Details are shown in the main window and Diagnostics folder.",APP_NAME,MB_OK|(fail?MB_ICONERROR:MB_ICONINFORMATION));
}
static LRESULT CALLBACK settings_proc(HWND h,UINT msg,WPARAM wp,LPARAM lp){(void)lp;switch(msg){case WM_CREATE:{
    g_settingsHwnd=h;
    HWND title=CreateWindowExW(0,L"STATIC",L"Program Diagnostic Monitor Settings",WS_CHILD|WS_VISIBLE,sc(18),sc(14),sc(470),sc(28),h,0,g_hInst,NULL);
    g_setMinimize=CreateWindowExW(0,L"BUTTON",L"Minimize main window to tray",WS_CHILD|WS_VISIBLE|BS_AUTOCHECKBOX,sc(18),sc(50),sc(480),sc(26),h,(HMENU)IDC_SET_MINIMIZE,g_hInst,NULL);
    g_setClose=CreateWindowExW(0,L"BUTTON",L"Close / X sends main window to tray",WS_CHILD|WS_VISIBLE|BS_AUTOCHECKBOX,sc(18),sc(80),sc(480),sc(26),h,(HMENU)IDC_SET_CLOSE,g_hInst,NULL);
    g_setStartMin=CreateWindowExW(0,L"BUTTON",L"Start minimized to tray",WS_CHILD|WS_VISIBLE|BS_AUTOCHECKBOX,sc(18),sc(110),sc(480),sc(26),h,(HMENU)IDC_SET_STARTMIN,g_hInst,NULL);
    g_setOpenSettings=CreateWindowExW(0,L"BUTTON",L"Open Settings at startup",WS_CHILD|WS_VISIBLE|BS_AUTOCHECKBOX,sc(18),sc(140),sc(480),sc(26),h,(HMENU)IDC_SET_OPENSETTINGS,g_hInst,NULL);
    g_setStartPaused=CreateWindowExW(0,L"BUTTON",L"Start paused on next launch",WS_CHILD|WS_VISIBLE|BS_AUTOCHECKBOX,sc(18),sc(170),sc(480),sc(26),h,(HMENU)IDC_SET_STARTPAUSED,g_hInst,NULL);
    g_setNotifications=CreateWindowExW(0,L"BUTTON",L"Tray notifications",WS_CHILD|WS_VISIBLE|BS_AUTOCHECKBOX,sc(18),sc(200),sc(480),sc(26),h,(HMENU)IDC_SET_NOTIFICATIONS,g_hInst,NULL);
    g_setDebug=CreateWindowExW(0,L"BUTTON",L"Debug Mode (privacy-safe project events only)",WS_CHILD|WS_VISIBLE|BS_AUTOCHECKBOX,sc(18),sc(230),sc(480),sc(26),h,(HMENU)IDC_SET_DEBUG,g_hInst,NULL);
    g_setSingleClick=CreateWindowExW(0,L"BUTTON",L"Single-click tray icon opens app (unchecked = double-click)",WS_CHILD|WS_VISIBLE|BS_AUTOCHECKBOX,sc(18),sc(260),sc(500),sc(26),h,(HMENU)IDC_SET_SINGLECLICK,g_hInst,NULL);
    HWND note=CreateWindowExW(0,L"STATIC",L"Changes apply immediately unless labeled for next launch; settings are saved atomically.",WS_CHILD|WS_VISIBLE,sc(18),sc(294),sc(510),sc(42),h,0,g_hInst,NULL);
    g_setResetLayout=CreateWindowExW(0,L"BUTTON",L"Reset Window Layout",WS_CHILD|WS_VISIBLE,sc(18),sc(346),sc(160),sc(32),h,(HMENU)IDC_SET_RESETLAYOUT,g_hInst,NULL);
    g_setCloseBtn=CreateWindowExW(0,L"BUTTON",L"Close Settings",WS_CHILD|WS_VISIBLE,sc(230),sc(346),sc(135),sc(32),h,(HMENU)IDC_SET_CLOSEBTN,g_hInst,NULL);
    g_setExitBtn=CreateWindowExW(0,L"BUTTON",L"Exit App",WS_CHILD|WS_VISIBLE,sc(375),sc(346),sc(120),sc(32),h,(HMENU)IDC_SET_EXITBTN,g_hInst,NULL);
    HWND all[]={title,note,g_setMinimize,g_setClose,g_setStartMin,g_setOpenSettings,g_setStartPaused,g_setNotifications,g_setDebug,g_setSingleClick,g_setResetLayout,g_setCloseBtn,g_setExitBtn};for(UINT i=0;i<sizeof(all)/sizeof(all[0]);i++)font_all(all[i]);settings_sync_ui();return 0;}
case WM_COMMAND:{DWORD id=(DWORD)(wp&0xffff);DWORD mask=0;BOOL v;if(id==IDC_SET_CLOSEBTN){ShowWindow(h,SW_HIDE);return 0;}if(id==IDC_SET_EXITBTN){request_exit();return 0;}if(id==IDC_SET_RESETLAYOUT){reset_window_layout(TRUE);return 0;}if(id==IDC_SET_DEBUG){v=SendMessageW(g_setDebug,BM_GETCHECK,0,0)==BST_CHECKED;set_debug_mode(v,TRUE);return 0;}if(id==IDC_SET_MINIMIZE){g_settings.minimizeToTray=SendMessageW(g_setMinimize,BM_GETCHECK,0,0)==BST_CHECKED;mask=SETF_MINIMIZE;}else if(id==IDC_SET_CLOSE){g_settings.closeToTray=SendMessageW(g_setClose,BM_GETCHECK,0,0)==BST_CHECKED;mask=SETF_CLOSE;}else if(id==IDC_SET_STARTMIN){g_settings.startMinimized=SendMessageW(g_setStartMin,BM_GETCHECK,0,0)==BST_CHECKED;mask=SETF_STARTMIN;}else if(id==IDC_SET_OPENSETTINGS){g_settings.openSettingsAtStartup=SendMessageW(g_setOpenSettings,BM_GETCHECK,0,0)==BST_CHECKED;mask=SETF_OPENSETTINGS;}else if(id==IDC_SET_STARTPAUSED){g_settings.startPaused=SendMessageW(g_setStartPaused,BM_GETCHECK,0,0)==BST_CHECKED;mask=SETF_STARTPAUSED;}else if(id==IDC_SET_NOTIFICATIONS){g_settings.notifications=SendMessageW(g_setNotifications,BM_GETCHECK,0,0)==BST_CHECKED;mask=SETF_NOTIFICATIONS;}else if(id==IDC_SET_SINGLECLICK){g_settings.trayClickMode=SendMessageW(g_setSingleClick,BM_GETCHECK,0,0)==BST_CHECKED?1:2;mask=SETF_TRAYCLICK;}else return 0;persist_settings_mask(mask);settings_sync_ui();log_event(L"INFO",L"Setting changed through Settings production handler");return 0;}
case WM_CLOSE:ShowWindow(h,SW_HIDE);return 0;case WM_DESTROY:g_settingsHwnd=NULL;return 0;}return DefWindowProcW(h,msg,wp,lp);}
static void open_settings_window(void){if(!g_settingsHwnd){g_settingsHwnd=CreateWindowExW(WS_EX_TOOLWINDOW,L"ProgramDiagnosticMonitorIsolatedSettingsWindow",L"Program Diagnostic Monitor — Settings",WS_OVERLAPPED|WS_CAPTION|WS_SYSMENU,sc(160),sc(110),sc(550),sc(430),NULL,NULL,g_hInst,NULL);}if(g_settingsHwnd){settings_sync_ui();ShowWindow(g_settingsHwnd,SW_SHOW);BringWindowToTop(g_settingsHwnd);SetForegroundWindow(g_settingsHwnd);}}


static void font_all(HWND h){if(h)SendMessageW(h,WM_SETFONT,(WPARAM)g_uiFont,TRUE);}
static void apply_ui_fonts(void){
    HWND controls[]={g_programLabel,g_argsLabel,g_watchLabel,g_pathEdit,g_argsEdit,g_watchEdit,g_browseBtn,g_watchBrowseBtn,g_startBtn,g_stopBtn,g_saveBtn,g_baseBtn,g_openFolderBtn,g_attachCheck,g_markBtn,g_settingsBtn,g_selfTestBtn,g_debugCheck,g_exitBtn,g_reportEdit,g_status};
    for(UINT i=0;i<sizeof(controls)/sizeof(controls[0]);i++)font_all(controls[i]);
    if(g_reportEdit)SendMessageW(g_reportEdit,WM_SETFONT,(WPARAM)g_monoFont,TRUE);
}
static void layout(HWND h){
    RECT r;if(!GetClientRect(h,&r))return;
    INT w=r.right-r.left,hh=r.bottom-r.top;
    INT m=sc(14),gap=sc(8),labelW=sc(84),rowH=sc(28),btnW=sc(110),panelW=sc(314);
    INT panelX=w-m-panelW,leftX=m,editX=leftX+labelW,browseX=panelX-gap-btnW,editW=browseX-gap-editX;
    if(panelX<sc(520)){panelX=sc(520);browseX=panelX-gap-btnW;editW=browseX-gap-editX;}if(editW<sc(140))editW=sc(140);
    INT y1=sc(14),y2=sc(50),y3=sc(86),y4=sc(122),y5=sc(158);
    MoveWindow(g_programLabel,leftX,y1+sc(5),labelW-sc(4),sc(22),TRUE);MoveWindow(g_pathEdit,editX,y1,editW,rowH,TRUE);MoveWindow(g_browseBtn,browseX,y1,btnW,rowH,TRUE);
    MoveWindow(g_argsLabel,leftX,y2+sc(5),labelW-sc(4),sc(22),TRUE);MoveWindow(g_argsEdit,editX,y2,editW+btnW+gap,rowH,TRUE);
    MoveWindow(g_watchLabel,leftX,y3+sc(5),labelW-sc(4),sc(22),TRUE);MoveWindow(g_watchEdit,editX,y3,editW,rowH,TRUE);MoveWindow(g_watchBrowseBtn,browseX,y3,btnW,rowH,TRUE);
    INT half=(panelW-gap)/2;MoveWindow(g_startBtn,panelX,y1,half,sc(30),TRUE);MoveWindow(g_stopBtn,panelX+half+gap,y1,half,sc(30),TRUE);MoveWindow(g_saveBtn,panelX,y2,half,rowH,TRUE);MoveWindow(g_baseBtn,panelX+half+gap,y2,half,rowH,TRUE);MoveWindow(g_openFolderBtn,panelX,y3,panelW,rowH,TRUE);
    MoveWindow(g_attachCheck,editX,y4,editW+btnW+gap,rowH,TRUE);MoveWindow(g_markBtn,panelX,y4,panelW,rowH,TRUE);
    INT toolW=(w-(m*2)-(gap*3))/4;if(toolW<sc(150))toolW=sc(150);MoveWindow(g_settingsBtn,m,y5,toolW,rowH,TRUE);MoveWindow(g_selfTestBtn,m+toolW+gap,y5,toolW,rowH,TRUE);MoveWindow(g_debugCheck,m+(toolW+gap)*2,y5,toolW,rowH,TRUE);MoveWindow(g_exitBtn,m+(toolW+gap)*3,y5,toolW,rowH,TRUE);
    INT reportY=sc(198),statusH=sc(26),bottom=sc(14);INT reportH=hh-reportY-statusH-bottom-sc(8);if(reportH<sc(100))reportH=sc(100);MoveWindow(g_reportEdit,m,reportY,w-(m*2),reportH,TRUE);MoveWindow(g_status,m,reportY+reportH+sc(8),w-(m*2),statusH,TRUE);
}

static LRESULT CALLBACK wndproc(HWND h,UINT msg,WPARAM wp,LPARAM lp){
    if(g_taskbarCreated&&msg==g_taskbarCreated){g_trayAdded=FALSE;tray_add();log_event(L"INFO",L"Tray icon rebuilt after Explorer/taskbar restart");return 0;}
    switch(msg){
    case WM_GETMINMAXINFO:{MINMAXINFO* mm=(MINMAXINFO*)lp;if(mm){mm->ptMinTrackSize.x=sc(900);mm->ptMinTrackSize.y=sc(560);}return 0;}
    case WM_CREATE:{
        g_programLabel=CreateWindowExW(0,L"STATIC",L"Program:",WS_CHILD|WS_VISIBLE,0,0,0,0,h,0,g_hInst,NULL);
        g_pathEdit=CreateWindowExW(WS_EX_CLIENTEDGE,L"EDIT",L"",WS_CHILD|WS_VISIBLE|ES_AUTOHSCROLL,0,0,0,0,h,(HMENU)IDC_PATH,g_hInst,NULL);
        g_browseBtn=CreateWindowExW(0,L"BUTTON",L"Browse...",WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON,0,0,0,0,h,(HMENU)IDC_BROWSE,g_hInst,NULL);
        g_argsLabel=CreateWindowExW(0,L"STATIC",L"Arguments:",WS_CHILD|WS_VISIBLE,0,0,0,0,h,0,g_hInst,NULL);
        g_argsEdit=CreateWindowExW(WS_EX_CLIENTEDGE,L"EDIT",L"",WS_CHILD|WS_VISIBLE|ES_AUTOHSCROLL,0,0,0,0,h,(HMENU)IDC_ARGS,g_hInst,NULL);
        g_watchLabel=CreateWindowExW(0,L"STATIC",L"Watch folder:",WS_CHILD|WS_VISIBLE,0,0,0,0,h,0,g_hInst,NULL);
        g_watchEdit=CreateWindowExW(WS_EX_CLIENTEDGE,L"EDIT",L"Disabled in isolated mode",WS_CHILD|WS_VISIBLE|ES_AUTOHSCROLL,0,0,0,0,h,(HMENU)IDC_WATCH,g_hInst,NULL);
        g_watchBrowseBtn=CreateWindowExW(0,L"BUTTON",L"Disabled",WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON,0,0,0,0,h,(HMENU)IDC_WATCH_BROWSE,g_hInst,NULL);
        g_startBtn=CreateWindowExW(0,L"BUTTON",L"Start Diagnostic",WS_CHILD|WS_VISIBLE|BS_DEFPUSHBUTTON,0,0,0,0,h,(HMENU)IDC_START,g_hInst,NULL);
        g_stopBtn=CreateWindowExW(0,L"BUTTON",L"Stop && Analyze",WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON,0,0,0,0,h,(HMENU)IDC_STOP,g_hInst,NULL);
        g_saveBtn=CreateWindowExW(0,L"BUTTON",L"Save Report",WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON,0,0,0,0,h,(HMENU)IDC_SAVE,g_hInst,NULL);
        g_baseBtn=CreateWindowExW(0,L"BUTTON",L"Set as Baseline",WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON,0,0,0,0,h,(HMENU)IDC_BASELINE,g_hInst,NULL);
        g_openFolderBtn=CreateWindowExW(0,L"BUTTON",L"Open Program Folder",WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON,0,0,0,0,h,(HMENU)IDC_OPENFOLDER,g_hInst,NULL);
        g_attachCheck=CreateWindowExW(0,L"BUTTON",L"Passive AV-safe watch: wait/attach only; never launch target",WS_CHILD|WS_VISIBLE|BS_AUTOCHECKBOX,0,0,0,0,h,(HMENU)IDC_ATTACH_EXISTING,g_hInst,NULL);SendMessageW(g_attachCheck,BM_SETCHECK,BST_CHECKED,0);
        g_markBtn=CreateWindowExW(WS_EX_CLIENTEDGE,L"STATIC",L"Automatic freeze/lag detection: ON",WS_CHILD|WS_VISIBLE,0,0,0,0,h,0,g_hInst,NULL);
        g_settingsBtn=CreateWindowExW(0,L"BUTTON",L"Settings",WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON,0,0,0,0,h,(HMENU)IDC_SETTINGS,g_hInst,NULL);
        g_selfTestBtn=CreateWindowExW(0,L"BUTTON",L"Run Safe Self-Test",WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON,0,0,0,0,h,(HMENU)IDC_SELFTEST,g_hInst,NULL);
        g_debugCheck=CreateWindowExW(0,L"BUTTON",L"Debug Mode",WS_CHILD|WS_VISIBLE|BS_AUTOCHECKBOX,0,0,0,0,h,(HMENU)IDC_DEBUG,g_hInst,NULL);
        g_exitBtn=CreateWindowExW(0,L"BUTTON",L"Exit App",WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON,0,0,0,0,h,(HMENU)IDC_EXITAPP,g_hInst,NULL);
        g_reportEdit=CreateWindowExW(WS_EX_CLIENTEDGE,L"EDIT",L"Automatic isolated AV-oriented freeze/lag workflow: select the .exe, click Start Diagnostic, then open the program normally. The monitor waits for the MAIN process and never launches a duplicate.\r\n\r\nNo Freeze/Lag button is needed. The app automatically samples MAIN + same-family helper CPU/memory/I/O, system CPU/RAM/disk, GDI/USER resources, and MAIN-window responsiveness about once per second. At freeze onset it runs target-only Wait Chain Traversal for hung MAIN UI threads without opening target threads. Reproduce the lag/freeze, wait about 10-20 seconds after it happens, then click Stop & Analyze. Broad DLL/event/network/folder scans are disabled in isolated mode.",WS_CHILD|WS_VISIBLE|WS_VSCROLL|WS_HSCROLL|ES_MULTILINE|ES_AUTOVSCROLL|ES_AUTOHSCROLL|ES_READONLY,0,0,0,0,h,(HMENU)IDC_REPORT,g_hInst,NULL);SendMessageW(g_reportEdit,EM_SETLIMITTEXT,0x7FFFFFFE,0);
        g_status=CreateWindowExW(0,L"STATIC",L"Ready — choose a program. No telemetry or network access.",WS_CHILD|WS_VISIBLE,0,0,0,0,h,(HMENU)IDC_STATUS,g_hInst,NULL);
        g_uiFont=CreateFontW(-sc(14),0,0,0,FW_NORMAL,0,0,0,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,0,L"Segoe UI");g_monoFont=CreateFontW(-sc(13),0,0,0,FW_NORMAL,0,0,0,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,FIXED_PITCH|FF_MODERN,L"Consolas");apply_ui_fonts();settings_sync_ui();
        EnableWindow(g_startBtn,FALSE);EnableWindow(g_stopBtn,FALSE);EnableWindow(g_saveBtn,FALSE);EnableWindow(g_baseBtn,FALSE);EnableWindow(g_openFolderBtn,FALSE);EnableWindow(g_watchEdit,FALSE);EnableWindow(g_watchBrowseBtn,FALSE);EnableWindow(g_attachCheck,FALSE);layout(h);return 0;}
    case WM_EXITSIZEMOVE:save_window_geometry();return 0;
    case WM_SIZE:if(wp==SIZE_MINIMIZED&&g_settings.minimizeToTray&&!g_exiting){ShowWindow(h,SW_HIDE);log_event(L"INFO",L"Main window minimized to tray");return 0;}layout(h);return 0;
    case WM_PDM_TRAY:if((UINT)lp==WM_RBUTTONUP){tray_menu();return 0;}if(g_settings.trayClickMode==1&&(UINT)lp==WM_LBUTTONUP){show_main_window();return 0;}if(g_settings.trayClickMode==2&&(UINT)lp==WM_LBUTTONDBLCLK){show_main_window();return 0;}return 0;
    case WM_PDM_STATUS:{WCHAR* p=(WCHAR*)lp;if(p){set_status(p);HeapFree(GetProcessHeap(),0,p);}return 0;}
    case WM_PDM_NO_INSTANCE:if(g_workerHandle){CloseHandle(g_workerHandle);g_workerHandle=NULL;}g_monitoring=FALSE;g_stopRequested=0;set_inputs_enabled(TRUE);EnableWindow(g_startBtn,g_program[0]&&!g_paused);EnableWindow(g_stopBtn,FALSE);set_status(L"Passive watch ended.");return 0;
    case WM_PDM_WORKER_ERROR:{WCHAR* p=(WCHAR*)lp;if(g_workerHandle){CloseHandle(g_workerHandle);g_workerHandle=NULL;}g_monitoring=FALSE;g_stopRequested=0;set_inputs_enabled(TRUE);EnableWindow(g_startBtn,g_program[0]&&!g_paused);EnableWindow(g_stopBtn,FALSE);set_status(L"Diagnostic worker stopped because Windows reported an error.");log_event(L"ERROR",L"Diagnostic worker stopped because Windows reported an error");if(p){MessageBoxW(g_hwnd,p,APP_NAME,MB_OK|MB_ICONERROR);HeapFree(GetProcessHeap(),0,p);}return 0;}
    case WM_PDM_ANALYSIS_COMPLETE:if(g_workerHandle){CloseHandle(g_workerHandle);g_workerHandle=NULL;}g_monitoring=FALSE;g_stopRequested=0;report_to_ui();set_inputs_enabled(TRUE);EnableWindow(g_startBtn,g_program[0]&&!g_paused);EnableWindow(g_stopBtn,FALSE);EnableWindow(g_saveBtn,TRUE);EnableWindow(g_baseBtn,TRUE);if(wp)set_status(L"Target stayed exited through the restart watch — background analysis complete. You can save the report or start another diagnostic.");else set_status(L"Background analysis complete. Save the report if you want to share or compare it.");log_event(L"INFO",L"Diagnostic analysis completed");tray_notify(L"Program Diagnostic Monitor",L"Background diagnostic analysis is complete.");return 0;
    case WM_COMMAND:{DWORD id=(DWORD)(wp&0xFFFF),code=(DWORD)((wp>>16)&0xFFFF);if(id==IDC_PATH&&code==EN_CHANGE){GetWindowTextW(g_pathEdit,g_program,MAX_WPATH);BOOL has=g_program[0]?TRUE:FALSE;EnableWindow(g_startBtn,has&&!g_paused&&!g_monitoring&&!g_workerHandle);EnableWindow(g_openFolderBtn,has&&!g_monitoring&&!g_workerHandle);return 0;}if(id==IDC_BROWSE)choose_exe(h);else if(id==IDC_START)start_diagnostic();else if(id==IDC_STOP)stop_diagnostic();else if(id==IDC_SAVE)save_text_file(h,g_report);else if(id==IDC_BASELINE)set_baseline();else if(id==IDC_OPENFOLDER)open_program_folder();else if(id==IDC_SETTINGS)open_settings_window();else if(id==IDC_SELFTEST)run_safe_self_test();else if(id==IDC_DEBUG&&code==BN_CLICKED)set_debug_mode(SendMessageW(g_debugCheck,BM_GETCHECK,0,0)==BST_CHECKED,TRUE);else if(id==IDC_EXITAPP)request_exit();return 0;}
    case WM_CLOSE:if(!g_exiting&&g_settings.closeToTray){save_window_geometry();ShowWindow(h,SW_HIDE);log_event(L"INFO",L"Main window closed to tray");return 0;}g_exiting=TRUE;save_window_geometry();if(g_settingsHwnd){DestroyWindow(g_settingsHwnd);g_settingsHwnd=NULL;}DestroyWindow(h);return 0;
    case WM_DESTROY:g_shutdownRequested=1;g_stopRequested=1;g_monitoring=FALSE;tray_remove();log_event(L"INFO",L"Application shutdown");if(g_workerHandle){DWORD wr=WaitForSingleObject(g_workerHandle,2000);CloseHandle(g_workerHandle);g_workerHandle=NULL;(void)wr;}if(g_rootHandle){CloseHandle(g_rootHandle);g_rootHandle=NULL;}if(g_uiFont)DeleteObject(g_uiFont);if(g_monoFont)DeleteObject(g_monoFont);PostQuitMessage(0);return 0;
    }
    return DefWindowProcW(h,msg,wp,lp);
}

void wWinMainCRTStartup(void){
    g_hInst=GetModuleHandleW(NULL);init_dpi_awareness();init_dialog_dirs();init_app_paths();load_settings();clamp_window_geometry();g_paused=g_settings.startPaused;
    g_report=(WCHAR*)HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,REPORT_CAP*sizeof(WCHAR));g_timeline=(WCHAR*)HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,TIMELINE_CAP*sizeof(WCHAR));g_freezeDetails=(WCHAR*)HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,FREEZE_DETAIL_CAP*sizeof(WCHAR));if(!g_report||!g_timeline||!g_freezeDetails){MessageBoxW(NULL,L"Not enough memory to start.",APP_NAME,MB_OK|MB_ICONERROR);ExitProcess(1);}CoInitializeEx(NULL,COINIT_APARTMENTTHREADED);
    g_taskbarCreated=RegisterWindowMessageW(L"TaskbarCreated");
    WNDCLASSEXW wc;memset(&wc,0,sizeof(wc));wc.cbSize=sizeof(wc);wc.lpfnWndProc=wndproc;wc.hInstance=g_hInst;wc.hCursor=LoadCursorW(NULL,IDC_ARROW);wc.hIcon=LoadIconW(g_hInst,(LPCWSTR)(ULONG_PTR)1);if(!wc.hIcon)wc.hIcon=LoadIconW(NULL,IDI_APPLICATION);wc.hIconSm=wc.hIcon;wc.hbrBackground=(HBRUSH)(ULONG_PTR)(COLOR_WINDOW+1);wc.lpszClassName=APP_WINDOW_CLASS;if(!RegisterClassExW(&wc)){MessageBoxW(NULL,L"Could not register the application window.",APP_NAME,MB_OK|MB_ICONERROR);ExitProcess(2);}
    WNDCLASSEXW swc=wc;swc.lpfnWndProc=settings_proc;swc.lpszClassName=L"ProgramDiagnosticMonitorIsolatedSettingsWindow";if(!RegisterClassExW(&swc)){MessageBoxW(NULL,L"Could not register the Settings window.",APP_NAME,MB_OK|MB_ICONERROR);ExitProcess(2);}
    g_hwnd=CreateWindowExW(0,APP_WINDOW_CLASS,L"Program Diagnostic Monitor 1.0.18 Build 19 — Isolated Automatic Freeze / Lag Diagnostics",WS_OVERLAPPEDWINDOW,g_settings.winX,g_settings.winY,g_settings.winW,g_settings.winH,NULL,NULL,g_hInst,NULL);if(!g_hwnd){MessageBoxW(NULL,L"Could not create the application window.",APP_NAME,MB_OK|MB_ICONERROR);ExitProcess(3);}tray_add();log_event(L"INFO",L"Application startup");
    if(g_settings.startMinimized)ShowWindow(g_hwnd,SW_HIDE);else{ShowWindow(g_hwnd,SW_SHOW);UpdateWindow(g_hwnd);}if(g_paused)set_status(L"Paused at startup — Resume from the tray to begin monitoring.");if(g_settings.openSettingsAtStartup)open_settings_window();
    MSG m;while(GetMessageW(&m,NULL,0,0)>0){TranslateMessage(&m);DispatchMessageW(&m);}CoUninitialize();ExitProcess((UINT)m.wParam);
}
