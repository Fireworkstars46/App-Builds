#include "winmini.h"
#define APP_NAME L"Program Diagnostic Monitor"
#define MAX_WPATH 1024
void *memset(void*d,int c,SIZE_T n){BYTE*p=d;while(n--)*p++=(BYTE)c;return d;}
void *memcpy(void*d,const void*s,SIZE_T n){BYTE*a=d;const BYTE*b=s;while(n--)*a++=*b++;return d;}
int memcmp(const void*a,const void*b,SIZE_T n){const BYTE*x=a,*y=b;while(n--){if(*x!=*y)return*x-*y;x++;y++;}return 0;}
static DWORD wlen(LPCWSTR s){DWORD n=0;while(s&&s[n])n++;return n;}
static void wcopy(LPWSTR d,LPCWSTR s,DWORD c){DWORD i=0;if(!c)return;while(s&&s[i]&&i+1<c){d[i]=s[i];i++;}d[i]=0;}
static void wcat(LPWSTR d,LPCWSTR s,DWORD c){DWORD n=wlen(d),i=0;while(s&&s[i]&&n+i+1<c){d[n+i]=s[i];i++;}d[n+i]=0;}
static void dirnamew(LPCWSTR p,LPWSTR o,DWORD c){wcopy(o,p,c);DWORD n=wlen(o);while(n){if(o[n-1]==L'\\'||o[n-1]==L'/'){o[n-1]=0;return;}n--;}o[0]=0;}
static DWORD atou(LPCWSTR s){DWORD v=0;while(*s>=L'0'&&*s<=L'9'){v=v*10+(*s-L'0');s++;}return v;}
static WCHAR lower_ascii(WCHAR c){return(c>=L'A'&&c<=L'Z')?(WCHAR)(c+(L'a'-L'A')):c;}
static BOOL path_eq_i(LPCWSTR a,LPCWSTR b){DWORD i=0;if(!a||!b)return FALSE;while(a[i]&&b[i]){WCHAR x=a[i],y=b[i];if(x==L'/')x=L'\\';if(y==L'/')y=L'\\';if(lower_ascii(x)!=lower_ascii(y))return FALSE;i++;}return a[i]==0&&b[i]==0;}
static BOOL expected_roots(LPWSTR installDir,LPWSTR appDataRoot){WCHAR local[MAX_WPATH];DWORD n=GetEnvironmentVariableW(L"LOCALAPPDATA",local,MAX_WPATH);if(!n||n>=MAX_WPATH)return FALSE;wcopy(installDir,local,MAX_WPATH);wcat(installDir,L"\\Programs\\ProgramDiagnosticMonitor-Isolated",MAX_WPATH);wcopy(appDataRoot,local,MAX_WPATH);wcat(appDataRoot,L"\\ProgramDiagnosticMonitor-Isolated",MAX_WPATH);return TRUE;}
static BOOL dot(LPCWSTR n){return(n[0]==L'.'&&n[1]==0)||(n[0]==L'.'&&n[1]==L'.'&&n[2]==0);}
__declspec(dllimport) BOOL WINAPI SetFileAttributesW(LPCWSTR,DWORD);
static void delete_tree(LPCWSTR dir){
    WCHAR pat[MAX_WPATH],full[MAX_WPATH];wcopy(pat,dir,MAX_WPATH);wcat(pat,L"\\*",MAX_WPATH);WIN32_FIND_DATAW fd;HANDLE h=FindFirstFileW(pat,&fd);
    if(h!=INVALID_HANDLE_VALUE){do{if(dot(fd.cFileName))continue;wcopy(full,dir,MAX_WPATH);wcat(full,L"\\",MAX_WPATH);wcat(full,fd.cFileName,MAX_WPATH);if(fd.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY)delete_tree(full);else{if(fd.dwFileAttributes&(FILE_ATTRIBUTE_HIDDEN|FILE_ATTRIBUTE_SYSTEM))SetFileAttributesW(full,FILE_ATTRIBUTE_NORMAL);DeleteFileW(full);}}while(FindNextFileW(h,&fd));FindClose(h);}RemoveDirectoryW(dir);
}
static void remove_shortcuts(void){
    WCHAR p[MAX_WPATH];if(SHGetFolderPathW(NULL,CSIDL_PROGRAMS,NULL,SHGFP_TYPE_CURRENT,p)>=0){wcat(p,L"\\Program Diagnostic Monitor (Isolated)",MAX_WPATH);WCHAR f[MAX_WPATH];wcopy(f,p,MAX_WPATH);wcat(f,L"\\Program Diagnostic Monitor (Isolated).lnk",MAX_WPATH);DeleteFileW(f);wcopy(f,p,MAX_WPATH);wcat(f,L"\\Uninstall Program Diagnostic Monitor (Isolated).lnk",MAX_WPATH);DeleteFileW(f);RemoveDirectoryW(p);}if(SHGetFolderPathW(NULL,CSIDL_DESKTOPDIRECTORY,NULL,SHGFP_TYPE_CURRENT,p)>=0){wcat(p,L"\\Program Diagnostic Monitor (Isolated).lnk",MAX_WPATH);DeleteFileW(p);}
}
static void cleanup_mode(LPCWSTR installDir,LPCWSTR appDataRoot,DWORD parentPid){
    WCHAR expectedInstall[MAX_WPATH],expectedData[MAX_WPATH];if(!expected_roots(expectedInstall,expectedData)||!path_eq_i(installDir,expectedInstall)||!path_eq_i(appDataRoot,expectedData)){MessageBoxW(NULL,L"Cleanup request did not match the dedicated Program Diagnostic Monitor isolated paths. Nothing was deleted.",APP_NAME,MB_OK|MB_ICONERROR);ExitProcess(5);}
    HANDLE ph=OpenProcess(SYNCHRONIZE,FALSE,parentPid);if(ph){WaitForSingleObject(ph,15000);CloseHandle(ph);}delete_tree(installDir);
    WCHAR p[MAX_WPATH];wcopy(p,appDataRoot,MAX_WPATH);wcat(p,L"\\Data",MAX_WPATH);delete_tree(p);
    /* Logs and Diagnostics intentionally remain as user diagnostic evidence. The helper lives in project Temp and cleans that folder as far as Windows permits while it is running. */
    wcopy(p,appDataRoot,MAX_WPATH);wcat(p,L"\\Temp",MAX_WPATH);delete_tree(p);
    WCHAR self[MAX_WPATH];GetModuleFileNameW(NULL,self,MAX_WPATH);MoveFileExW(self,NULL,MOVEFILE_DELAY_UNTIL_REBOOT);
    MessageBoxW(NULL,L"Program Diagnostic Monitor was removed. Installed app files, shortcuts, and PDM Data/settings were deleted.\r\n\r\nThe dedicated Logs and Diagnostics folders were preserved, along with reports you saved elsewhere.",L"Uninstall complete",MB_OK|MB_ICONINFORMATION);ExitProcess(0);
}
void wWinMainCRTStartup(void){
    INT argc=0;LPWSTR* argv=CommandLineToArgvW(GetCommandLineW(),&argc);if(argc>=5&&argv&&argv[1][0]==L'-'&&argv[1][1]==L'-'){cleanup_mode(argv[2],argv[3],atou(argv[4]));}
    WCHAR self[MAX_WPATH],dir[MAX_WPATH];GetModuleFileNameW(NULL,self,MAX_WPATH);dirnamew(self,dir,MAX_WPATH);WCHAR expectedInstall[MAX_WPATH],expectedData[MAX_WPATH];if(!expected_roots(expectedInstall,expectedData)||!path_eq_i(dir,expectedInstall)){MessageBoxW(NULL,L"For safety, this uninstaller only runs from the dedicated Program Diagnostic Monitor isolated install folder. Nothing was deleted.",APP_NAME,MB_OK|MB_ICONERROR);ExitProcess(6);}
    if(MessageBoxW(NULL,L"Uninstall Program Diagnostic Monitor?\r\n\r\nThis removes the isolated installed program, Start menu/Desktop shortcuts, uninstall entry, and PDM Data/settings. The dedicated PDM Logs and Diagnostics folders and reports saved elsewhere are preserved.",L"Uninstall Program Diagnostic Monitor (Isolated)",MB_YESNO|MB_ICONWARNING)!=IDYES)ExitProcess(0);
    remove_shortcuts();RegDeleteTreeW(HKEY_CURRENT_USER,L"Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\ProgramDiagnosticMonitor-Isolated");
    WCHAR appData[MAX_WPATH];wcopy(appData,expectedData,MAX_WPATH);WCHAR temp[MAX_WPATH];wcopy(temp,appData,MAX_WPATH);wcat(temp,L"\\Temp",MAX_WPATH);CreateDirectoryW(appData,NULL);CreateDirectoryW(temp,NULL);
    WCHAR name[128];wsprintfW(name,L"\\PDM-Isolated-Uninstall-%u.exe",GetCurrentProcessId());wcat(temp,name,MAX_WPATH);if(!CopyFileW(self,temp,FALSE)){MessageBoxW(NULL,L"Could not start the isolated cleanup helper. Uninstall stopped.",APP_NAME,MB_OK|MB_ICONERROR);ExitProcess(3);}
    WCHAR cmd[4096];wsprintfW(cmd,L"\"%s\" --cleanup \"%s\" \"%s\" %u",temp,dir,appData,GetCurrentProcessId());STARTUPINFOW si;PROCESS_INFORMATION pi;memset(&si,0,sizeof(si));memset(&pi,0,sizeof(pi));si.cb=sizeof(si);if(!CreateProcessW(temp,cmd,NULL,NULL,FALSE,CREATE_UNICODE_ENVIRONMENT,NULL,NULL,&si,&pi)){DeleteFileW(temp);MessageBoxW(NULL,L"Could not start the isolated cleanup helper. Uninstall stopped.",APP_NAME,MB_OK|MB_ICONERROR);ExitProcess(4);}CloseHandle(pi.hThread);CloseHandle(pi.hProcess);ExitProcess(0);
}
