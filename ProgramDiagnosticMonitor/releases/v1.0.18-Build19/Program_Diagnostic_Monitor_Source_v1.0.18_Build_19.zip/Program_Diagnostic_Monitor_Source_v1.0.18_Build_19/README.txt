Program Diagnostic Monitor v1.0.18 Build 19
===========================================

Recovery/source status
----------------------
Build 19 is the first permanently recoverable source-backed release after the
original v1.0.18 Build 18 chat artifacts expired. It is reconstructed from the
actual v1.0.15 source tree, the verified v1.0.17 Build 17 compiled baseline,
and the documented Build 16-18 requirements. It is a new Build 19; it is not a
relabeling or fabrication of the lost historical Build 18 source.

Purpose
-------
A passive, read-only Windows diagnostic monitor for an explicitly selected EXE.
It is intended to help investigate hangs, freezes, lag, unexpected exits, and
restart behavior while minimizing antivirus-sensitive behavior.

Build 19 safety / isolation model
---------------------------------
- Passive wait/attach only: the monitor never launches the selected target.
- MAIN-process access uses PROCESS_QUERY_LIMITED_INFORMATION only.
- No code/DLL injection, API hooks, debugger attach, remote memory access,
  thread suspension, driver, service, scheduled task, updater, telemetry, or
  target termination.
- Cross-process DLL/module enumeration is disabled.
- Broad Application event-log scanning is disabled.
- System-wide TCP/UDP owner-table enumeration is disabled.
- Target token/integrity inspection is disabled.
- Recursive watched-folder scanning is disabled.
- Same-family helpers are refreshed at a bounded interval for lightweight
  aggregate CPU/memory/I/O correlation only and are excluded from deep scans.
- Freeze/lag detection uses a bounded 150 ms WM_NULL window responsiveness
  probe from the background worker.
- Wait Chain Traversal is dynamically loaded and limited to hung MAIN UI thread
  IDs, up to four per freeze event. The monitor does not OpenThread or walk
  target stacks.
- Crash Monitor and RitschyMirror are protected peers unless explicitly chosen
  as the selected target.

Project isolation
-----------------
Install:  %LOCALAPPDATA%\Programs\ProgramDiagnosticMonitor-Isolated
Data:     %LOCALAPPDATA%\ProgramDiagnosticMonitor-Isolated
Settings: ...\Data\settings.ini
Logs:     ...\Logs
Temp:     ...\Temp
Reports:  ...\Diagnostics

Build 19 preserves the isolated uninstall identity and does not share private
helpers, settings, logs, temp state, IPC, services, tasks, or updater state with
other projects.

UI / settings
-------------
Build 19 includes project-local bounded logs, Debug Mode, Safe Self-Test,
Settings, tray recovery after Explorer/taskbar restart, Minimize-to-Tray,
Close/X-to-Tray vs Exit, Start Minimized, Open Settings at startup, Start
Paused, notifications, configurable tray click behavior, Reset Window Layout,
remembered window geometry, Logs/Diagnostics access, and diagnostic export.

Settings intended to be immediate use the production setter/state path and are
persisted atomically. Shared settings writes use a merge-under-mutex strategy so
an older concurrent instance cannot blindly overwrite newer unrelated settings.

Safe Self-Test
--------------
The in-app Safe Self-Test exercises safely testable production paths using
project-owned temporary data where practical. Every item reports PASS, FAIL,
SKIPPED, or NOT TESTED. It does not claim PASS for destructive/unavailable
runtime actions such as terminating its own process, forcing Explorer to exit,
or manufacturing a real hung external target.

Installer/update behavior
-------------------------
The per-user installer preserves the existing isolated install/data identity and
keeps user Data/Settings/Logs/Diagnostics during in-place updates. Optional app
launch occurs only after Finish. The installer verifies the embedded app and
uninstaller SHA-256 values before installation.

Uninstall
---------
Use Windows Settings > Apps, the Start Menu uninstall shortcut, or the installed
Uninstall.exe. Build 19 guards cleanup against non-project paths. Logs and
Diagnostics are intentionally preserved as recovery evidence.

Security note
-------------
This custom build is unsigned. Static/import checks can verify the intended
least-privilege design, but they cannot guarantee that reputation-based
SmartScreen or antivirus products will never warn.
